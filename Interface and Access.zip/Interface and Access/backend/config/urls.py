from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('django-admin/', admin.site.urls),
    path('api/', include('accounts.urls')),
    path('api/', include('skills.urls')),
    path('api/', include('verification.urls')),
    path('api/', include('wallet.urls')),
    path('api/', include('learning_sessions.urls')),
    path('api/', include('swaps.urls')),
    path('api/', include('materials.urls')),
    path('api/', include('reviews.urls')),
    path('api/', include('notifications.urls')),
    path('api/', include('achievements.urls')),
    path('api/', include('chatbot.urls')),
    path('api/', include('administration.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
