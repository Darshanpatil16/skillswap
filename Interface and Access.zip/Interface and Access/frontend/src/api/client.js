import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

const client = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to attach JWT Access Token
client.interceptors.request.use(
  (config) => {
    const tokens = localStorage.getItem('skillswap_tokens');
    if (tokens) {
      try {
        const parsed = JSON.parse(tokens);
        if (parsed.access) {
          config.headers.Authorization = `Bearer ${parsed.access}`;
        }
      } catch (e) {
        console.error('Error parsing auth tokens', e);
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle token refresh
client.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      const tokensStr = localStorage.getItem('skillswap_tokens');
      if (tokensStr) {
        try {
          const tokens = JSON.parse(tokensStr);
          if (tokens.refresh) {
            const res = await axios.post(`${API_BASE_URL}/auth/token/refresh/`, {
              refresh: tokens.refresh,
            });
            if (res.data.access) {
              tokens.access = res.data.access;
              localStorage.setItem('skillswap_tokens', JSON.stringify(tokens));
              originalRequest.headers.Authorization = `Bearer ${res.data.access}`;
              return client(originalRequest);
            }
          }
        } catch (refreshErr) {
          localStorage.removeItem('skillswap_tokens');
          localStorage.removeItem('skillswap_user');
          window.location.href = '/login';
        }
      }
    }
    return Promise.reject(error);
  }
);

export default client;
