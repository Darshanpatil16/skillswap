import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, Sun, Moon, Bell, Coins, User, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import client from '../api/client';

export default function TopHeader({ setMobileOpen }) {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    const fetchUnread = async () => {
      try {
        const res = await client.get('/notifications/');
        if (res.data?.unread_count !== undefined) {
          setUnreadCount(res.data.unread_count);
        }
      } catch (err) {
        // silent
      }
    };
    if (user) {
      fetchUnread();
    }
  }, [user]);

  return (
    <header className="sticky top-0 z-30 h-16 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 flex items-center justify-between">
      {/* Left: Mobile Toggle & Campus Info */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setMobileOpen(true)}
          className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden"
          aria-label="Open navigation sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="hidden sm:block">
          <p className="text-xs font-semibold text-slate-900 dark:text-white leading-tight">
            {user?.profile?.college_name || 'SkillSwap University'}
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            {user?.profile?.department || 'Student Skill Exchange Portal'}
          </p>
        </div>
      </div>

      {/* Right: Credits, Notifications, Theme, Profile */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        {/* Available Credits Pill */}
        <Link
          to="/wallet"
          title="View Credit Ledger & Wallet"
          className="flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-amber-500/10 to-amber-600/10 hover:from-amber-500/20 hover:to-amber-600/20 text-amber-700 dark:text-amber-400 border border-amber-300/50 dark:border-amber-600/30 rounded-full transition-all group"
        >
          <Coins className="w-4 h-4 text-amber-600 dark:text-amber-400 group-hover:rotate-12 transition-transform" />
          <span className="text-xs font-bold tracking-tight">
            {user?.wallet_balance ?? 50} <span className="font-medium text-[11px] opacity-80">Credits</span>
          </span>
        </Link>

        {/* Notifications Icon with Badge */}
        <Link
          to="/notifications"
          className="relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 transition-colors"
          title="Notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </Link>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          aria-label="Toggle theme"
          className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 transition-colors"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
        </button>

        {/* Profile Avatar Pill */}
        <Link
          to="/profile"
          className="flex items-center gap-2 pl-1.5 pr-2.5 py-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 transition-all"
        >
          <div className="w-8 h-8 rounded-full bg-primary-600 text-white font-semibold text-xs flex items-center justify-center shadow-xs">
            {user?.first_name ? user.first_name[0] : user?.username?.[0]?.toUpperCase()}
          </div>
          <div className="hidden md:block text-left">
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block leading-tight">
              {user?.first_name || user?.username}
            </span>
            <span className="text-[10px] text-slate-400 dark:text-slate-500 capitalize">
              {user?.role}
            </span>
          </div>
        </Link>
      </div>
    </header>
  );
}
