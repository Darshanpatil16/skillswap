import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  User,
  GraduationCap,
  BookOpen,
  Repeat,
  Calendar,
  Wallet,
  Award,
  Bell,
  Bot,
  Settings,
  LogOut,
  ShieldAlert,
  Layers,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useChatbot } from '../context/ChatbotContext';

export default function Sidebar({ mobileOpen, setMobileOpen }) {
  const { user, logout, isAdmin } = useAuth();
  const { toggleChat } = useChatbot();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { name: 'Overview', path: '/dashboard', icon: LayoutDashboard },
    { name: 'My Profile', path: '/profile', icon: User },
    { name: 'Teach Skills', path: '/teach', icon: GraduationCap },
    { name: 'Learn Skills', path: '/learn', icon: BookOpen },
    { name: 'Skill Swap', path: '/swaps', icon: Repeat },
    { name: 'My Sessions', path: '/sessions', icon: Calendar },
    { name: 'Credit Wallet', path: '/wallet', icon: Wallet },
    { name: 'My Achievements', path: '/achievements', icon: Award },
    { name: 'Notifications', path: '/notifications', icon: Bell },
  ];

  const handleItemClick = () => {
    if (setMobileOpen) setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-sm lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transition-transform duration-200 ease-in-out flex flex-col justify-between ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Top Brand Logo */}
        <div>
          <div className="h-16 px-5 flex items-center gap-3 border-b border-slate-200 dark:border-slate-800">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-primary-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-primary-500/20">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-base text-slate-900 dark:text-white leading-none block">
                SkillSwap
              </span>
              <span className="text-[11px] font-medium text-primary-600 dark:text-primary-400">
                Credit Ledger
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-180px)]">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.name}
                  to={item.path}
                  onClick={handleItemClick}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      isActive
                        ? 'bg-primary-50 text-primary-700 dark:bg-primary-950/60 dark:text-primary-300 font-semibold shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'
                    }`
                  }
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span>{item.name}</span>
                </NavLink>
              );
            })}

            {/* AI Assistant Quick Trigger */}
            <button
              onClick={() => {
                toggleChat();
                handleItemClick();
              }}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200 transition-colors text-left"
            >
              <Bot className="w-4 h-4 text-accent-500 flex-shrink-0" />
              <span>AI Assistant</span>
              <span className="ml-auto text-[10px] bg-accent-100 dark:bg-accent-950 text-accent-700 dark:text-accent-300 px-1.5 py-0.5 rounded font-medium">
                Ask
              </span>
            </button>

            {/* Admin Portal if Admin */}
            {isAdmin && (
              <NavLink
                to="/admin-portal"
                onClick={handleItemClick}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 font-semibold'
                      : 'text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-slate-800'
                  }`
                }
              >
                <ShieldAlert className="w-4 h-4 flex-shrink-0" />
                <span>Admin Portal</span>
                <span className="ml-auto text-[10px] bg-amber-200 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 px-1.5 py-0.5 rounded font-bold">
                  ADMIN
                </span>
              </NavLink>
            )}
          </nav>
        </div>

        {/* Bottom User & Logout Area */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 space-y-1">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors text-left"
          >
            <LogOut className="w-4 h-4 flex-shrink-0" />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
}
