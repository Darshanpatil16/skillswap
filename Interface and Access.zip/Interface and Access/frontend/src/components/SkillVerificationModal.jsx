import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  Clock,
  Sparkles,
  HelpCircle,
  Award
} from 'lucide-react';
import client from '../api/client';

export default function SkillVerificationModal({ teachingSkill, isOpen, onClose, onVerified }) {
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [assessmentData, setAssessmentData] = useState(null);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen && teachingSkill) {
      fetchQuestions();
      setResult(null);
      setAnswers({});
      setError('');
    }
  }, [isOpen, teachingSkill]);

  const fetchQuestions = async () => {
    try {
      setLoading(true);
      const res = await client.get(`/verification/skills/${teachingSkill.id}/questions/`);
      setAssessmentData(res.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to load assessment questions.');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectOption = (questionId, optionId) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: {
        ...prev[questionId],
        question_id: questionId,
        selected_option_id: optionId,
      },
    }));
  };

  const handleTextResponse = (questionId, text) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: {
        ...prev[questionId],
        question_id: questionId,
        descriptive_response: text,
      },
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      setError('');

      const answersList = Object.values(answers);
      if (answersList.length === 0) {
        setError('Please answer the assessment questions before submitting.');
        setSubmitting(false);
        return;
      }

      const res = await client.post(`/verification/skills/${teachingSkill.id}/submit/`, {
        answers: answersList,
      });

      setResult(res.data);
      if (onVerified) onVerified(res.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to submit assessment.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-8"
      >
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-primary-600 via-indigo-600 to-primary-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">
                Peer Skill Verification Assessment
              </h3>
              <p className="text-xs text-primary-100">
                {teachingSkill.skill_details?.name} • Passing threshold: 80% score
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-colors">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
          {error && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 rounded-xl text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {loading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3">
              <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
              <span className="text-xs text-slate-400">Loading tailored assessment questions...</span>
            </div>
          ) : result ? (
            /* Result Banner */
            <div className="text-center space-y-5 py-6">
              <div
                className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${
                  result.outcome === 'verified'
                    ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                    : result.outcome === 'provisional'
                    ? 'bg-amber-100 dark:bg-amber-950 text-amber-600'
                    : 'bg-rose-100 dark:bg-rose-950 text-rose-600'
                }`}
              >
                {result.outcome === 'verified' ? (
                  <CheckCircle2 className="w-9 h-9" />
                ) : result.outcome === 'provisional' ? (
                  <Sparkles className="w-9 h-9" />
                ) : (
                  <AlertCircle className="w-9 h-9" />
                )}
              </div>

              <div>
                <span className="text-3xl font-extrabold text-slate-900 dark:text-white">
                  {result.score}%
                </span>
                <span className="text-xs text-slate-400 block mt-1 uppercase tracking-wider font-semibold">
                  Assessment Score
                </span>
              </div>

              <div className="max-w-md mx-auto p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs leading-relaxed text-slate-700 dark:text-slate-300">
                {result.feedback}
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-semibold text-xs rounded-xl shadow-sm transition-all"
                >
                  Close & View Skill Status
                </button>
              </div>
            </div>
          ) : (
            /* Questions Form */
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-xl text-xs text-amber-800 dark:text-amber-200">
                💡 <strong>Evaluation Standards:</strong> Score 80%+ to unlock verified listing and start accepting sessions at{' '}
                <strong>{teachingSkill.hourly_rate} credits/hr</strong>.
              </div>

              <div className="space-y-6">
                {assessmentData?.questions?.map((q, idx) => (
                  <div
                    key={q.id}
                    className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3"
                  >
                    <div className="flex items-start gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-primary-100 dark:bg-primary-950 text-primary-700 dark:text-primary-300 text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white leading-snug">
                        {q.question_text}
                      </p>
                    </div>

                    {q.question_type === 'mcq' && q.options && (
                      <div className="space-y-2 pt-1 pl-8">
                        {q.options.map((opt) => {
                          const isSelected = answers[q.id]?.selected_option_id === opt.id;
                          return (
                            <label
                              key={opt.id}
                              onClick={() => handleSelectOption(q.id, opt.id)}
                              className={`flex items-start gap-3 p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                                isSelected
                                  ? 'bg-primary-50 dark:bg-primary-950/80 border-primary-500 text-primary-900 dark:text-primary-100 font-medium'
                                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-750'
                              }`}
                            >
                              <span
                                className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 ${
                                  isSelected
                                    ? 'bg-primary-600 text-white'
                                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                                }`}
                              >
                                {opt.id}
                              </span>
                              <span className="leading-relaxed">{opt.text}</span>
                            </label>
                          );
                        })}
                      </div>
                    )}

                    {q.question_type !== 'mcq' && (
                      <div className="pl-8 pt-1">
                        <textarea
                          rows={3}
                          required
                          value={answers[q.id]?.descriptive_response || ''}
                          onChange={(e) => handleTextResponse(q.id, e.target.value)}
                          placeholder="Provide a concise, detailed technical explanation or code example..."
                          className="w-full p-3 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-bold text-xs rounded-xl shadow-md transition-all disabled:opacity-50"
                >
                  {submitting ? 'Evaluating Assessment...' : 'Submit Assessment for Verification'}
                </button>
              </div>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
}
