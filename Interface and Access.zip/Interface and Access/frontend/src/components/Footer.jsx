import React from 'react';
import { Link } from 'react-router-dom';
import { Layers, ShieldCheck, Heart, Github, Twitter, Linkedin, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand & Theme */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-primary-600 flex items-center justify-center text-white">
                <Layers className="w-4 h-4" />
              </div>
              <span className="font-bold text-lg text-slate-900 dark:text-white">SkillSwap</span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Theme 3: Ledger & Money Systems. Student skill exchange platform powered by an internal credit ledger instead of real-money payments.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
              <ShieldCheck className="w-4 h-4" />
              <span>Verified Peer Learning System</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-white mb-3">Platform</h4>
            <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
              <li><Link to="/learn" className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors">Explore Tutors</Link></li>
              <li><Link to="/swaps" className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors">Skill Swaps</Link></li>
              <li><Link to="/teach" className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors">Become a Tutor</Link></li>
              <li><Link to="/wallet" className="hover:text-primary-600 dark:hover:text-primary-400 transition-colors">Credit Ledger</Link></li>
            </ul>
          </div>

          {/* Core Rules */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-white mb-3">Credit Rules</h4>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              <li>• 50 Welcome credits on registration</li>
              <li>• Beginner rate: 10 credits/hr</li>
              <li>• Intermediate rate: 15 credits/hr</li>
              <li>• Advanced rate: 20 credits/hr</li>
              <li>• Direct Skill Swaps: 0 credits</li>
            </ul>
          </div>

          {/* Contact & College Info */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-white mb-3">College Project</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
              Developed as a Full-Stack College Mini Project. Aligned with approved Gate Zero & Gate One problem statements.
            </p>
            <div className="flex items-center gap-3 pt-2 text-slate-400 dark:text-slate-500">
              <span className="text-xs font-medium">Django REST • React Vite • PostgreSQL</span>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-slate-200 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-400 gap-4">
          <p>© {new Date().getFullYear()} SkillSwap Ecosystem. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Built with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" /> for campus peer collaboration
          </p>
        </div>
      </div>
    </footer>
  );
}
