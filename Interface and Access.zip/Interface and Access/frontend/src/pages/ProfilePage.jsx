import React, { useState, useEffect } from 'react';
import {
  User,
  GraduationCap,
  BookOpen,
  Calendar,
  Clock,
  Star,
  Award,
  ShieldCheck,
  Edit2,
  CheckCircle2,
  AlertCircle,
  Plus,
  Coins,
  Sparkles,
  MapPin,
  Building
} from 'lucide-react';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function ProfilePage() {
  const { user, refreshUserData } = useAuth();
  const [profile, setProfile] = useState(null);
  const [teachingSkills, setTeachingSkills] = useState([]);
  const [learningInterests, setLearningInterests] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [availabilities, setAvailabilities] = useState([]);
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState('');

  // Edit form state
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [collegeName, setCollegeName] = useState('');
  const [department, setDepartment] = useState('');
  const [yearOfStudy, setYearOfStudy] = useState('');
  const [bio, setBio] = useState('');
  const [learningGoals, setLearningGoals] = useState('');
  const [teachingMode, setTeachingMode] = useState('online');

  const fetchProfileData = async () => {
    try {
      setLoading(true);
      const [pRes, tsRes, liRes, revRes, avRes, achRes] = await Promise.all([
        client.get('/profiles/me/'),
        client.get('/teaching/my-skills/'),
        client.get('/learning/interests/'),
        user ? client.get(`/reviews/tutor/${user.id}/`) : Promise.resolve({ data: [] }),
        client.get('/profiles/me/availabilities/'),
        client.get('/achievements/')
      ]);

      const prof = pRes.data;
      setProfile(prof);
      setTeachingSkills(tsRes.data || []);
      setLearningInterests(liRes.data || []);
      setReviews(revRes.data || []);
      setAvailabilities(avRes.data || []);
      setAchievements((achRes.data || []).filter((a) => a.is_earned));

      // Populate form
      setFirstName(prof.first_name || '');
      setLastName(prof.last_name || '');
      setCollegeName(prof.profile?.college_name || '');
      setDepartment(prof.profile?.department || '');
      setYearOfStudy(prof.profile?.year_of_study || '2nd Year');
      setBio(prof.profile?.bio || '');
      setLearningGoals(prof.profile?.learning_goals || '');
      setTeachingMode(prof.profile?.teaching_mode || 'online');
    } catch (err) {
      console.error('Failed to load profile data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfileData();
  }, [user]);

  const handleProfileSave = async (e) => {
    e.preventDefault();
    try {
      await client.patch('/profiles/me/', {
        first_name: firstName,
        last_name: lastName,
        college_name: collegeName,
        department,
        year_of_study: yearOfStudy,
        bio,
        learning_goals: learningGoals,
        teaching_mode: teachingMode,
      });
      setSaveSuccess('Profile details successfully updated!');
      setEditing(false);
      fetchProfileData();
      refreshUserData();
      setTimeout(() => setSaveSuccess(''), 4000);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to update profile.');
    }
  };

  const completionScore = profile?.profile?.completion_percentage || 85;

  return (
    <div className="space-y-8">
      {/* Profile Header Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-5">
            {/* Avatar */}
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-primary-600 to-indigo-600 text-white font-black text-2xl flex items-center justify-center shadow-lg shadow-primary-500/20 flex-shrink-0">
              {profile?.first_name ? profile.first_name[0] : profile?.username?.[0]?.toUpperCase()}
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-2.5">
                <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                  {profile?.first_name ? `${profile.first_name} ${profile.last_name || ''}` : profile?.username}
                </h1>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-primary-50 dark:bg-primary-950 text-primary-700 dark:text-primary-300 font-bold border border-primary-200 dark:border-primary-800">
                  {profile?.role?.toUpperCase()}
                </span>
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5" />
                {profile?.profile?.college_name} • {profile?.profile?.department} ({profile?.profile?.year_of_study})
              </p>

              <div className="flex items-center gap-4 text-xs font-semibold pt-1">
                <span className="flex items-center gap-1 text-amber-600">
                  <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                  {profile?.profile?.average_rating || 5.0} Rating ({profile?.profile?.total_reviews || 0} reviews)
                </span>
                <span className="text-slate-300 dark:text-slate-700">|</span>
                <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                  <Coins className="w-3.5 h-3.5" />
                  {profile?.wallet_balance ?? 50} Available Credits
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => setEditing(!editing)}
            className="px-4 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold self-start sm:self-auto flex items-center gap-1.5"
          >
            <Edit2 className="w-3.5 h-3.5" />
            {editing ? 'Cancel Editing' : 'Edit Profile'}
          </button>
        </div>

        {/* Profile Completion Bar (Section 6) */}
        <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-primary-500" />
              Profile Completeness
            </span>
            <span className="text-primary-600 dark:text-primary-400 font-bold">{completionScore}%</span>
          </div>
          <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary-500 to-emerald-500 rounded-full transition-all duration-500"
              style={{ width: `${completionScore}%` }}
            />
          </div>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded-xl text-emerald-800 dark:text-emerald-200 text-xs font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          {saveSuccess}
        </div>
      )}

      {/* Edit Form */}
      {editing && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white mb-4">Update Profile Details</h3>
          <form onSubmit={handleProfileSave} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold mb-1">First Name</label>
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Last Name</label>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-semibold mb-1">College</label>
                <input
                  type="text"
                  value={collegeName}
                  onChange={(e) => setCollegeName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Department</label>
                <input
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Year of Study</label>
                <select
                  value={yearOfStudy}
                  onChange={(e) => setYearOfStudy(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                >
                  <option>1st Year</option>
                  <option>2nd Year</option>
                  <option>3rd Year</option>
                  <option>4th Year</option>
                  <option>Postgraduate</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-semibold mb-1">Bio / Peer Introduction</label>
              <textarea
                rows={2}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1">Personal Learning Goals</label>
              <textarea
                rows={2}
                value={learningGoals}
                onChange={(e) => setLearningGoals(e.target.value)}
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="px-4 py-2 font-semibold text-slate-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-xl"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Middle Grid: Skills Taught & Skills Learning */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Skills Taught */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-primary-600" />
            Skills You Teach
          </h3>

          {teachingSkills.length === 0 ? (
            <p className="text-xs text-slate-400">No teaching skills registered yet.</p>
          ) : (
            <div className="space-y-3">
              {teachingSkills.map((ts) => (
                <div
                  key={ts.id}
                  className="p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between"
                >
                  <div>
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white">
                      {ts.skill_details?.name}
                    </h4>
                    <span className="text-[11px] text-slate-400">
                      {ts.experience_level} • {ts.hourly_rate} credits/hr
                    </span>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      ts.verification_status === 'verified'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}
                  >
                    {ts.verification_status.toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Learning Interests */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-600" />
            Skills You Want to Learn
          </h3>

          {learningInterests.length === 0 ? (
            <p className="text-xs text-slate-400">No learning interests saved yet.</p>
          ) : (
            <div className="space-y-3">
              {learningInterests.map((li) => (
                <div
                  key={li.id}
                  className="p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between"
                >
                  <div>
                    <h4 className="font-bold text-xs text-slate-900 dark:text-white">
                      {li.skill_details?.name}
                    </h4>
                    <span className="text-[11px] text-slate-400">
                      Goal: {li.learning_goals || 'Skill mastery'}
                    </span>
                  </div>

                  <span className="text-[10px] font-semibold px-2 py-0.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-full">
                    {li.preferred_level}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Unlocked Achievements Badges (Section 18) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
          <Award className="w-5 h-5 text-amber-500" />
          Earned Campus Badges ({achievements.length})
        </h3>

        {achievements.length === 0 ? (
          <p className="text-xs text-slate-400">No achievements unlocked yet. Complete your first session to earn a badge!</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {achievements.map((ach) => (
              <div
                key={ach.id}
                className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 text-center space-y-1.5"
              >
                <div className="w-10 h-10 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-600 mx-auto flex items-center justify-center">
                  <Award className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-xs text-slate-900 dark:text-white">{ach.name}</h4>
                <p className="text-[10px] text-slate-400 line-clamp-2">{ach.description}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Tutor Reviews Received */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-white">
          Reviews from Students ({reviews.length})
        </h3>

        {reviews.length === 0 ? (
          <p className="text-xs text-slate-400">No student reviews received yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {reviews.map((rev) => (
              <div
                key={rev.id}
                className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-900 dark:text-white">
                    {rev.reviewer_name}
                  </span>
                  <span className="flex items-center gap-1 font-bold text-amber-500">
                    <Star className="w-3.5 h-3.5 fill-amber-500" />
                    {rev.overall_rating}
                  </span>
                </div>
                <p className="text-slate-600 dark:text-slate-300 italic">
                  "{rev.feedback_comment}"
                </p>
                <span className="text-[10px] text-slate-400 block">
                  Subject: {rev.skill_name} • {new Date(rev.created_at).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
