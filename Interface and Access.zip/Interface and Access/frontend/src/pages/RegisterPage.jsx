import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Layers,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Coins,
  User,
  BookOpen,
  GraduationCap,
  Sliders,
  Check
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [registeredSuccess, setRegisteredSuccess] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    // Step 1: Personal Info
    full_name: '',
    username: '',
    email: '',
    password: '',
    confirm_password: '',
    college_name: 'SkillSwap University',
    department: 'Computer Science & Engineering',
    year_of_study: '2nd Year',
    phone_number: '',

    // Step 2: Learning Interests
    learning_interests: ['Python Programming'],
    preferred_categories: ['Programming', 'Web Development'],
    learning_goals: 'Master core concepts and prepare for technical interviews.',

    // Step 3: Teaching Preferences
    wants_to_teach: true,
    teaching_skills: ['Adobe Photoshop'],
    teaching_experience_level: 'intermediate',
    teaching_experience_duration: '1.5 years',
    teaching_mode: 'online',

    // Step 4: Learning Preferences
    preferred_level: 'beginner',
    preferred_duration_minutes: 60,
  });

  const availableSkillsList = [
    'Python Programming',
    'React.js',
    'Adobe Photoshop',
    'UI/UX in Figma',
    'Java Development',
    'C++ Programming',
    'Data Science with Pandas',
    'Machine Learning Basics',
    'Spanish for Beginners',
    'Public Speaking & Pitching'
  ];

  const categoriesList = [
    'Programming',
    'Web Development',
    'Graphic Design',
    'UI/UX Design',
    'Data Science',
    'Artificial Intelligence',
    'Languages',
    'Communication'
  ];

  const updateField = (field, val) => {
    setFormData((prev) => ({ ...prev, [field]: val }));
    setError('');
  };

  const toggleArrayItem = (field, item) => {
    setFormData((prev) => {
      const current = prev[field] || [];
      if (current.includes(item)) {
        return { ...prev, [field]: current.filter((x) => x !== item) };
      } else {
        return { ...prev, [field]: [...current, item] };
      }
    });
  };

  const handleNext = () => {
    // Validate Step 1
    if (step === 1) {
      if (!formData.full_name.trim() || !formData.username.trim() || !formData.email.trim() || !formData.password) {
        setError('Please fill in all mandatory personal information fields.');
        return;
      }
      if (formData.password.length < 6) {
        setError('Password must be at least 6 characters.');
        return;
      }
      if (formData.password !== formData.confirm_password) {
        setError('Passwords do not match.');
        return;
      }
    }
    setError('');
    setStep((prev) => Math.min(prev + 1, 5));
  };

  const handlePrev = () => {
    setError('');
    setStep((prev) => Math.max(prev - 1, 1));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError('');
      await register(formData);
      setRegisteredSuccess(true);
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);
    } catch (err) {
      const errData = err.response?.data;
      if (typeof errData === 'object') {
        const firstKey = Object.keys(errData)[0];
        const val = errData[firstKey];
        setError(Array.isArray(val) ? val[0] : String(val));
      } else {
        setError('Registration failed. Please check your information.');
      }
    } finally {
      setLoading(false);
    }
  };

  const stepTitles = [
    'Personal Info',
    'Learning Interests',
    'Teaching Preferences',
    'Learning Goals',
    'Review & Submit'
  ];

  return (
    <div className="min-h-[90vh] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-10 shadow-xl">
        {/* Brand Header */}
        <div className="text-center mb-6">
          <Link to="/" className="inline-flex items-center gap-2 mb-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-primary-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-primary-500/20">
              <Layers className="w-5 h-5" />
            </div>
            <span className="font-bold text-xl text-slate-900 dark:text-white">SkillSwap</span>
          </Link>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Join the SkillSwap Network</h2>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800/80 rounded-full text-amber-700 dark:text-amber-300 text-xs font-semibold mt-2">
            <Coins className="w-3.5 h-3.5" />
            Receive 50 SkillSwap Welcome Credits Upon Registration
          </div>
        </div>

        {/* Progress Stepper */}
        <div className="mb-8">
          <div className="flex items-center justify-between relative">
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-slate-100 dark:bg-slate-800 -z-0" />
            {stepTitles.map((title, idx) => {
              const currentStepNum = idx + 1;
              const isDone = currentStepNum < step;
              const isCurrent = currentStepNum === step;
              return (
                <div key={idx} className="flex flex-col items-center relative z-10">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      isDone
                        ? 'bg-emerald-600 text-white'
                        : isCurrent
                        ? 'bg-primary-600 text-white ring-4 ring-primary-100 dark:ring-primary-950'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {isDone ? <Check className="w-4 h-4" /> : currentStepNum}
                  </div>
                  <span className="text-[10px] font-medium text-slate-500 dark:text-slate-400 mt-1 hidden sm:block">
                    {title}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-6 p-3.5 bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900/60 rounded-xl flex items-center gap-2.5 text-rose-700 dark:text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Success Banner */}
        {registeredSuccess && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-6 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded-2xl text-center space-y-2 mb-6"
          >
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
            <h3 className="text-lg font-bold text-emerald-800 dark:text-emerald-200">Registration Successful!</h3>
            <p className="text-xs text-emerald-700 dark:text-emerald-300">
              50 SkillSwap welcome credits have been created in your wallet. Redirecting to your student dashboard...
            </p>
          </motion.div>
        )}

        {/* Step Forms */}
        {!registeredSuccess && (
          <form onSubmit={handleSubmit} className="space-y-6">
            <AnimatePresence mode="wait">
              {/* STEP 1: Personal Info */}
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="space-y-4"
                >
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
                    Step 1: Student Information
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.full_name}
                        onChange={(e) => updateField('full_name', e.target.value)}
                        placeholder="e.g. Maya Krishnan"
                        className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Username *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.username}
                        onChange={(e) => updateField('username', e.target.value)}
                        placeholder="e.g. mayak"
                        className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      College Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => updateField('email', e.target.value)}
                      placeholder="e.g. maya@student.edu"
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Password *
                      </label>
                      <input
                        type="password"
                        required
                        value={formData.password}
                        onChange={(e) => updateField('password', e.target.value)}
                        placeholder="Min. 6 characters"
                        className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Confirm Password *
                      </label>
                      <input
                        type="password"
                        required
                        value={formData.confirm_password}
                        onChange={(e) => updateField('confirm_password', e.target.value)}
                        placeholder="Re-type password"
                        className="w-full px-3.5 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        College / University
                      </label>
                      <input
                        type="text"
                        value={formData.college_name}
                        onChange={(e) => updateField('college_name', e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Department
                      </label>
                      <input
                        type="text"
                        value={formData.department}
                        onChange={(e) => updateField('department', e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Year of Study
                      </label>
                      <select
                        value={formData.year_of_study}
                        onChange={(e) => updateField('year_of_study', e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                      >
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                        <option>Postgraduate</option>
                      </select>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* STEP 2: Learning Interests */}
              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="space-y-4"
                >
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
                    Step 2: What do you want to learn?
                  </h3>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Select Preferred Categories:
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {categoriesList.map((cat) => {
                        const selected = formData.preferred_categories.includes(cat);
                        return (
                          <button
                            type="button"
                            key={cat}
                            onClick={() => toggleArrayItem('preferred_categories', cat)}
                            className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                              selected
                                ? 'bg-primary-600 text-white border-primary-600 font-semibold'
                                : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            {cat}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                      Specific Skills You Want to Learn:
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {availableSkillsList.map((skill) => {
                        const selected = formData.learning_interests.includes(skill);
                        return (
                          <button
                            type="button"
                            key={skill}
                            onClick={() => toggleArrayItem('learning_interests', skill)}
                            className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                              selected
                                ? 'bg-accent-600 text-white border-accent-600 font-semibold'
                                : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            {skill}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Your Learning Goals
                    </label>
                    <textarea
                      rows={2}
                      value={formData.learning_goals}
                      onChange={(e) => updateField('learning_goals', e.target.value)}
                      placeholder="e.g. Want to understand machine learning algorithms for my final year project."
                      className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                  </div>
                </motion.div>
              )}

              {/* STEP 3: Teaching Preferences */}
              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="space-y-4"
                >
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
                    Step 3: Peer Teaching Preferences
                  </h3>

                  <div className="p-3 bg-primary-50 dark:bg-primary-950/60 rounded-xl flex items-center justify-between border border-primary-100 dark:border-primary-900">
                    <div>
                      <span className="text-xs font-semibold text-primary-900 dark:text-primary-100 block">
                        Do you want to teach other students?
                      </span>
                      <span className="text-[11px] text-primary-600 dark:text-primary-400">
                        Earn 10 to 20 credits per hour by teaching peers.
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={formData.wants_to_teach}
                      onChange={(e) => updateField('wants_to_teach', e.target.checked)}
                      className="w-5 h-5 text-primary-600 rounded border-slate-300 focus:ring-primary-500"
                    />
                  </div>

                  {formData.wants_to_teach && (
                    <div className="space-y-4 pt-2">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                          Skills You Are Confident Teaching:
                        </label>
                        <div className="flex flex-wrap gap-2">
                          {availableSkillsList.map((skill) => {
                            const selected = formData.teaching_skills.includes(skill);
                            return (
                              <button
                                type="button"
                                key={skill}
                                onClick={() => toggleArrayItem('teaching_skills', skill)}
                                className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                                  selected
                                    ? 'bg-primary-600 text-white border-primary-600 font-semibold'
                                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                                }`}
                              >
                                {skill}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                            Experience Level
                          </label>
                          <select
                            value={formData.teaching_experience_level}
                            onChange={(e) => updateField('teaching_experience_level', e.target.value)}
                            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                          >
                            <option value="beginner">Beginner (10 cr/hr)</option>
                            <option value="intermediate">Intermediate (15 cr/hr)</option>
                            <option value="advanced">Advanced (20 cr/hr)</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                            Duration of Experience
                          </label>
                          <input
                            type="text"
                            value={formData.teaching_experience_duration}
                            onChange={(e) => updateField('teaching_experience_duration', e.target.value)}
                            placeholder="e.g. 1 year"
                            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                            Teaching Mode
                          </label>
                          <select
                            value={formData.teaching_mode}
                            onChange={(e) => updateField('teaching_mode', e.target.value)}
                            className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                          >
                            <option value="online">Online</option>
                            <option value="offline">Offline (On Campus)</option>
                            <option value="hybrid">Hybrid</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}

              {/* STEP 4: Learning Preferences */}
              {step === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="space-y-4"
                >
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
                    Step 4: Learning Preferences
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Preferred Starting Level
                      </label>
                      <select
                        value={formData.preferred_level}
                        onChange={(e) => updateField('preferred_level', e.target.value)}
                        className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      >
                        <option value="beginner">Beginner (Foundations)</option>
                        <option value="intermediate">Intermediate (Hands-on)</option>
                        <option value="advanced">Advanced (Deep Dive)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Preferred Session Duration
                      </label>
                      <select
                        value={formData.preferred_duration_minutes}
                        onChange={(e) => updateField('preferred_duration_minutes', Number(e.target.value))}
                        className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                      >
                        <option value={45}>45 Minutes</option>
                        <option value={60}>60 Minutes (Standard)</option>
                        <option value={90}>90 Minutes</option>
                        <option value={120}>120 Minutes (Workshop)</option>
                      </select>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-400 space-y-1">
                    <p className="font-semibold text-slate-800 dark:text-slate-200">How sessions work:</p>
                    <p>• You can browse tutors in the Learn catalog and request customized 1:1 sessions.</p>
                    <p>• Credits are held in escrow safely until both you and the tutor confirm completion.</p>
                    <p>• Or, find a mutual match in the Skill Swap tab and learn for zero credits!</p>
                  </div>
                </motion.div>
              )}

              {/* STEP 5: Review & Submit */}
              {step === 5 && (
                <motion.div
                  key="step5"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="space-y-4"
                >
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
                    Step 5: Review Registration Details
                  </h3>

                  <div className="space-y-3 text-xs bg-slate-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-slate-200 dark:border-slate-700">
                    <div className="flex justify-between py-1 border-b border-slate-200/60 dark:border-slate-700/60">
                      <span className="text-slate-500">Full Name:</span>
                      <span className="font-semibold text-slate-900 dark:text-white">{formData.full_name}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-200/60 dark:border-slate-700/60">
                      <span className="text-slate-500">Username:</span>
                      <span className="font-semibold text-slate-900 dark:text-white">{formData.username}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-200/60 dark:border-slate-700/60">
                      <span className="text-slate-500">College & Dept:</span>
                      <span className="font-semibold text-slate-900 dark:text-white">{formData.college_name} ({formData.department})</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-200/60 dark:border-slate-700/60">
                      <span className="text-slate-500">Learning Interests:</span>
                      <span className="font-semibold text-accent-600 dark:text-accent-400">
                        {formData.learning_interests.join(', ') || 'General Exploration'}
                      </span>
                    </div>
                    {formData.wants_to_teach && (
                      <div className="flex justify-between py-1 border-b border-slate-200/60 dark:border-slate-700/60">
                        <span className="text-slate-500">Teaching Skills:</span>
                        <span className="font-semibold text-primary-600 dark:text-primary-400">
                          {formData.teaching_skills.join(', ')} ({formData.teaching_experience_level})
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between py-1 text-emerald-600 dark:text-emerald-400 font-bold">
                      <span>Initial Credit Wallet Grant:</span>
                      <span>50 Credits</span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Stepper Controls */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
              {step > 1 ? (
                <button
                  type="button"
                  onClick={handlePrev}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Back
                </button>
              ) : <div />}

              {step < 5 ? (
                <button
                  type="button"
                  onClick={handleNext}
                  className="px-5 py-2.5 bg-primary-600 hover:bg-primary-700 text-white text-xs font-semibold rounded-xl shadow-sm transition-all flex items-center gap-1.5"
                >
                  Continue
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-2 disabled:opacity-50"
                >
                  {loading ? 'Creating Account...' : 'Complete Registration & Claim 50 Credits'}
                </button>
              )}
            </div>
          </form>
        )}

        {/* Footer Link */}
        <p className="text-center text-xs text-slate-500 dark:text-slate-400 mt-6">
          Already registered?{' '}
          <Link to="/login" className="font-semibold text-primary-600 dark:text-primary-400 hover:underline">
            Sign In here
          </Link>
        </p>
      </div>
    </div>
  );
}
