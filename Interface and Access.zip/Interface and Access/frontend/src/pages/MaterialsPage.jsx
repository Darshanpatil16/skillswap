import React, { useState, useEffect } from 'react';
import {
  FileText,
  Upload,
  Download,
  ExternalLink,
  BookOpen,
  Filter,
  CheckCircle2,
  AlertCircle,
  Plus,
  FileCode,
  FileSpreadsheet,
  Image,
  Link as LinkIcon
} from 'lucide-react';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function MaterialsPage() {
  const { user } = useAuth();
  const [materials, setMaterials] = useState([]);
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');

  // Upload Form
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [skillId, setSkillId] = useState('');
  const [materialType, setMaterialType] = useState('pdf');
  const [externalLink, setExternalLink] = useState('');
  const [file, setFile] = useState(null);
  const [isPublic, setIsPublic] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');

  const fetchMaterials = async () => {
    try {
      setLoading(true);
      const [mRes, sRes] = await Promise.all([
        client.get('/materials/'),
        client.get('/skills/')
      ]);
      setMaterials(mRes.data || []);
      setSkills(sRes.data || []);
      if (sRes.data?.length > 0 && !skillId) {
        setSkillId(sRes.data[0].id);
      }
    } catch (err) {
      console.error('Failed to load materials', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMaterials();
  }, []);

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim() || !skillId) {
      setUploadError('Please provide a title and select a skill.');
      return;
    }
    if (!file && !externalLink.trim()) {
      setUploadError('Please select a file to upload or enter an external link.');
      return;
    }

    try {
      setUploading(true);
      setUploadError('');

      const formData = new FormData();
      formData.append('title', title);
      formData.append('description', description);
      formData.append('skill', skillId);
      formData.append('material_type', materialType);
      formData.append('is_public', isPublic);
      if (externalLink) formData.append('external_link', externalLink);
      if (file) formData.append('file', file);

      await client.post('/materials/', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      setStatusMessage('Learning resource uploaded successfully!');
      setShowUploadModal(false);
      setTitle('');
      setDescription('');
      setExternalLink('');
      setFile(null);
      fetchMaterials();
      setTimeout(() => setStatusMessage(''), 4000);
    } catch (err) {
      setUploadError(err.response?.data?.error || 'Failed to upload material.');
    } finally {
      setUploading(false);
    }
  };

  const getIconForType = (type) => {
    switch (type) {
      case 'pdf':
        return FileText;
      case 'presentation':
        return FileSpreadsheet;
      case 'code':
        return FileCode;
      case 'image':
        return Image;
      default:
        return LinkIcon;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <BookOpen className="w-8 h-8 text-primary-600" />
            Learning Materials Repository
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Access slides, cheatsheets, notebooks, and reference materials shared by verified tutors.
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="px-4 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-semibold text-xs shadow-sm transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Share Resource
        </button>
      </div>

      {statusMessage && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded-xl text-emerald-800 dark:text-emerald-200 text-xs font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          {statusMessage}
        </div>
      )}

      {/* Materials List */}
      {loading ? (
        <div className="py-16 text-center text-xs text-slate-400">Loading resources...</div>
      ) : materials.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <FileText className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-semibold text-sm text-slate-700 dark:text-slate-300">No learning materials found</h3>
          <p className="text-xs text-slate-400">Tutors can upload session guides and notes here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {materials.map((m) => {
            const Icon = getIconForType(m.material_type);
            return (
              <div
                key={m.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-primary-50 dark:bg-primary-950 text-primary-600 dark:text-primary-400 flex items-center justify-center">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 uppercase">
                      {m.material_type}
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-slate-900 dark:text-white leading-snug">
                    {m.title}
                  </h3>
                  <p className="text-xs font-semibold text-primary-600 dark:text-primary-400 mt-1">
                    {m.skill_name}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 line-clamp-2">
                    {m.description || 'Shared learning reference material.'}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <span>By {m.uploader_name}</span>
                  {m.external_link ? (
                    <a
                      href={m.external_link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary-600 dark:text-primary-400 font-semibold hover:underline flex items-center gap-1"
                    >
                      Open Link <ExternalLink className="w-3 h-3" />
                    </a>
                  ) : m.file_url ? (
                    <a
                      href={m.file_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      download
                      className="text-primary-600 dark:text-primary-400 font-semibold hover:underline flex items-center gap-1"
                    >
                      Download <Download className="w-3 h-3" />
                    </a>
                  ) : (
                    <span>Available in session</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Upload Resource Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Share a Learning Resource
              </h3>
              <button onClick={() => setShowUploadModal(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            {uploadError && (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                <span>{uploadError}</span>
              </div>
            )}

            <form onSubmit={handleUploadSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Python Quick Reference Cheatsheet"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Skill *</label>
                <select
                  required
                  value={skillId}
                  onChange={(e) => setSkillId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                >
                  {skills.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Type</label>
                  <select
                    value={materialType}
                    onChange={(e) => setMaterialType(e.target.value)}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  >
                    <option value="pdf">PDF Document</option>
                    <option value="presentation">Presentation (PPTX)</option>
                    <option value="code">Code / Notebook</option>
                    <option value="image">Diagram / Image</option>
                    <option value="link">Web Resource</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Visibility</label>
                  <select
                    value={isPublic ? 'true' : 'false'}
                    onChange={(e) => setIsPublic(e.target.value === 'true')}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  >
                    <option value="true">Public to all students</option>
                    <option value="false">Session participants only</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">External Resource Link</label>
                <input
                  type="url"
                  value={externalLink}
                  onChange={(e) => setExternalLink(e.target.value)}
                  placeholder="https://docs.python.org or shared Google Drive"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Upload File (Max 10MB)</label>
                <input
                  type="file"
                  onChange={(e) => setFile(e.target.files[0])}
                  className="w-full p-2 text-xs bg-slate-50 dark:bg-slate-800 border rounded-xl file:mr-3 file:py-1 file:px-2 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-primary-50 file:text-primary-700"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploading}
                  className="px-5 py-2 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-xl"
                >
                  {uploading ? 'Uploading...' : 'Publish Material'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
