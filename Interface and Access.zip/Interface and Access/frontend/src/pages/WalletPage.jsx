import React, { useState, useEffect } from 'react';
import {
  Wallet,
  Coins,
  ArrowUpRight,
  ArrowDownLeft,
  RefreshCw,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  FileText,
  Filter
} from 'lucide-react';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function WalletPage() {
  const { user } = useAuth();
  const [wallet, setWallet] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState('all');

  const fetchWalletData = async () => {
    try {
      setLoading(true);
      const params = activeFilter !== 'all' ? `?type=${activeFilter}` : '';
      const [wRes, txRes] = await Promise.all([
        client.get('/wallet/'),
        client.get(`/wallet/transactions/${params}`)
      ]);
      setWallet(wRes.data);
      setTransactions(txRes.data || []);
    } catch (err) {
      console.error('Error fetching wallet data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWalletData();
  }, [activeFilter]);

  const filterTabs = [
    { id: 'all', label: 'All Transactions' },
    { id: 'earned', label: 'Credits Earned' },
    { id: 'spent', label: 'Credits Spent' },
    { id: 'escrow', label: 'Held in Escrow' },
    { id: 'refund', label: 'Refunds' },
    { id: 'bonus', label: 'Welcome Bonus' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <Wallet className="w-8 h-8 text-amber-500" />
            Credit Wallet & Ledger System
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Theme 3: Ledger and Money Systems • Immutable campus transaction ledger.
          </p>
        </div>

        <button
          onClick={fetchWalletData}
          className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors self-start sm:self-auto flex items-center gap-2 text-xs font-semibold"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh Ledger
        </button>
      </div>

      {/* Wallet Passbook Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Digital Credit Passbook Card */}
        <div className="lg:col-span-1 bg-gradient-to-tr from-slate-900 via-indigo-950 to-primary-950 text-white rounded-3xl p-6 sm:p-7 shadow-xl relative overflow-hidden flex flex-col justify-between space-y-6">
          <div className="flex items-center justify-between relative z-10">
            <span className="text-xs font-bold uppercase tracking-wider text-primary-300">
              SkillSwap Credit Ledger
            </span>
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
              <Coins className="w-5 h-5 text-amber-400" />
            </div>
          </div>

          <div className="relative z-10 space-y-1">
            <span className="text-xs text-slate-400 font-medium">Available Balance</span>
            <div className="text-4xl font-extrabold tracking-tight">
              {wallet?.available_balance ?? 50}{' '}
              <span className="text-sm font-semibold text-amber-400">Credits</span>
            </div>
          </div>

          <div className="relative z-10 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-slate-300">
            <div>
              <span className="block text-[10px] text-slate-400">Student Account</span>
              <span className="font-semibold">{user?.username}</span>
            </div>
            <div className="text-right">
              <span className="block text-[10px] text-slate-400">Escrow Reserved</span>
              <span className="font-semibold text-amber-300">{wallet?.escrow_balance || 0} Credits</span>
            </div>
          </div>
        </div>

        {/* 3 Analytics Summary Cards */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Reserved Escrow Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Escrow Balance</span>
              <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900 dark:text-white">
              {wallet?.escrow_balance || 0}
            </div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Held safely for scheduled sessions until mutual confirmation.
            </p>
          </div>

          {/* Total Earned Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Total Credits Earned</span>
              <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center">
                <ArrowDownLeft className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
              +{wallet?.total_earned || 0}
            </div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Earned by conducting verified peer teaching sessions.
            </p>
          </div>

          {/* Total Spent Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500 font-medium">Total Credits Spent</span>
              <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center">
                <ArrowUpRight className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-bold text-slate-900 dark:text-white">
              {wallet?.total_spent || 0}
            </div>
            <p className="text-[11px] text-slate-400 leading-tight">
              Invested into learning from skilled peer tutors.
            </p>
          </div>
        </div>
      </div>

      {/* Transaction History & Immutable Ledger Table (Section 13) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary-600" />
              Immutable Transaction Ledger
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Every credit movement is cryptographically audited and stored in the backend database.
            </p>
          </div>

          {/* Filters Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveFilter(tab.id)}
                className={`px-3 py-1.5 rounded-xl font-medium transition-all flex-shrink-0 ${
                  activeFilter === tab.id
                    ? 'bg-primary-600 text-white font-semibold shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Ledger Table */}
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-400">Loading ledger records...</div>
        ) : transactions.length === 0 ? (
          <div className="py-10 text-center text-xs text-slate-400">
            No transactions found under this category filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-3">Transaction ID</th>
                  <th className="py-3 px-3">Type</th>
                  <th className="py-3 px-3">Party</th>
                  <th className="py-3 px-3">Amount</th>
                  <th className="py-3 px-3">Balance Snapshot</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3">Date & Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {transactions.map((tx) => {
                  const isReceiver = tx.receiver === user?.id;
                  const isSender = tx.sender === user?.id;

                  return (
                    <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                      {/* UUID */}
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-500">
                        {tx.transaction_id.slice(0, 8)}...
                      </td>

                      {/* Type */}
                      <td className="py-3 px-3">
                        <span className="font-semibold text-slate-900 dark:text-white block">
                          {tx.transaction_type_display}
                        </span>
                        <span className="text-[10px] text-slate-400 truncate max-w-xs block">
                          {tx.description}
                        </span>
                      </td>

                      {/* Parties */}
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-300">
                        {isReceiver ? `From: ${tx.sender_name}` : `To: ${tx.receiver_name}`}
                      </td>

                      {/* Amount */}
                      <td className="py-3 px-3 font-bold">
                        <span
                          className={
                            isReceiver
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-slate-700 dark:text-slate-300'
                          }
                        >
                          {isReceiver ? `+${tx.amount}` : `-${tx.amount}`} Credits
                        </span>
                      </td>

                      {/* Balance Snapshot (Previous -> Updated) */}
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-500">
                        {isReceiver ? (
                          <span>{tx.receiver_previous_balance ?? 0} → {tx.receiver_updated_balance ?? 0}</span>
                        ) : (
                          <span>{tx.sender_previous_balance ?? 0} → {tx.sender_updated_balance ?? 0}</span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            tx.status === 'completed'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : tx.status === 'pending'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          }`}
                        >
                          {tx.status_display}
                        </span>
                      </td>

                      {/* Timestamp */}
                      <td className="py-3 px-3 text-slate-400 whitespace-nowrap">
                        {new Date(tx.timestamp).toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
