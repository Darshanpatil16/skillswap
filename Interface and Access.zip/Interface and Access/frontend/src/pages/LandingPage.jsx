import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  ShieldCheck,
  Coins,
  Repeat,
  Users,
  CheckCircle2,
  BookOpen,
  Code,
  Globe,
  Palette,
  Layout,
  BarChart2,
  Cpu,
  MessageSquare,
  Sparkles,
  Award,
  Video
} from 'lucide-react';
import client from '../api/client';

export default function LandingPage() {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await client.get('/skills/categories/');
        setCategories(res.data);
      } catch (err) {
        // fallback
      }
    };
    fetchCategories();
  }, []);

  const steps = [
    {
      num: '01',
      title: 'Create Your Profile',
      desc: 'Sign up in minutes. Receive 50 SkillSwap credits immediately in your personal credit wallet.',
      icon: Users,
    },
    {
      num: '02',
      title: 'Verify & Share Your Skills',
      desc: 'Register skills you are confident teaching and complete a dynamic peer verification assessment.',
      icon: ShieldCheck,
    },
    {
      num: '03',
      title: 'Teach & Earn Credits',
      desc: 'Accept requests from peers, conduct structured sessions, and earn 10 to 20 credits per hour.',
      icon: Coins,
    },
    {
      num: '04',
      title: 'Learn Using Credits or Swaps',
      desc: 'Spend your earned credits on subjects you want to learn, or do a direct 0-credit skill swap.',
      icon: Repeat,
    },
  ];

  const popularCategories = [
    { name: 'Programming', icon: Code, count: 'Python, Java, C++' },
    { name: 'Web Development', icon: Globe, count: 'React, Django, Node' },
    { name: 'Graphic Design', icon: Palette, count: 'Photoshop, Illustrator' },
    { name: 'UI/UX Design', icon: Layout, count: 'Figma, Wireframing' },
    { name: 'Data Science', icon: BarChart2, count: 'Pandas, Visualization' },
    { name: 'Artificial Intelligence', icon: Cpu, count: 'Machine Learning, NLP' },
    { name: 'Languages', icon: MessageSquare, count: 'Spanish, French, English' },
    { name: 'Communication', icon: Award, count: 'Public Speaking, Pitching' },
  ];

  const whyChooseUs = [
    {
      title: 'No Real-Money Payments',
      desc: 'Completely cashless campus economy. Powered by an internal, transparent double-entry credit ledger.',
      icon: Coins,
    },
    {
      title: 'Verified Peer Tutors',
      desc: 'Every tutor completes a dynamic subject assessment before publishing. No fabricated credentials.',
      icon: ShieldCheck,
    },
    {
      title: 'Earn Credits by Teaching',
      desc: 'Monetize your knowledge into credits. Top tutors build a strong campus reputation and rating.',
      icon: Award,
    },
    {
      title: 'Direct Skill Swaps',
      desc: 'Trade 1:1 learning time directly (e.g. Python for Photoshop) with zero credits required.',
      icon: Repeat,
    },
    {
      title: 'Safe Escrow Protection',
      desc: 'Credits are locked in escrow and released only upon mutual completion confirmation by both students.',
      icon: Sparkles,
    },
  ];

  return (
    <div className="space-y-24 py-8">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 sm:pt-16 pb-12 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary-50 dark:bg-primary-950/80 border border-primary-200 dark:border-primary-800 text-primary-700 dark:text-primary-300 text-xs font-semibold mb-6"
        >
          <Sparkles className="w-4 h-4 text-primary-500" />
          Theme 3: Ledger and Money Systems • College Mini Project
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white max-w-4xl mx-auto leading-tight"
        >
          Learn Together. <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-600 via-indigo-600 to-primary-500">Grow Together.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mt-6 text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed"
        >
          Share what you know, discover new skills and exchange knowledge using SkillSwap credits. Learning becomes easier when students learn from each other.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-4"
        >
          <Link
            to="/register"
            className="px-6 py-3.5 text-sm sm:text-base font-semibold text-white bg-primary-600 hover:bg-primary-700 rounded-xl shadow-lg shadow-primary-500/25 transition-all flex items-center gap-2"
          >
            Get Started (50 Free Credits)
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            to="/learn"
            className="px-6 py-3.5 text-sm sm:text-base font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs transition-all"
          >
            Explore Skills
          </Link>
        </motion.div>

        {/* Live Metrics Ribbon */}
        <div className="mt-14 pt-8 border-t border-slate-200/80 dark:border-slate-800/80 max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div>
            <span className="block text-2xl sm:text-3xl font-extrabold text-primary-600 dark:text-primary-400">50</span>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Welcome Credits</span>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">100%</span>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Verified Tutors</span>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-extrabold text-accent-600 dark:text-accent-400">0</span>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Real Money Required</span>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">Escrow</span>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Safe Credit Release</span>
          </div>
        </div>
      </section>

      {/* Section A: About SkillSwap */}
      <section id="about-us" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 sm:p-12 shadow-sm">
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-primary-600 dark:text-primary-400">About SkillSwap</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">
              The Campus Knowledge Sharing Problem & Our Solution
            </h2>
            <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
              Many students possess valuable skills in coding, design, and academics, but lack an organized platform to teach peers and learn from each other. Commercial platforms demand real-money payments that students cannot afford.
            </p>
            <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
              SkillSwap eliminates cash by establishing an internal credit ledger system. Students earn credits when teaching, spend credits to learn, or perform direct 1:1 skill swaps. Every contribution is verified, recognized, and rewarded.
            </p>
          </div>
        </div>
      </section>

      {/* Section B: How It Works */}
      <section id="how-it-works" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-3 mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-primary-600 dark:text-primary-400">Simple 4-Step Process</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">How SkillSwap Works</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
            From creating your student profile to exchanging knowledge through credits.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={idx}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 relative group hover:border-primary-400 dark:hover:border-primary-600 transition-all shadow-xs"
              >
                <span className="text-3xl font-black text-slate-200 dark:text-slate-800 absolute top-5 right-5">
                  {step.num}
                </span>
                <div className="w-12 h-12 rounded-xl bg-primary-50 dark:bg-primary-950/70 text-primary-600 dark:text-primary-400 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white mb-2">{step.title}</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{step.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Section C: Popular Skill Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-3 mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-primary-600 dark:text-primary-400">Explore Subjects</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">Popular Skill Categories</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
            Discover verified peer tutors across technological, creative, and academic disciplines.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {popularCategories.map((cat, idx) => {
            const Icon = cat.icon;
            return (
              <Link
                key={idx}
                to={`/learn?q=${encodeURIComponent(cat.name)}`}
                className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:border-primary-500 dark:hover:border-primary-500 transition-all group flex flex-col items-center text-center shadow-xs"
              >
                <div className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 group-hover:bg-primary-50 dark:group-hover:bg-primary-950/80 text-slate-700 dark:text-slate-300 group-hover:text-primary-600 dark:group-hover:text-primary-400 flex items-center justify-center mb-3 transition-colors">
                  <Icon className="w-6 h-6" />
                </div>
                <h4 className="font-semibold text-sm text-slate-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                  {cat.name}
                </h4>
                <span className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">{cat.count}</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Section D: Why SkillSwap? */}
      <section id="why-skillswap" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-3 mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-primary-600 dark:text-primary-400">Core Advantages</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white">Why SkillSwap?</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
            Designed specifically for student budgets and authentic peer collaboration.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {whyChooseUs.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xs space-y-3"
              >
                <div className="w-10 h-10 rounded-xl bg-accent-50 dark:bg-accent-950/60 text-accent-600 dark:text-accent-400 flex items-center justify-center">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="font-semibold text-base text-slate-900 dark:text-white">{item.title}</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Section E: Call to Action */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="bg-gradient-to-r from-primary-600 via-indigo-600 to-primary-700 rounded-3xl p-8 sm:p-14 text-center text-white shadow-xl relative overflow-hidden">
          <div className="absolute -top-24 -right-24 w-72 h-72 bg-white/10 rounded-full blur-2xl pointer-events-none" />
          <div className="max-w-2xl mx-auto space-y-6 relative z-10">
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
              Your skills have value. Start sharing them today.
            </h2>
            <p className="text-primary-100 text-sm sm:text-base leading-relaxed">
              Join your campus peer network, earn your initial 50 credits, and unlock a trusted environment to teach and learn.
            </p>
            <div>
              <Link
                to="/register"
                className="inline-flex items-center gap-2 px-8 py-3.5 bg-white text-primary-700 hover:bg-primary-50 rounded-xl font-bold text-sm shadow-md transition-all hover:scale-105"
              >
                Create Student Account
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
