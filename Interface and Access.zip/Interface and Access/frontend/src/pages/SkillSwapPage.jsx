import React, { useState, useEffect } from 'react';
import {
  Repeat,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Calendar,
  AlertCircle,
  X,
  Star,
  Users
} from 'lucide-react';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function SkillSwapPage() {
  const { user, refreshUserData } = useAuth();
  const [mutualMatches, setMutualMatches] = useState([]);
  const [swapsList, setSwapsList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionMessage, setActionMessage] = useState('');

  // Swap Invite Modal
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [swapDate, setSwapDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });
  const [swapTime, setSwapTime] = useState('17:00');
  const [swapMessage, setSwapMessage] = useState('Hey! Let us exchange skills directly (zero credits needed)!');
  const [inviting, setInviting] = useState(false);
  const [inviteError, setInviteError] = useState('');

  const fetchSwapData = async () => {
    try {
      setLoading(true);
      const [matchesRes, swapsRes] = await Promise.all([
        client.get('/swaps/mutual-matches/'),
        client.get('/swaps/')
      ]);
      setMutualMatches(matchesRes.data || []);
      setSwapsList(swapsRes.data || []);
    } catch (err) {
      console.error('Error fetching swaps data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSwapData();
  }, []);

  const handleSendSwapInvite = async (e) => {
    e.preventDefault();
    if (!selectedMatch) return;

    try {
      setInviting(true);
      setInviteError('');

      const payload = {
        receiver_id: selectedMatch.peer_id,
        initiator_skill_offered_id: selectedMatch.skill_you_teach_them.id,
        receiver_skill_requested_id: selectedMatch.skill_they_teach.id,
        scheduled_date: swapDate,
        start_time: `${swapTime}:00`,
        session_duration_minutes: 60,
        message: swapMessage,
      };

      await client.post('/swaps/', payload);
      setActionMessage(`Skill Swap invitation sent to ${selectedMatch.peer_username}!`);
      setSelectedMatch(null);
      fetchSwapData();
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err) {
      setInviteError(err.response?.data?.error || 'Failed to send swap invitation.');
    } finally {
      setInviting(false);
    }
  };

  const handleSwapAction = async (swapId, action) => {
    try {
      await client.patch(`/swaps/${swapId}/${action}/`);
      setActionMessage(`Skill swap marked as ${action}ed.`);
      fetchSwapData();
      refreshUserData();
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err) {
      alert(err.response?.data?.error || `Failed to ${action} swap.`);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
          <Repeat className="w-8 h-8 text-primary-600" />
          Direct Skill Swap
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Exchange learning time 1:1 with peers who teach what you want to learn.
        </p>
      </div>

      {/* Info Ribbon (Section 12) */}
      <div className="p-5 bg-gradient-to-r from-emerald-900 to-teal-950 text-white rounded-3xl shadow-sm space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            Zero-Credit Mutual Exchange
          </span>
          <span className="text-[11px] text-emerald-200">Balanced Learning Barter</span>
        </div>
        <p className="text-xs text-emerald-100 max-w-2xl leading-relaxed">
          When two students teach complementary skills (e.g. you teach Photoshop and learn Python from your peer), SkillSwap allows a direct exchange with <strong>0 credits transferred</strong>!
        </p>
      </div>

      {actionMessage && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded-xl text-emerald-800 dark:text-emerald-200 text-xs font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          {actionMessage}
        </div>
      )}

      {/* Section 1: Discovered Mutual Matches */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-5 h-5 text-primary-600" />
            Discovered Mutual Matches ({mutualMatches.length})
          </h2>
          <span className="text-xs text-slate-400">Automated match detection</span>
        </div>

        {mutualMatches.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 rounded-3xl p-8 text-center space-y-2">
            <Repeat className="w-8 h-8 text-slate-300 mx-auto" />
            <p className="text-xs text-slate-400">
              No mutual complementary matches found currently. Add more skills to your teaching list or learning interests to unlock automated barter matches!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {mutualMatches.map((match, idx) => (
              <div
                key={idx}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                        {match.peer_full_name}
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        {match.peer_college} • {match.peer_department}
                      </p>
                    </div>

                    <span className="px-2.5 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded-full text-[10px] font-bold">
                      0 Credits
                    </span>
                  </div>

                  {/* Trade Exchange Box */}
                  <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">They Teach You:</span>
                      <span className="font-bold text-primary-600 dark:text-primary-400">
                        {match.skill_they_teach.name}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">You Teach Them:</span>
                      <span className="font-bold text-accent-600 dark:text-accent-400">
                        {match.skill_you_teach_them.name}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-end">
                  <button
                    onClick={() => setSelectedMatch(match)}
                    className="px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    Propose Skill Swap
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Section 2: My Skill Swap Requests & Active Barters */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
        <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Calendar className="w-5 h-5 text-indigo-500" />
          Active Skill Swaps ({swapsList.length})
        </h2>

        {swapsList.length === 0 ? (
          <p className="text-xs text-slate-400 py-3">No active skill swap records yet.</p>
        ) : (
          <div className="space-y-3">
            {swapsList.map((swap) => {
              const isInitiator = swap.initiator === user?.id;
              const peerName = isInitiator ? swap.receiver_details?.username : swap.initiator_details?.username;
              return (
                <div
                  key={swap.id}
                  className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-900 dark:text-white">
                        {swap.offered_skill_details?.name} ⟷ {swap.requested_skill_details?.name}
                      </span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          swap.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : swap.status === 'accepted'
                            ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {swap.status_display}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Partner: {peerName} • {swap.scheduled_date || 'Date TBD'} • Zero credits
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {swap.status === 'pending' && !isInitiator && (
                      <>
                        <button
                          onClick={() => handleSwapAction(swap.id, 'accept')}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold"
                        >
                          Accept
                        </button>
                        <button
                          onClick={() => handleSwapAction(swap.id, 'reject')}
                          className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-rose-100 hover:text-rose-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium"
                        >
                          Decline
                        </button>
                      </>
                    )}

                    {swap.status === 'accepted' && (
                      <button
                        onClick={() => handleSwapAction(swap.id, 'complete')}
                        className="px-3.5 py-1.5 bg-primary-600 hover:bg-primary-700 text-white rounded-lg text-xs font-semibold"
                      >
                        Confirm Completion
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Propose Swap Modal */}
      {selectedMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Propose Direct Skill Swap
              </h3>
              <button onClick={() => setSelectedMatch(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {inviteError && (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                <span>{inviteError}</span>
              </div>
            )}

            <form onSubmit={handleSendSwapInvite} className="space-y-4 text-xs">
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1">
                <p>Partner: <strong>{selectedMatch.peer_full_name}</strong></p>
                <p>Exchange: Teach <strong>{selectedMatch.skill_you_teach_them.name}</strong> ⟷ Learn <strong>{selectedMatch.skill_they_teach.name}</strong></p>
                <p className="text-emerald-600 dark:text-emerald-400 font-bold">Cost: 0 Credits (Mutual Barter)</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Proposed Date</label>
                  <input
                    type="date"
                    required
                    value={swapDate}
                    onChange={(e) => setSwapDate(e.target.value)}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Proposed Time</label>
                  <input
                    type="time"
                    required
                    value={swapTime}
                    onChange={(e) => setSwapTime(e.target.value)}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Message for Peer</label>
                <textarea
                  rows={2}
                  value={swapMessage}
                  onChange={(e) => setSwapMessage(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedMatch(null)}
                  className="px-4 py-2 font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={inviting}
                  className="px-5 py-2 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-xl"
                >
                  {inviting ? 'Sending...' : 'Send Swap Invitation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
