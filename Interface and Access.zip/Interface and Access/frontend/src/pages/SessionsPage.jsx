import React, { useState, useEffect } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  XCircle,
  Star,
  MessageSquare,
  ShieldAlert,
  ArrowRight,
  Filter,
  X
} from 'lucide-react';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function SessionsPage() {
  const { user, refreshUserData } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterTab, setFilterTab] = useState('all');
  const [actionMessage, setActionMessage] = useState('');

  // Dispute Modal
  const [disputeSession, setDisputeSession] = useState(null);
  const [disputeReason, setDisputeReason] = useState('');
  const [disputeEvidence, setDisputeEvidence] = useState('');
  const [disputeSubmitting, setDisputeSubmitting] = useState(false);

  // Review Modal
  const [reviewSession, setReviewSession] = useState(null);
  const [ratingKnowledge, setRatingKnowledge] = useState(5);
  const [ratingClarity, setRatingClarity] = useState(5);
  const [ratingCommunication, setRatingCommunication] = useState(5);
  const [ratingTime, setRatingTime] = useState(5);
  const [feedbackComment, setFeedbackComment] = useState('');
  const [reviewSubmitting, setReviewSubmitting] = useState(false);

  const fetchSessions = async () => {
    try {
      setLoading(true);
      const res = await client.get('/sessions/');
      setSessions(res.data || []);
    } catch (err) {
      console.error('Failed to load sessions', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  const handleConfirmCompletion = async (sessionId) => {
    try {
      const res = await client.patch(`/sessions/${sessionId}/complete/`);
      const s = res.data;
      if (s.status === 'completed') {
        setActionMessage(`Session #${sessionId} is now fully completed! Credits have been released to the tutor.`);
        if (s.learner === user?.id && !s.review) {
          setReviewSession(s);
        }
      } else {
        setActionMessage(`You marked Session #${sessionId} as completed. Awaiting confirmation from the other participant.`);
      }
      fetchSessions();
      refreshUserData();
      setTimeout(() => setActionMessage(''), 5000);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to confirm session completion.');
    }
  };

  const handleCancelSession = async (sessionId) => {
    const reason = prompt('Please enter a cancellation reason:');
    if (!reason) return;

    try {
      await client.post(`/sessions/${sessionId}/cancel/`, { reason });
      setActionMessage(`Session #${sessionId} cancelled. Escrow credits refunded to the learner.`);
      fetchSessions();
      refreshUserData();
      setTimeout(() => setActionMessage(''), 5000);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to cancel session.');
    }
  };

  const handleDisputeSubmit = async (e) => {
    e.preventDefault();
    if (!disputeSession || !disputeReason.trim()) return;

    try {
      setDisputeSubmitting(true);
      await client.post(`/sessions/${disputeSession.id}/dispute/`, {
        reason: disputeReason,
        evidence_text: disputeEvidence,
      });
      setActionMessage(`Dispute filed for Session #${disputeSession.id}. Campus administrator has been alerted.`);
      setDisputeSession(null);
      setDisputeReason('');
      setDisputeEvidence('');
      fetchSessions();
      setTimeout(() => setActionMessage(''), 5000);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to file dispute.');
    } finally {
      setDisputeSubmitting(false);
    }
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!reviewSession || !feedbackComment.trim()) return;

    try {
      setReviewSubmitting(true);
      await client.post('/reviews/', {
        session_id: reviewSession.id,
        subject_knowledge: ratingKnowledge,
        teaching_clarity: ratingClarity,
        communication: ratingCommunication,
        time_management: ratingTime,
        feedback_comment: feedbackComment,
      });
      setActionMessage('Thank you! Your tutor review and rating have been recorded.');
      setReviewSession(null);
      setFeedbackComment('');
      fetchSessions();
      setTimeout(() => setActionMessage(''), 5000);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to submit review.');
    } finally {
      setReviewSubmitting(false);
    }
  };

  // Filtered sessions list
  const filteredSessions = sessions.filter((s) => {
    if (filterTab === 'active') return ['accepted', 'in_progress'].includes(s.status);
    if (filterTab === 'requested') return s.status === 'requested';
    if (filterTab === 'completed') return s.status === 'completed';
    if (filterTab === 'cancelled') return ['cancelled', 'rejected', 'disputed'].includes(s.status);
    return true;
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <Calendar className="w-8 h-8 text-primary-600" />
            Learning Session Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Track scheduled sessions, manage mutual completion confirmations, and resolve disputes.
          </p>
        </div>

        {/* Tab Filters */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl text-xs font-semibold">
          {[
            { id: 'all', label: 'All' },
            { id: 'active', label: 'Active / Scheduled' },
            { id: 'requested', label: 'Pending Requests' },
            { id: 'completed', label: 'Completed' },
            { id: 'cancelled', label: 'Cancelled' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterTab(tab.id)}
              className={`px-3 py-1.5 rounded-xl transition-all ${
                filterTab === tab.id
                  ? 'bg-white dark:bg-slate-900 text-primary-600 dark:text-primary-400 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {actionMessage && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded-2xl text-emerald-800 dark:text-emerald-200 text-xs font-medium flex items-center gap-2.5 shadow-xs">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Sessions Grid */}
      {loading ? (
        <div className="py-16 text-center text-xs text-slate-400">Loading your learning sessions...</div>
      ) : filteredSessions.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <Calendar className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-semibold text-sm text-slate-700 dark:text-slate-300">No sessions found</h3>
          <p className="text-xs text-slate-400">There are no learning sessions under this status tab.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredSessions.map((s) => {
            const isTeacher = s.teacher === user?.id;
            const peer = isTeacher ? s.learner_details : s.teacher_details;
            const myCompleted = isTeacher ? s.teacher_completed_confirmed : s.learner_completed_confirmed;
            const peerCompleted = isTeacher ? s.learner_completed_confirmed : s.teacher_completed_confirmed;

            return (
              <div
                key={s.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs flex flex-col justify-between space-y-4"
              >
                <div>
                  {/* Top Bar: Skill & Status */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-primary-50 dark:bg-primary-950 text-primary-700 dark:text-primary-300">
                      {isTeacher ? '👨‍🏫 Teaching' : '🎓 Learning'}
                    </span>

                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                        s.status === 'completed'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : s.status === 'accepted'
                          ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300'
                          : s.status === 'disputed'
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {s.status_display}
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-slate-900 dark:text-white">
                    {s.skill_details?.name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    With {peer?.first_name || peer?.username} ({peer?.email})
                  </p>

                  {/* Schedule & Credit Details */}
                  <div className="mt-3.5 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs space-y-1">
                    <p>📅 <strong>Date:</strong> {s.scheduled_date} at {s.start_time}</p>
                    <p>⏱️ <strong>Duration:</strong> {s.duration_minutes} minutes ({s.session_mode})</p>
                    <p>💰 <strong>Credit Settlement:</strong> {s.credit_amount} Credits</p>
                    {s.topics?.length > 0 && (
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                        Topics: {s.topics.join(', ')}
                      </p>
                    )}
                  </div>

                  {/* Mutual Confirmation State Badge (Section 14) */}
                  {['accepted', 'in_progress'].includes(s.status) && (
                    <div className="mt-3 p-2.5 bg-slate-100/70 dark:bg-slate-800/80 rounded-xl text-[11px] space-y-1">
                      <div className="flex items-center justify-between">
                        <span>Your Completion Status:</span>
                        <span className={`font-bold ${myCompleted ? 'text-emerald-600' : 'text-slate-400'}`}>
                          {myCompleted ? 'Confirmed ✓' : 'Pending'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Peer's Completion Status:</span>
                        <span className={`font-bold ${peerCompleted ? 'text-emerald-600' : 'text-slate-400'}`}>
                          {peerCompleted ? 'Confirmed ✓' : 'Pending'}
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Actions Bar */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {/* Mutual Confirm Button */}
                    {['accepted', 'in_progress'].includes(s.status) && !myCompleted && (
                      <button
                        onClick={() => handleConfirmCompletion(s.id)}
                        className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                      >
                        Mark as Completed
                      </button>
                    )}

                    {/* Review Button if completed and not reviewed */}
                    {s.status === 'completed' && !isTeacher && !s.review && (
                      <button
                        onClick={() => setReviewSession(s)}
                        className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1"
                      >
                        <Star className="w-3.5 h-3.5 fill-white" />
                        Leave Review
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Cancellation */}
                    {['requested', 'accepted'].includes(s.status) && (
                      <button
                        onClick={() => handleCancelSession(s.id)}
                        className="text-xs text-rose-600 dark:text-rose-400 hover:underline"
                      >
                        Cancel Session
                      </button>
                    )}

                    {/* Dispute */}
                    {s.status === 'accepted' && (
                      <button
                        onClick={() => setDisputeSession(s)}
                        className="text-xs text-slate-400 hover:text-amber-600"
                        title="Raise dispute to admin"
                      >
                        Raise Dispute
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Review & Rating Modal (Section 16) */}
      {reviewSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Rate Your Tutor Experience
                </h3>
                <p className="text-xs text-slate-400">
                  Tutor: {reviewSession.teacher_details?.first_name || reviewSession.teacher_details?.username} ({reviewSession.skill_details?.name})
                </p>
              </div>
              <button onClick={() => setReviewSession(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleReviewSubmit} className="space-y-4 text-xs">
              {/* 4 Multi-criteria categories */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Subject Knowledge:</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRatingKnowledge(star)}
                        className="p-1"
                      >
                        <Star
                          className={`w-4 h-4 ${
                            star <= ratingKnowledge ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Teaching Clarity:</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRatingClarity(star)}
                        className="p-1"
                      >
                        <Star
                          className={`w-4 h-4 ${
                            star <= ratingClarity ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Communication:</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRatingCommunication(star)}
                        className="p-1"
                      >
                        <Star
                          className={`w-4 h-4 ${
                            star <= ratingCommunication ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">Time Management:</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRatingTime(star)}
                        className="p-1"
                      >
                        <Star
                          className={`w-4 h-4 ${
                            star <= ratingTime ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Feedback Comment *</label>
                <textarea
                  rows={3}
                  required
                  value={feedbackComment}
                  onChange={(e) => setFeedbackComment(e.target.value)}
                  placeholder="Share details about the tutor's explanations, patience, and session quality..."
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReviewSession(null)}
                  className="px-4 py-2 font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={reviewSubmitting}
                  className="px-5 py-2 bg-primary-600 hover:bg-primary-700 text-white font-bold rounded-xl"
                >
                  {reviewSubmitting ? 'Submitting...' : 'Submit Review'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Dispute Modal */}
      {disputeSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" />
                Report Dispute on Session #{disputeSession.id}
              </h3>
              <button onClick={() => setDisputeSession(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleDisputeSubmit} className="space-y-4 text-xs">
              <p className="text-slate-500">
                Disputed sessions pause credit settlement. A campus administrator will review both sides before releasing credits or issuing a refund.
              </p>

              <div>
                <label className="block font-semibold mb-1">Reason for Dispute *</label>
                <textarea
                  rows={3}
                  required
                  value={disputeReason}
                  onChange={(e) => setDisputeReason(e.target.value)}
                  placeholder="e.g. Tutor did not attend the scheduled meeting, or session was interrupted."
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Evidence or Notes (Optional)</label>
                <input
                  type="text"
                  value={disputeEvidence}
                  onChange={(e) => setDisputeEvidence(e.target.value)}
                  placeholder="Meeting screenshots, timestamps, or links"
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border rounded-xl"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDisputeSession(null)}
                  className="px-4 py-2 font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={disputeSubmitting}
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl"
                >
                  {disputeSubmitting ? 'Filing...' : 'Submit Dispute'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
