import React, { useState, useEffect } from 'react';
import {
  Award,
  CheckCircle2,
  Lock,
  Sparkles,
  Zap,
  BookOpen,
  Share2,
  Clock,
  Crown
} from 'lucide-react';
import client from '../api/client';

export default function AchievementsPage() {
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAchievements = async () => {
      try {
        setLoading(true);
        const res = await client.get('/achievements/');
        setAchievements(res.data || []);
      } catch (err) {
        console.error('Failed to load achievements', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAchievements();
  }, []);

  const earnedCount = achievements.filter((a) => a.is_earned).length;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <Award className="w-8 h-8 text-amber-500" />
            Achievements & Campus Badges
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Earn verifiable badges by peer teaching, attending sessions, and maintaining 5-star ratings.
          </p>
        </div>

        <div className="px-4 py-2 bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 rounded-2xl text-xs font-bold text-amber-800 dark:text-amber-200 self-start sm:self-auto flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-500" />
          {earnedCount} of {achievements.length} Badges Unlocked
        </div>
      </div>

      {/* Badges Grid */}
      {loading ? (
        <div className="py-16 text-center text-xs text-slate-400">Loading achievements...</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((ach) => (
            <div
              key={ach.id}
              className={`p-6 rounded-3xl border transition-all flex flex-col justify-between space-y-4 ${
                ach.is_earned
                  ? 'bg-white dark:bg-slate-900 border-amber-300 dark:border-amber-700/80 shadow-md shadow-amber-500/5'
                  : 'bg-slate-50/60 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                      ach.is_earned
                        ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 shadow-sm'
                        : 'bg-slate-200 text-slate-400 dark:bg-slate-800 dark:text-slate-500'
                    }`}
                  >
                    <Award className="w-6 h-6" />
                  </div>

                  {ach.is_earned ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">
                      <Lock className="w-3 h-3" />
                      LOCKED
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-base text-slate-900 dark:text-white leading-tight">
                  {ach.name}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                  {ach.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
                {ach.is_earned ? (
                  <span>Unlocked on {new Date(ach.earned_at).toLocaleDateString()}</span>
                ) : (
                  <span>Requirement: {ach.threshold} session(s) or hours</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
