import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  Star,
  ShieldCheck,
  Coins,
  Calendar,
  Clock,
  Sparkles,
  ArrowUpDown,
  BookOpen,
  CheckCircle2,
  AlertCircle,
  X,
  ExternalLink
} from 'lucide-react';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function LearnPage() {
  const { user, refreshUserData } = useAuth();
  const [tutors, setTutors] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('');
  const [minRating, setMinRating] = useState('');
  const [maxCredits, setMaxCredits] = useState('');
  const [selectedMode, setSelectedMode] = useState('');
  const [sortBy, setSortBy] = useState('rating');

  // Request Session Modal
  const [selectedTutor, setSelectedTutor] = useState(null);
  const [sessionDate, setSessionDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });
  const [sessionTime, setSessionTime] = useState('16:00');
  const [sessionDuration, setSessionDuration] = useState(60);
  const [sessionMode, setSessionMode] = useState('online');
  const [selectedTopics, setSelectedTopics] = useState([]);
  const [sessionNotes, setSessionNotes] = useState('');
  const [requestSubmitting, setRequestSubmitting] = useState(false);
  const [requestSuccess, setRequestSuccess] = useState('');
  const [requestError, setRequestError] = useState('');

  const fetchTutors = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (searchQuery) params.append('q', searchQuery);
      if (selectedCategory) params.append('category', selectedCategory);
      if (selectedLevel) params.append('level', selectedLevel);
      if (minRating) params.append('min_rating', minRating);
      if (maxCredits) params.append('max_credits', maxCredits);
      if (selectedMode) params.append('mode', selectedMode);
      if (sortBy) params.append('sort_by', sortBy);

      const [tutRes, catRes] = await Promise.all([
        client.get(`/learning/tutors/?${params.toString()}`),
        client.get('/skills/categories/')
      ]);

      setTutors(tutRes.data || []);
      setCategories(catRes.data || []);
    } catch (err) {
      console.error('Error fetching tutors', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTutors();
  }, [selectedCategory, selectedLevel, minRating, maxCredits, selectedMode, sortBy]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchTutors();
  };

  const handleOpenBooking = (tutor) => {
    setSelectedTutor(tutor);
    setSelectedTopics(tutor.topics_offered ? tutor.topics_offered.slice(0, 2) : []);
    setRequestSuccess('');
    setRequestError('');
  };

  const toggleTopicSelection = (topic) => {
    if (selectedTopics.includes(topic)) {
      setSelectedTopics(selectedTopics.filter((t) => t !== topic));
    } else {
      setSelectedTopics([...selectedTopics, topic]);
    }
  };

  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    if (!selectedTutor) return;

    try {
      setRequestSubmitting(true);
      setRequestError('');

      const payload = {
        tutor_id: selectedTutor.tutor_id,
        skill_id: selectedTutor.skill,
        topics: selectedTopics,
        scheduled_date: sessionDate,
        start_time: `${sessionTime}:00`,
        duration_minutes: sessionDuration,
        session_mode: sessionMode,
        notes: sessionNotes,
      };

      const res = await client.post('/learning/sessions/request/', payload);
      setRequestSuccess(`Session requested successfully with ${selectedTutor.tutor_name}! Required credits reserved in escrow.`);
      refreshUserData();
      setTimeout(() => {
        setSelectedTutor(null);
        setRequestSuccess('');
      }, 2500);
    } catch (err) {
      setRequestError(err.response?.data?.error || 'Failed to submit session request.');
    } finally {
      setRequestSubmitting(false);
    }
  };

  // Calculate live credit cost
  const calculatedCreditCost = selectedTutor
    ? Math.round(selectedTutor.hourly_rate * (sessionDuration / 60))
    : 15;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
          <BookOpen className="w-8 h-8 text-primary-600" />
          Explore Peer Tutors
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Learn from verified fellow students and spend internal SkillSwap credits.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-3xl shadow-xs space-y-4">
        {/* Search Input Row */}
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by skill name, tutor name, or topic (e.g. Python, Photoshop, React)..."
              className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
          >
            Search
          </button>
        </form>

        {/* Dropdown Filters Row */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
          {/* Category */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          >
            <option value="">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.slug}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Level */}
          <select
            value={selectedLevel}
            onChange={(e) => setSelectedLevel(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          >
            <option value="">All Levels</option>
            <option value="beginner">Beginner (10 cr/hr)</option>
            <option value="intermediate">Intermediate (15 cr/hr)</option>
            <option value="advanced">Advanced (20 cr/hr)</option>
          </select>

          {/* Min Rating */}
          <select
            value={minRating}
            onChange={(e) => setMinRating(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          >
            <option value="">Any Rating</option>
            <option value="4.5">4.5+ Stars</option>
            <option value="4.8">4.8+ Stars</option>
            <option value="5.0">5.0 Stars only</option>
          </select>

          {/* Max Credits */}
          <select
            value={maxCredits}
            onChange={(e) => setMaxCredits(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
          >
            <option value="">Max Cost</option>
            <option value="10">Max 10 credits/hr</option>
            <option value="15">Max 15 credits/hr</option>
            <option value="20">Max 20 credits/hr</option>
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="col-span-2 sm:col-span-1 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium"
          >
            <option value="rating">Highest Rated</option>
            <option value="experience">Most Experienced</option>
            <option value="sessions">Most Completed Sessions</option>
            <option value="cost_asc">Lowest Credit Cost</option>
            <option value="cost_desc">Highest Credit Cost</option>
          </select>
        </div>
      </div>

      {/* Tutor Cards Grid */}
      {loading ? (
        <div className="py-16 text-center text-xs text-slate-400 space-y-3">
          <div className="w-8 h-8 border-4 border-primary-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p>Querying verified peer tutors...</p>
        </div>
      ) : tutors.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-semibold text-sm text-slate-700 dark:text-slate-300">No verified tutors matched your filters</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Try resetting your filters or search for another skill like "Python" or "Photoshop".
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tutors.map((tutor) => (
            <div
              key={tutor.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs flex flex-col justify-between space-y-4 hover:border-primary-400 dark:hover:border-primary-600 transition-all"
            >
              <div>
                {/* Header: Tutor Avatar & Verification Badge */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-primary-600 to-indigo-500 text-white font-bold text-sm flex items-center justify-center shadow-xs">
                      {tutor.tutor_name?.[0] || 'T'}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900 dark:text-white leading-tight">
                        {tutor.tutor_name}
                      </h3>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {tutor.college || 'SkillSwap University'}
                      </p>
                    </div>
                  </div>

                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 text-[10px] font-bold rounded-full">
                    <ShieldCheck className="w-3 h-3 text-emerald-600" />
                    Verified
                  </span>
                </div>

                {/* Skill & Level */}
                <div className="mb-2">
                  <span className="text-xs font-bold text-primary-600 dark:text-primary-400 block">
                    {tutor.skill_name}
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    {tutor.experience_level.toUpperCase()} • {tutor.experience_duration} experience
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed mb-3">
                  {tutor.description}
                </p>

                {/* Topics Offered */}
                {tutor.topics_offered?.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    {tutor.topics_offered.slice(0, 3).map((topic, i) => (
                      <span
                        key={i}
                        className="text-[10px] px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-md"
                      >
                        {topic}
                      </span>
                    ))}
                    {tutor.topics_offered.length > 3 && (
                      <span className="text-[10px] px-1 text-slate-400 font-semibold self-center">
                        +{tutor.topics_offered.length - 3} more
                      </span>
                    )}
                  </div>
                )}

                {/* Stats: Rating and Sessions */}
                <div className="flex items-center gap-3 text-xs text-slate-500 pt-1">
                  <span className="flex items-center gap-1 font-semibold text-amber-600">
                    <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                    {tutor.average_rating}
                  </span>
                  <span>•</span>
                  <span>{tutor.total_sessions_taught} sessions taught</span>
                </div>
              </div>

              {/* Bottom: Credits / Hour & Request Session Button */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-lg font-extrabold text-slate-900 dark:text-white">
                    {tutor.hourly_rate}
                  </span>
                  <span className="text-xs text-slate-400 font-medium ml-1">Credits / Hr</span>
                </div>

                <button
                  onClick={() => handleOpenBooking(tutor)}
                  className="px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
                >
                  Request Session
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Request Session Modal */}
      {selectedTutor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Request a Learning Session
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Tutor: {selectedTutor.tutor_name} • {selectedTutor.skill_name}
                </p>
              </div>
              <button
                onClick={() => setSelectedTutor(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {requestError && (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{requestError}</span>
              </div>
            )}

            {requestSuccess ? (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200 text-xs rounded-xl flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                <span>{requestSuccess}</span>
              </div>
            ) : (
              <form onSubmit={handleBookingSubmit} className="space-y-4">
                {/* Topic selection */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Topics to Focus On:
                  </label>
                  <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                    {selectedTutor.topics_offered?.map((topic, i) => {
                      const isSel = selectedTopics.includes(topic);
                      return (
                        <button
                          type="button"
                          key={i}
                          onClick={() => toggleTopicSelection(topic)}
                          className={`text-xs px-2.5 py-1 rounded-lg border transition-colors ${
                            isSel
                              ? 'bg-primary-600 text-white border-primary-600 font-medium'
                              : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {topic}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Date & Time */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Proposed Date *
                    </label>
                    <input
                      type="date"
                      required
                      value={sessionDate}
                      onChange={(e) => setSessionDate(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Proposed Start Time *
                    </label>
                    <input
                      type="time"
                      required
                      value={sessionTime}
                      onChange={(e) => setSessionTime(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                    />
                  </div>
                </div>

                {/* Duration & Mode */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Duration
                    </label>
                    <select
                      value={sessionDuration}
                      onChange={(e) => setSessionDuration(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                    >
                      <option value={45}>45 Minutes</option>
                      <option value={60}>60 Minutes (Standard)</option>
                      <option value={90}>90 Minutes</option>
                      <option value={120}>120 Minutes</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Session Mode
                    </label>
                    <select
                      value={sessionMode}
                      onChange={(e) => setSessionMode(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                    >
                      <option value="online">Online (Google Meet)</option>
                      <option value="offline">Offline (Campus Library)</option>
                    </select>
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Notes for Tutor (Optional)
                  </label>
                  <textarea
                    rows={2}
                    value={sessionNotes}
                    onChange={(e) => setSessionNotes(e.target.value)}
                    placeholder="Specific questions or background experience..."
                    className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>

                {/* Escrow Credit Summary Card */}
                <div className="p-3.5 bg-amber-50 dark:bg-amber-950/60 rounded-2xl border border-amber-200 dark:border-amber-800 text-xs space-y-1">
                  <div className="flex items-center justify-between font-bold text-amber-900 dark:text-amber-200">
                    <span>Credit Escrow Hold:</span>
                    <span className="text-sm">{calculatedCreditCost} Credits</span>
                  </div>
                  <p className="text-[11px] text-amber-700 dark:text-amber-300 leading-relaxed">
                    Credits will be reserved in escrow from your available balance ({user?.wallet_balance || 50} credits). Credits are released to the tutor ONLY after mutual completion confirmation.
                  </p>
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedTutor(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={requestSubmitting}
                    className="px-5 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-xs font-bold shadow-md transition-all disabled:opacity-50"
                  >
                    {requestSubmitting ? 'Reserving Escrow & Requesting...' : `Confirm & Hold ${calculatedCreditCost} Credits`}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
