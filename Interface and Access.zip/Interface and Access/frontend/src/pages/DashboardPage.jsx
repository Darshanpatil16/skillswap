import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Coins,
  GraduationCap,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
  TrendingUp,
  AlertCircle,
  ShieldCheck,
  User,
  Star
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';
import { useAuth } from '../context/AuthContext';
import client from '../api/client';

export default function DashboardPage() {
  const { user, refreshUserData } = useAuth();
  const [loading, setLoading] = useState(true);
  const [wallet, setWallet] = useState(null);
  const [upcomingSessions, setUpcomingSessions] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [achievements, setAchievements] = useState([]);
  const [actionMessage, setActionMessage] = useState('');

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [wRes, sRes, recRes, txRes, achRes] = await Promise.all([
        client.get('/wallet/'),
        client.get('/sessions/'),
        client.get('/learning/recommendations/'),
        client.get('/wallet/transactions/?limit=5'),
        client.get('/achievements/')
      ]);

      setWallet(wRes.data);

      const allSessions = sRes.data || [];
      // Filter upcoming
      setUpcomingSessions(
        allSessions.filter((s) => ['accepted', 'in_progress'].includes(s.status)).slice(0, 3)
      );
      // Filter pending requests where I am the teacher
      setPendingRequests(
        allSessions.filter((s) => s.status === 'requested' && s.teacher === user?.id)
      );

      setRecommendations(recRes.data ? recRes.data.slice(0, 3) : []);
      setRecentTransactions(txRes.data ? txRes.data.slice(0, 5) : []);
      setAchievements(achRes.data ? achRes.data.filter((a) => a.is_earned).slice(0, 4) : []);
    } catch (err) {
      console.error('Error fetching dashboard data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [user]);

  const handleRequestAction = async (sessionId, action) => {
    try {
      await client.patch(`/teaching/requests/${sessionId}/${action}/`);
      setActionMessage(`Session request #${sessionId} has been ${action}ed.`);
      fetchDashboardData();
      refreshUserData();
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err) {
      alert(err.response?.data?.error || `Failed to ${action} request.`);
    }
  };

  // Analytical Charts Data
  const creditFlowData = [
    { name: 'Welcome', credits: 50 },
    { name: 'Earned', credits: wallet?.total_earned || 0 },
    { name: 'Spent', credits: wallet?.total_spent || 0 },
    { name: 'Available', credits: wallet?.available_balance || 50 },
  ];

  const hoursRatioData = [
    { name: 'Teaching Hours', value: Number(user?.profile?.total_teaching_hours || 0) || 0.1, color: '#6366f1' },
    { name: 'Learning Hours', value: Number(user?.profile?.total_learning_hours || 0) || 0.1, color: '#10b981' },
  ];

  const monthlyActivityData = [
    { week: 'W1', hours: 1.5, credits: 25 },
    { week: 'W2', hours: 3.0, credits: 45 },
    { week: 'W3', hours: 4.5, credits: 60 },
    { week: 'W4', hours: Number(user?.profile?.total_teaching_hours || 2) + 2, credits: (wallet?.total_earned || 10) + 20 },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-primary-600 via-indigo-600 to-primary-700 p-6 sm:p-8 rounded-3xl text-white shadow-lg relative overflow-hidden">
        <div className="space-y-1 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-white/20 text-xs font-medium backdrop-blur-xs mb-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            Verified Campus Learning Community
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            Welcome, {user?.first_name || user?.username}!
          </h1>
          <p className="text-xs sm:text-sm text-primary-100 max-w-xl">
            {user?.profile?.college_name} • {user?.profile?.department} ({user?.profile?.year_of_study})
          </p>
        </div>

        <div className="flex items-center gap-3 relative z-10">
          <Link
            to="/learn"
            className="px-4 py-2.5 bg-white text-primary-700 hover:bg-primary-50 rounded-xl font-semibold text-xs shadow-sm transition-all"
          >
            Find a Tutor
          </Link>
          <Link
            to="/teach"
            className="px-4 py-2.5 bg-primary-800/80 hover:bg-primary-800 text-white rounded-xl font-semibold text-xs border border-white/20 transition-all"
          >
            Teach a Skill
          </Link>
        </div>
      </div>

      {actionMessage && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded-xl text-emerald-800 dark:text-emerald-200 text-xs font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          {actionMessage}
        </div>
      )}

      {/* Top 4 Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Available Credits */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Available Credits</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Coins className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              {wallet?.available_balance ?? 50}
            </span>
            <span className="text-xs text-amber-600 font-semibold">
              ({wallet?.escrow_balance || 0} in Escrow)
            </span>
          </div>
          <Link to="/wallet" className="text-[11px] text-primary-600 dark:text-primary-400 font-medium hover:underline mt-2 inline-flex items-center gap-1">
            View Ledger <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        {/* Skills Teaching */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Skills Teaching</span>
            <div className="w-8 h-8 rounded-lg bg-primary-50 dark:bg-primary-950/60 text-primary-600 dark:text-primary-400 flex items-center justify-center">
              <GraduationCap className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              {user?.teaching_skills?.length || 1}
            </span>
            <span className="text-xs text-slate-400">Skills</span>
          </div>
          <Link to="/teach" className="text-[11px] text-primary-600 dark:text-primary-400 font-medium hover:underline mt-2 inline-flex items-center gap-1">
            Manage Teaching <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        {/* Skills Learning */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Skills Learning</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              {user?.learning_interests?.length || 2}
            </span>
            <span className="text-xs text-slate-400">Subjects</span>
          </div>
          <Link to="/learn" className="text-[11px] text-primary-600 dark:text-primary-400 font-medium hover:underline mt-2 inline-flex items-center gap-1">
            Browse Tutors <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        {/* Completed Sessions */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Completed Sessions</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              {user?.profile?.completed_sessions || 0}
            </span>
            <span className="text-xs text-slate-400">Sessions</span>
          </div>
          <Link to="/sessions" className="text-[11px] text-primary-600 dark:text-primary-400 font-medium hover:underline mt-2 inline-flex items-center gap-1">
            Session History <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>

      {/* Analytical Charts Section (Recharts) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Credits Flow Bar Chart */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Credit Ledger Balance Flow</h3>
              <p className="text-xs text-slate-400">Earned, spent, and current balance in internal credits</p>
            </div>
            <span className="text-xs font-semibold px-2 py-1 bg-primary-50 dark:bg-primary-950 text-primary-600 rounded-lg">
              Theme 3 Ledger
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={creditFlowData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1e293b',
                    color: '#fff',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="credits" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Teaching vs Learning Hours Ratio */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-xs space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Teaching vs Learning Hours</h3>
            <p className="text-xs text-slate-400">Balanced peer exchange contribution</p>
          </div>

          <div className="h-48 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={hoursRatioData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {hoursRatioData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-center text-xs pt-2 border-t border-slate-100 dark:border-slate-800">
            <div>
              <span className="block font-bold text-primary-600 dark:text-primary-400">
                {user?.profile?.total_teaching_hours || 0} hrs
              </span>
              <span className="text-[11px] text-slate-400">Teaching</span>
            </div>
            <div>
              <span className="block font-bold text-emerald-600 dark:text-emerald-400">
                {user?.profile?.total_learning_hours || 0} hrs
              </span>
              <span className="text-[11px] text-slate-400">Learning</span>
            </div>
          </div>
        </div>
      </div>

      {/* Middle Row: Pending Requests & Upcoming Sessions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending Teaching Requests */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-500" />
              Incoming Teaching Requests
            </h3>
            <span className="text-xs font-semibold text-slate-400">{pendingRequests.length} pending</span>
          </div>

          {pendingRequests.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-400">
              No pending teaching requests at the moment. When peers request sessions, they will appear here.
            </div>
          ) : (
            <div className="space-y-3">
              {pendingRequests.map((req) => (
                <div
                  key={req.id}
                  className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-xs text-slate-900 dark:text-white">
                        {req.learner_details?.first_name || req.learner_details?.username}
                      </h4>
                      <p className="text-[11px] text-primary-600 font-medium">{req.skill_details?.name}</p>
                    </div>
                    <span className="text-xs font-bold px-2.5 py-1 bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800 rounded-full">
                      +{req.credit_amount} Credits
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    📅 {req.scheduled_date} at {req.start_time} ({req.duration_minutes} mins) • {req.session_mode}
                  </p>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={() => handleRequestAction(req.id, 'accept')}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold transition-colors"
                    >
                      Accept Request
                    </button>
                    <button
                      onClick={() => handleRequestAction(req.id, 'reject')}
                      className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-rose-100 hover:text-rose-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium transition-colors"
                    >
                      Decline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Upcoming Confirmed Sessions */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary-500" />
              Upcoming Learning Sessions
            </h3>
            <Link to="/sessions" className="text-xs font-semibold text-primary-600 hover:underline">
              View All
            </Link>
          </div>

          {upcomingSessions.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-xs text-slate-400">
              No sessions scheduled currently.{' '}
              <Link to="/learn" className="text-primary-600 font-semibold hover:underline">
                Explore verified peer tutors
              </Link>{' '}
              to book your first session!
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingSessions.map((session) => {
                const isTeacher = session.teacher === user?.id;
                return (
                  <div
                    key={session.id}
                    className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-xs text-slate-900 dark:text-white">
                          {session.skill_details?.name}
                        </span>
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                          {isTeacher ? 'Teaching' : 'Learning'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        With {isTeacher ? session.learner_details?.username : session.teacher_details?.username} • {session.scheduled_date} at {session.start_time}
                      </p>
                    </div>

                    <Link
                      to="/sessions"
                      className="px-3 py-1.5 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-xs font-semibold rounded-lg hover:border-primary-500"
                    >
                      Manage
                    </Link>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Row: Intelligent Recommendations & Recent Ledger Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recommended Verified Tutors (Section 11) */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-primary-500" />
                Intelligent Skill Recommendations
              </h3>
              <p className="text-xs text-slate-400">Ranked by verification score, ratings, and schedule alignment</p>
            </div>
            <Link to="/learn" className="text-xs font-semibold text-primary-600 hover:underline">
              Browse All Tutors
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recommendations.map((tutor) => (
              <div
                key={tutor.id}
                className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-primary-100 dark:bg-primary-950 text-primary-700 dark:text-primary-300">
                      {tutor.relevance_score || 95}% Match
                    </span>
                    <span className="text-xs font-bold text-amber-600 flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                      {tutor.average_rating}
                    </span>
                  </div>

                  <h4 className="font-semibold text-xs text-slate-900 dark:text-white">{tutor.tutor_name}</h4>
                  <p className="text-xs text-primary-600 font-medium">{tutor.skill_name}</p>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                    {tutor.match_explanation || 'Verified tutor with high campus ratings.'}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    {tutor.hourly_rate} cr/hr
                  </span>
                  <Link
                    to={`/learn?tutor=${tutor.tutor_id}`}
                    className="text-xs font-semibold text-primary-600 hover:underline"
                  >
                    Request
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Ledger Transactions */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">Recent Transactions</h3>
            <Link to="/wallet" className="text-xs font-semibold text-primary-600 hover:underline">
              Wallet
            </Link>
          </div>

          <div className="space-y-3 text-xs">
            {recentTransactions.map((tx) => {
              const isCredit = tx.receiver === user?.id;
              return (
                <div
                  key={tx.id}
                  className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl"
                >
                  <div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200 block truncate max-w-[150px]">
                      {tx.transaction_type_display}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(tx.timestamp).toLocaleDateString()}
                    </span>
                  </div>

                  <span
                    className={`font-bold text-xs ${
                      isCredit ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {isCredit ? `+${tx.amount}` : `-${tx.amount}`} Cr
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
