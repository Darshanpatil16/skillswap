import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Bell,
  CheckCircle2,
  Calendar,
  Coins,
  ShieldCheck,
  Star,
  Repeat,
  Check
} from 'lucide-react';
import client from '../api/client';

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const res = await client.get('/notifications/');
      setNotifications(res.data?.notifications || []);
      setUnreadCount(res.data?.unread_count || 0);
    } catch (err) {
      console.error('Failed to load notifications', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  const handleMarkRead = async (id) => {
    try {
      await client.patch(`/notifications/${id}/read/`);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, is_read: true } : n))
      );
      setUnreadCount((c) => Math.max(c - 1, 0));
    } catch (err) {
      // silent
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await client.post('/notifications/mark-all-read/');
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch (err) {
      // silent
    }
  };

  const getIconForType = (type) => {
    switch (type) {
      case 'session_request':
      case 'session_accepted':
      case 'session_completed':
        return Calendar;
      case 'credit_received':
      case 'credit_deducted':
        return Coins;
      case 'verification_result':
        return ShieldCheck;
      case 'review_received':
        return Star;
      case 'swap_invitation':
        return Repeat;
      default:
        return Bell;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <Bell className="w-8 h-8 text-primary-600" />
            Notifications Center
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Stay updated on new session requests, escrow credit movements, and verification reviews.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllRead}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Check className="w-4 h-4" />
            Mark All as Read
          </button>
        )}
      </div>

      {/* Notifications List */}
      {loading ? (
        <div className="py-16 text-center text-xs text-slate-400">Loading notifications...</div>
      ) : notifications.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <Bell className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="font-semibold text-sm text-slate-700 dark:text-slate-300">No notifications</h3>
          <p className="text-xs text-slate-400">You are completely up to date.</p>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xs divide-y divide-slate-100 dark:divide-slate-800">
          {notifications.map((n) => {
            const Icon = getIconForType(n.notification_type);
            return (
              <div
                key={n.id}
                onClick={() => !n.is_read && handleMarkRead(n.id)}
                className={`p-5 flex items-start gap-4 transition-colors cursor-pointer ${
                  n.is_read
                    ? 'hover:bg-slate-50/50 dark:hover:bg-slate-850/40'
                    : 'bg-primary-50/40 dark:bg-primary-950/20 hover:bg-primary-50/70'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 ${
                    n.is_read
                      ? 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      : 'bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-300 shadow-xs'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>

                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <h4
                      className={`text-xs sm:text-sm font-semibold ${
                        n.is_read
                          ? 'text-slate-800 dark:text-slate-200'
                          : 'text-primary-900 dark:text-primary-100 font-bold'
                      }`}
                    >
                      {n.title}
                    </h4>
                    <span className="text-[11px] text-slate-400">
                      {new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {n.message}
                  </p>

                  {n.link_url && (
                    <Link
                      to={n.link_url}
                      className="text-xs font-semibold text-primary-600 dark:text-primary-400 hover:underline inline-block pt-1"
                    >
                      View Details →
                    </Link>
                  )}
                </div>

                {!n.is_read && (
                  <span className="w-2.5 h-2.5 rounded-full bg-primary-600 flex-shrink-0 mt-2" />
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
