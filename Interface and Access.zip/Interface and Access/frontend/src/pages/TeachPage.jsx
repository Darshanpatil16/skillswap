import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  Plus,
  ShieldCheck,
  Clock,
  Coins,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ChevronRight,
  ExternalLink,
  Trash2,
  Edit2
} from 'lucide-react';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';
import SkillVerificationModal from '../components/SkillVerificationModal';

export default function TeachPage() {
  const { user, refreshUserData } = useAuth();
  const [teachingSkills, setTeachingSkills] = useState([]);
  const [categories, setCategories] = useState([]);
  const [allSkills, setAllSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedForVerification, setSelectedForVerification] = useState(null);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [statusMessage, setStatusMessage] = useState('');

  // Add skill form state
  const [selectedSkillId, setSelectedSkillId] = useState('');
  const [experienceLevel, setExperienceLevel] = useState('intermediate');
  const [experienceDuration, setExperienceDuration] = useState('1 year');
  const [description, setDescription] = useState('');
  const [topicsInput, setTopicsInput] = useState('');
  const [teachingLanguage, setTeachingLanguage] = useState('English');
  const [preferredDuration, setPreferredDuration] = useState(60);
  const [portfolioLink, setPortfolioLink] = useState('');
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  const fetchTeachingData = async () => {
    try {
      setLoading(true);
      const [tsRes, catRes, skillsRes, sessionsRes] = await Promise.all([
        client.get('/teaching/my-skills/'),
        client.get('/skills/categories/'),
        client.get('/skills/'),
        client.get('/sessions/?role=teaching')
      ]);

      setTeachingSkills(tsRes.data || []);
      setCategories(catRes.data || []);
      setAllSkills(skillsRes.data || []);
      if (skillsRes.data?.length > 0 && !selectedSkillId) {
        setSelectedSkillId(skillsRes.data[0].id);
      }
      setPendingRequests(
        (sessionsRes.data || []).filter((s) => s.status === 'requested')
      );
    } catch (err) {
      console.error('Error fetching teaching data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTeachingData();
  }, []);

  const handleAddSkill = async (e) => {
    e.preventDefault();
    if (!selectedSkillId) {
      setFormError('Please select a skill to teach.');
      return;
    }

    try {
      setFormSubmitting(true);
      setFormError('');

      const topics = topicsInput
        .split('\n')
        .map((t) => t.trim())
        .filter(Boolean);

      const payload = {
        skill: selectedSkillId,
        experience_level: experienceLevel,
        experience_duration: experienceDuration,
        description,
        topics_offered: topics.length > 0 ? topics : ['Core Fundamentals', 'Practical Hands-on Projects'],
        teaching_language: teachingLanguage,
        preferred_duration_minutes: preferredDuration,
        portfolio_link: portfolioLink,
      };

      const res = await client.post('/teaching/my-skills/', payload);
      setShowAddModal(false);
      resetForm();
      fetchTeachingData();
      refreshUserData();

      // Open verification modal immediately for the new skill
      setSelectedForVerification(res.data);
    } catch (err) {
      setFormError(err.response?.data?.error || 'Failed to save teaching skill.');
    } finally {
      setFormSubmitting(false);
    }
  };

  const resetForm = () => {
    setDescription('');
    setTopicsInput('');
    setPortfolioLink('');
    setFormError('');
  };

  const handleRequestAction = async (sessionId, action) => {
    try {
      await client.patch(`/teaching/requests/${sessionId}/${action}/`);
      setStatusMessage(`Request #${sessionId} has been ${action}ed.`);
      fetchTeachingData();
      refreshUserData();
      setTimeout(() => setStatusMessage(''), 4000);
    } catch (err) {
      alert(err.response?.data?.error || `Failed to ${action} request.`);
    }
  };

  const creditRates = {
    beginner: 10,
    intermediate: 15,
    advanced: 20,
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <GraduationCap className="w-8 h-8 text-primary-600" />
            Peer Teaching Hub
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Share your knowledge with fellow students and earn SkillSwap credits.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-semibold text-xs shadow-sm transition-all flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add a Teaching Skill
        </button>
      </div>

      {statusMessage && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded-xl text-emerald-800 dark:text-emerald-200 text-xs font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          {statusMessage}
        </div>
      )}

      {/* Credit Rates Info Ribbon (Section 9) */}
      <div className="p-5 bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-3xl shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-primary-300 flex items-center gap-1.5">
            <Coins className="w-4 h-4 text-amber-400" />
            Official Teaching Credit Rates
          </span>
          <span className="text-[11px] text-slate-300">Set automatically by approved level</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
          <div className="p-3 bg-white/10 rounded-xl">
            <span className="text-xs text-slate-300 block">Beginner Tutor</span>
            <span className="text-lg font-extrabold text-amber-300">10 Credits / Hour</span>
          </div>
          <div className="p-3 bg-white/10 rounded-xl">
            <span className="text-xs text-slate-300 block">Intermediate Tutor</span>
            <span className="text-lg font-extrabold text-emerald-300">15 Credits / Hour</span>
          </div>
          <div className="p-3 bg-white/10 rounded-xl">
            <span className="text-xs text-slate-300 block">Advanced Tutor</span>
            <span className="text-lg font-extrabold text-indigo-300">20 Credits / Hour</span>
          </div>
        </div>
      </div>

      {/* Incoming Teaching Requests Section */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-500" />
            Incoming Teaching Requests ({pendingRequests.length})
          </h2>
        </div>

        {pendingRequests.length === 0 ? (
          <p className="text-xs text-slate-400 py-3">
            You have no pending requests right now. As learners browse verified tutors, requests will arrive here.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingRequests.map((req) => (
              <div
                key={req.id}
                className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-xs text-slate-900 dark:text-white">
                      Learner: {req.learner_details?.first_name || req.learner_details?.username}
                    </h4>
                    <p className="text-[11px] text-primary-600 font-medium">Subject: {req.skill_details?.name}</p>
                  </div>
                  <span className="text-xs font-bold px-2 py-0.5 bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 rounded-full">
                    +{req.credit_amount} Cr
                  </span>
                </div>

                <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1">
                  <p>📅 {req.scheduled_date} at {req.start_time} ({req.duration_minutes} min)</p>
                  {req.topics?.length > 0 && (
                    <p className="text-[11px]">Requested Topics: {req.topics.join(', ')}</p>
                  )}
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    onClick={() => handleRequestAction(req.id, 'accept')}
                    className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold"
                  >
                    Accept
                  </button>
                  <button
                    onClick={() => handleRequestAction(req.id, 'reject')}
                    className="px-3.5 py-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-rose-100 hover:text-rose-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium"
                  >
                    Decline
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* My Teaching Skills List */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-primary-600" />
          My Teaching Skills & Verification Status
        </h2>

        {teachingSkills.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-800 rounded-3xl p-10 text-center space-y-3">
            <GraduationCap className="w-10 h-10 text-slate-300 mx-auto" />
            <h3 className="font-semibold text-sm text-slate-700 dark:text-slate-300">No teaching skills added yet</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Add skills you are confident in, pass the verification assessment, and start earning credits by tutoring peers!
            </p>
            <button
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2 bg-primary-600 text-white text-xs font-semibold rounded-xl"
            >
              Add Your First Teaching Skill
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {teachingSkills.map((ts) => {
              const isVerified = ts.verification_status === 'verified';
              const isProvisional = ts.verification_status === 'provisional';
              return (
                <div
                  key={ts.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs flex flex-col justify-between space-y-4"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {ts.experience_level.toUpperCase()} • {ts.experience_duration}
                      </span>

                      {/* Verification Status Badge */}
                      {isVerified ? (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300 text-xs font-bold rounded-full">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          VERIFIED ({ts.verification_score}%)
                        </span>
                      ) : isProvisional ? (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-700 text-amber-700 dark:text-amber-300 text-xs font-bold rounded-full">
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                          PROVISIONAL REVIEW ({ts.verification_score}%)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-50 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-700 text-rose-700 dark:text-rose-300 text-xs font-bold rounded-full">
                          <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                          PENDING ASSESSMENT
                        </span>
                      )}
                    </div>

                    <h3 className="font-bold text-base text-slate-900 dark:text-white">
                      {ts.skill_details?.name}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                      {ts.description}
                    </p>

                    {ts.topics_offered?.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {ts.topics_offered.map((topic, i) => (
                          <span
                            key={i}
                            className="text-[11px] px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-md"
                          >
                            {topic}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="text-base font-extrabold text-primary-600 dark:text-primary-400">
                        {ts.hourly_rate}
                      </span>
                      <span className="text-xs text-slate-400 font-medium ml-1">Credits / Hour</span>
                    </div>

                    {!isVerified ? (
                      <button
                        onClick={() => setSelectedForVerification(ts)}
                        className="px-3.5 py-1.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                      >
                        Take Skill Assessment
                      </button>
                    ) : (
                      <div className="text-xs text-slate-400 flex items-center gap-1">
                        <span>{ts.total_sessions_taught} sessions taught</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add Teaching Skill Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Register a New Teaching Skill
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleAddSkill} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Select Skill to Teach *
                </label>
                <select
                  required
                  value={selectedSkillId}
                  onChange={(e) => setSelectedSkillId(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                >
                  {allSkills.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.category_name})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Experience Level *
                  </label>
                  <select
                    value={experienceLevel}
                    onChange={(e) => setExperienceLevel(e.target.value)}
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  >
                    <option value="beginner">Beginner (10 credits/hr)</option>
                    <option value="intermediate">Intermediate (15 credits/hr)</option>
                    <option value="advanced">Advanced (20 credits/hr)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Duration of Experience
                  </label>
                  <input
                    type="text"
                    required
                    value={experienceDuration}
                    onChange={(e) => setExperienceDuration(e.target.value)}
                    placeholder="e.g. 2 years, 6 months"
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Credit Rate Preview Box */}
              <div className="p-3 bg-primary-50 dark:bg-primary-950/60 rounded-xl border border-primary-100 dark:border-primary-900 text-xs flex items-center justify-between">
                <span className="text-primary-800 dark:text-primary-200 font-medium">
                  Hourly Rate for {experienceLevel.toUpperCase()}:
                </span>
                <span className="font-extrabold text-primary-700 dark:text-primary-300">
                  {creditRates[experienceLevel]} Credits / Hour
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Description of Your Teaching Approach *
                </label>
                <textarea
                  rows={2}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Experienced in Python syntax, data structures, and debugging code with students."
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Topics You Can Teach (One per line)
                </label>
                <textarea
                  rows={3}
                  value={topicsInput}
                  onChange={(e) => setTopicsInput(e.target.value)}
                  placeholder="e.g.&#10;Variables and Data Types&#10;Loops and Functions&#10;OOP Classes&#10;Project Debugging"
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Portfolio or GitHub Link (Optional)
                </label>
                <input
                  type="url"
                  value={portfolioLink}
                  onChange={(e) => setPortfolioLink(e.target.value)}
                  placeholder="https://github.com/yourusername or portfolio URL"
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formSubmitting}
                  className="px-5 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-xs font-bold"
                >
                  {formSubmitting ? 'Saving...' : 'Save & Proceed to Verification'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Skill Verification Modal */}
      {selectedForVerification && (
        <SkillVerificationModal
          teachingSkill={selectedForVerification}
          isOpen={Boolean(selectedForVerification)}
          onClose={() => {
            setSelectedForVerification(null);
            fetchTeachingData();
          }}
          onVerified={() => {
            fetchTeachingData();
            refreshUserData();
          }}
        />
      )}
    </div>
  );
}
