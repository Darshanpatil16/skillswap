import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Users,
  GraduationCap,
  Calendar,
  Coins,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  FileText,
  Search,
  ExternalLink,
  RefreshCw,
  BarChart3
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import client from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function AdminDashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [students, setStudents] = useState([]);
  const [pendingVerifications, setPendingVerifications] = useState([]);
  const [disputes, setDisputes] = useState([]);
  const [ledger, setLedger] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('verifications');
  const [actionMessage, setActionMessage] = useState('');

  // Search in students
  const [studentSearch, setStudentSearch] = useState('');

  const fetchAdminData = async () => {
    try {
      setLoading(true);
      const [statsRes, studentsRes, verifRes, dispRes, ledgRes] = await Promise.all([
        client.get('/admin/stats/'),
        client.get('/admin/students/'),
        client.get('/admin/verifications/'),
        client.get('/admin/disputes/'),
        client.get('/admin/ledger/')
      ]);

      setStats(statsRes.data);
      setStudents(studentsRes.data || []);
      setPendingVerifications(verifRes.data || []);
      setDisputes(dispRes.data || []);
      setLedger(ledgRes.data || []);
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleToggleStudent = async (studentId) => {
    try {
      const res = await client.patch(`/admin/students/${studentId}/status/`);
      setActionMessage(res.data.message);
      fetchAdminData();
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to update student status.');
    }
  };

  const handleVerificationAction = async (pk, action) => {
    const comments = prompt(`Enter comments for ${action}:`) || '';
    try {
      await client.patch(`/admin/verifications/${pk}/`, { action, comments });
      setActionMessage(`Skill verification submission #${pk} marked as ${action}d.`);
      fetchAdminData();
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to update verification status.');
    }
  };

  const handleResolveDispute = async (disputeId, resolution) => {
    const notes = prompt(`Resolution notes for "${resolution}":`) || 'Resolved by Administrator.';
    try {
      await client.patch(`/admin/disputes/${disputeId}/resolve/`, {
        resolution,
        admin_notes: notes,
      });
      setActionMessage(`Dispute #${disputeId} resolved (${resolution}). Ledger balances updated.`);
      fetchAdminData();
      setTimeout(() => setActionMessage(''), 4000);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to resolve dispute.');
    }
  };

  const filteredStudents = students.filter((s) => {
    if (!studentSearch) return true;
    const q = studentSearch.toLowerCase();
    return (
      s.username.toLowerCase().includes(q) ||
      s.email.toLowerCase().includes(q) ||
      s.first_name.toLowerCase().includes(q) ||
      s.last_name.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <ShieldAlert className="w-8 h-8 text-amber-500" />
            Campus Administration Portal
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Section 21: Full administrative oversight, skill approvals, dispute arbitrations & ledger auditing.
          </p>
        </div>

        <button
          onClick={fetchAdminData}
          className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-2 self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh Stats
        </button>
      </div>

      {actionMessage && (
        <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700 rounded-xl text-emerald-800 dark:text-emerald-200 text-xs font-medium flex items-center gap-2 shadow-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          {actionMessage}
        </div>
      )}

      {/* Admin Analytics 4 KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <span className="text-xs font-semibold text-slate-400 block mb-1">Registered Students</span>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {stats?.total_students || 0}
          </div>
          <span className="text-[11px] text-emerald-600 font-medium">
            {stats?.active_students || 0} active accounts
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <span className="text-xs font-semibold text-slate-400 block mb-1">Verified Teaching Skills</span>
          <div className="text-2xl font-black text-primary-600 dark:text-primary-400">
            {stats?.verified_skills || 0}
          </div>
          <span className="text-[11px] text-amber-600 font-medium">
            {stats?.pending_verifications || 0} pending review
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <span className="text-xs font-semibold text-slate-400 block mb-1">Total Learning Sessions</span>
          <div className="text-2xl font-black text-slate-900 dark:text-white">
            {stats?.total_sessions || 0}
          </div>
          <span className="text-[11px] text-emerald-600 font-medium">
            {stats?.completed_sessions || 0} completed
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <span className="text-xs font-semibold text-slate-400 block mb-1">Total Credits Settled</span>
          <div className="text-2xl font-black text-amber-500">
            {stats?.credits_earned || 0} Cr
          </div>
          <span className="text-[11px] text-slate-400 font-medium">
            {stats?.circulating_credits || 0} circulating
          </span>
        </div>
      </div>

      {/* Monthly Activity Analytics Chart */}
      {stats?.completed_by_month && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl shadow-xs space-y-3">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-primary-600" />
            Monthly Campus Learning Activity (Completed Sessions)
          </h3>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.completed_by_month}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1e293b',
                    color: '#fff',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="sessions" fill="#6366f1" radius={[4, 4, 0, 0]} name="Sessions" />
                <Bar dataKey="credits" fill="#10b981" radius={[4, 4, 0, 0]} name="Credits Transferred" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Tabs Row */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3 text-xs font-bold overflow-x-auto">
        <button
          onClick={() => setActiveTab('verifications')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'verifications'
              ? 'bg-primary-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Pending Verifications ({pendingVerifications.length})
        </button>
        <button
          onClick={() => setActiveTab('disputes')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'disputes'
              ? 'bg-primary-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Session Disputes ({disputes.length})
        </button>
        <button
          onClick={() => setActiveTab('students')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'students'
              ? 'bg-primary-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Manage Students ({students.length})
        </button>
        <button
          onClick={() => setActiveTab('ledger')}
          className={`px-4 py-2 rounded-xl transition-all ${
            activeTab === 'ledger'
              ? 'bg-primary-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Global Audit Ledger ({ledger.length})
        </button>
      </div>

      {/* TAB 1: PENDING VERIFICATIONS */}
      {activeTab === 'verifications' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Teaching Skill Verification Submissions
          </h2>

          {pendingVerifications.length === 0 ? (
            <p className="text-xs text-slate-400 py-4">No pending verification requests at this time.</p>
          ) : (
            <div className="space-y-4">
              {pendingVerifications.map((item) => (
                <div
                  key={item.id}
                  className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        {item.skill_name}
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold text-[10px]">
                        Score: {item.verification_score}% ({item.verification_status})
                      </span>
                    </div>

                    <p className="text-slate-500">
                      Submitted by: <strong>{item.student_name}</strong> ({item.student_email}) • {item.college}
                    </p>
                    <p className="text-slate-600 dark:text-slate-300 italic">"{item.description}"</p>

                    {item.portfolio_link && (
                      <a
                        href={item.portfolio_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary-600 font-semibold hover:underline inline-flex items-center gap-1"
                      >
                        Portfolio / Project Link <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleVerificationAction(item.id, 'approve')}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-xs"
                    >
                      Approve Skill
                    </button>
                    <button
                      onClick={() => handleVerificationAction(item.id, 'reject')}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-semibold shadow-xs"
                    >
                      Decline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: DISPUTES RESOLUTION */}
      {activeTab === 'disputes' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Campus Session Disputes & Arbitrations
          </h2>

          {disputes.length === 0 ? (
            <p className="text-xs text-slate-400 py-4">No open disputes reported.</p>
          ) : (
            <div className="space-y-4">
              {disputes.map((d) => (
                <div
                  key={d.id}
                  className="p-5 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        Dispute on Session #{d.session_id} ({d.skill_name})
                      </span>
                      <p className="text-slate-500">
                        Raised by: <strong>{d.raised_by_name}</strong> • Tutor: {d.teacher_name} • Learner: {d.learner_name}
                      </p>
                    </div>

                    <span
                      className={`px-2.5 py-1 rounded-full font-bold text-[10px] ${
                        d.status === 'open'
                          ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                          : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      }`}
                    >
                      {d.status.toUpperCase()}
                    </span>
                  </div>

                  <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1">
                    <p><strong>Dispute Reason:</strong> {d.reason}</p>
                    {d.evidence_text && <p><strong>Evidence:</strong> {d.evidence_text}</p>}
                    <p className="text-amber-600 font-bold">Escrow Amount at Stake: {d.credit_amount} Credits</p>
                  </div>

                  {d.status === 'open' && (
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => handleResolveDispute(d.id, 'refund_learner')}
                        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold"
                      >
                        Refund {d.credit_amount} Credits to Learner
                      </button>
                      <button
                        onClick={() => handleResolveDispute(d.id, 'payout_teacher')}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold"
                      >
                        Release {d.credit_amount} Credits to Teacher
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: MANAGE STUDENTS */}
      {activeTab === 'students' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">Registered Students</h2>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                placeholder="Search students..."
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border rounded-xl"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-2.5 px-3">Student</th>
                  <th className="py-2.5 px-3">College & Dept</th>
                  <th className="py-2.5 px-3">Teaching / Learning Hrs</th>
                  <th className="py-2.5 px-3">Credits Available</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {filteredStudents.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-3">
                      <span className="font-bold text-slate-900 dark:text-white block">
                        {s.first_name} {s.last_name} ({s.username})
                      </span>
                      <span className="text-[10px] text-slate-400">{s.email}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-500">
                      {s.college} ({s.department})
                    </td>
                    <td className="py-3 px-3 text-slate-500">
                      {s.teaching_hours} hrs teach / {s.learning_hours} hrs learn
                    </td>
                    <td className="py-3 px-3 font-bold text-amber-600">
                      {s.credits_available ?? 50} Cr
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          s.is_active
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                        }`}
                      >
                        {s.is_active ? 'ACTIVE' : 'SUSPENDED'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleToggleStudent(s.id)}
                        className={`px-3 py-1 rounded-lg text-xs font-semibold ${
                          s.is_active
                            ? 'bg-rose-50 text-rose-600 hover:bg-rose-100'
                            : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'
                        }`}
                      >
                        {s.is_active ? 'Suspend' : 'Activate'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: GLOBAL AUDIT LEDGER */}
      {activeTab === 'ledger' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-xs space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Platform-Wide Double Entry Credit Ledger
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-2.5 px-3">UUID</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Sender → Receiver</th>
                  <th className="py-2.5 px-3">Credits</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {ledger.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-mono text-[10px] text-slate-400">
                      {tx.transaction_id.slice(0, 8)}...
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-200">
                      {tx.transaction_type_display}
                    </td>
                    <td className="py-2.5 px-3 text-slate-500">
                      {tx.sender_name} → {tx.receiver_name}
                    </td>
                    <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-white">
                      {tx.amount} Cr
                    </td>
                    <td className="py-2.5 px-3 font-bold text-[10px] text-emerald-600">
                      {tx.status}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">
                      {new Date(tx.timestamp).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
