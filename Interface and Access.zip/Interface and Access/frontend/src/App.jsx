import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import DashboardLayout from './layouts/DashboardLayout';
import { ProtectedRoute, AdminRoute } from './layouts/ProtectedRoute';

// Pages
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import ProfilePage from './pages/ProfilePage';
import TeachPage from './pages/TeachPage';
import LearnPage from './pages/LearnPage';
import SkillSwapPage from './pages/SkillSwapPage';
import WalletPage from './pages/WalletPage';
import SessionsPage from './pages/SessionsPage';
import MaterialsPage from './pages/MaterialsPage';
import AchievementsPage from './pages/AchievementsPage';
import NotificationsPage from './pages/NotificationsPage';
import AdminDashboardPage from './pages/AdminDashboardPage';

export default function App() {
  return (
    <Routes>
      {/* Public Pages with Landing Layout */}
      <Route element={<MainLayout />}>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
      </Route>

      {/* Authenticated Dashboard Pages */}
      <Route element={<ProtectedRoute />}>
        <Route element={<DashboardLayout />}>
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/teach" element={<TeachPage />} />
          <Route path="/learn" element={<LearnPage />} />
          <Route path="/swaps" element={<SkillSwapPage />} />
          <Route path="/sessions" element={<SessionsPage />} />
          <Route path="/wallet" element={<WalletPage />} />
          <Route path="/materials" element={<MaterialsPage />} />
          <Route path="/achievements" element={<AchievementsPage />} />
          <Route path="/notifications" element={<NotificationsPage />} />

          {/* Admin Protected Portal */}
          <Route element={<AdminRoute />}>
            <Route path="/admin-portal" element={<AdminDashboardPage />} />
          </Route>
        </Route>
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
