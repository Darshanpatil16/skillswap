import React, { createContext, useContext, useState, useEffect } from 'react';
import client from '../api/client';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [tokens, setTokens] = useState(() => {
    const saved = localStorage.getItem('skillswap_tokens');
    return saved ? JSON.parse(saved) : null;
  });
  const [loading, setLoading] = useState(true);

  const fetchCurrentUser = async () => {
    try {
      const res = await client.get('/auth/me/');
      setUser(res.data);
      localStorage.setItem('skillswap_user', JSON.stringify(res.data));
    } catch (err) {
      console.error('Failed to load user', err);
      setUser(null);
      localStorage.removeItem('skillswap_tokens');
      localStorage.removeItem('skillswap_user');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (tokens?.access) {
      fetchCurrentUser();
    } else {
      setLoading(false);
    }
  }, [tokens]);

  const login = async (usernameOrEmail, password) => {
    const res = await client.post('/auth/login/', {
      username: usernameOrEmail,
      password,
    });
    const { tokens: newTokens, user: userData } = res.data;
    setTokens(newTokens);
    setUser(userData);
    localStorage.setItem('skillswap_tokens', JSON.stringify(newTokens));
    localStorage.setItem('skillswap_user', JSON.stringify(userData));
    return userData;
  };

  const register = async (formData) => {
    const res = await client.post('/auth/register/', formData);
    const { tokens: newTokens, user: userData } = res.data;
    setTokens(newTokens);
    setUser(userData);
    localStorage.setItem('skillswap_tokens', JSON.stringify(newTokens));
    localStorage.setItem('skillswap_user', JSON.stringify(userData));
    return res.data;
  };

  const logout = () => {
    setUser(null);
    setTokens(null);
    localStorage.removeItem('skillswap_tokens');
    localStorage.removeItem('skillswap_user');
  };

  const refreshUserData = async () => {
    if (tokens?.access) {
      await fetchCurrentUser();
    }
  };

  const isAdmin = user?.role === 'admin' || user?.is_superuser || user?.is_staff;

  return (
    <AuthContext.Provider
      value={{
        user,
        tokens,
        loading,
        login,
        register,
        logout,
        refreshUserData,
        isAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
