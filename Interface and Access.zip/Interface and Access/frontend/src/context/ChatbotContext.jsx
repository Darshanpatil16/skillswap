import React, { createContext, useContext, useState, useEffect } from 'react';
import client from '../api/client';
import { useAuth } from './AuthContext';

const ChatbotContext = createContext();

export const ChatbotProvider = ({ children }) => {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [initialLoaded, setInitialLoaded] = useState(false);

  const fetchHistory = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const res = await client.get('/chatbot/history/');
      if (res.data?.messages) {
        setMessages(res.data.messages);
      }
      setInitialLoaded(true);
    } catch (err) {
      console.error('Error fetching chat history', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user && isOpen && !initialLoaded) {
      fetchHistory();
    }
  }, [user, isOpen, initialLoaded]);

  const sendMessage = async (text) => {
    if (!text.trim()) return;

    // Optimistically add user message
    const tempUserMsg = {
      id: Date.now(),
      role: 'user',
      content: text,
      timestamp: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, tempUserMsg]);
    setLoading(true);

    try {
      const res = await client.post('/chatbot/message/', { message: text });
      if (res.data?.response) {
        const assistantMsg = {
          id: Date.now() + 1,
          role: 'assistant',
          content: res.data.response,
          timestamp: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, assistantMsg]);
      }
    } catch (err) {
      const errorMsg = {
        id: Date.now() + 1,
        role: 'assistant',
        content: 'I apologize, but I encountered a network issue communicating with the assistant service. Please check your connection and try again.',
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const clearChat = async () => {
    try {
      setLoading(true);
      const res = await client.post('/chatbot/clear/');
      if (res.data?.messages) {
        setMessages(res.data.messages);
      } else {
        setMessages([]);
      }
    } catch (err) {
      console.error('Failed to clear chat', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleChat = () => setIsOpen((prev) => !prev);

  return (
    <ChatbotContext.Provider
      value={{
        isOpen,
        toggleChat,
        messages,
        loading,
        sendMessage,
        clearChat,
      }}
    >
      {children}
    </ChatbotContext.Provider>
  );
};

export const useChatbot = () => useContext(ChatbotContext);
