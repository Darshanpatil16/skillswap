# Antigravity task – Web Technology

You are working on one engine of the SkillSwap college mini-project.

**GitHub repository:** PASTE_YOUR_GITHUB_REPOSITORY_URL_HERE
**Target folder in repository:** `04_Web_Technology/`
**Engine:** Web Technology

## Task
1. Inspect every file in this folder before making changes.
2. Use the included source code and documentation as the only project-specific evidence. Do not fabricate modules, algorithms, schema fields, tests, or functionality.
3. Prepare this engine folder for a clean GitHub commit. Preserve the folder structure and filenames.
4. Add or improve explanations only when supported by the actual code. Clearly mark any analysis/inference.
5. Do not modify or delete other engine folders or the main application.
6. Do not include secrets, `.env`, credentials, database files, virtual environments, `node_modules`, caches, or generated build output.
7. Before pushing, show the proposed file list and git diff. Do not force-push, rewrite history, or overwrite existing repository content.
8. If the repository URL is still the placeholder, stop and ask for the correct URL.
9. Commit with message: `Add SkillSwap Web Technology engine files`. Push to the repository's current default branch only after confirming the remote and target path.

## Scope
React frontend, component architecture, routing, state/context, API communication, Django REST endpoints, serializers, authentication, styling and build configuration.
