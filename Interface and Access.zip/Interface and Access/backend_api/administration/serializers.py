from rest_framework import serializers
from django.contrib.auth import get_user_model
from accounts.models import StudentProfile
from skills.models import StudentTeachingSkill, SkillCategory
from verification.models import SkillVerification, SkillAssessment
from learning_sessions.models import LearningSession, Dispute
from wallet.models import CreditTransaction

User = get_user_model()

class AdminStudentSerializer(serializers.ModelSerializer):
    college = serializers.CharField(source='profile.college_name', read_only=True)
    department = serializers.CharField(source='profile.department', read_only=True)
    year = serializers.CharField(source='profile.year_of_study', read_only=True)
    teaching_hours = serializers.DecimalField(source='profile.total_teaching_hours', max_digits=6, decimal_places=1, read_only=True)
    learning_hours = serializers.DecimalField(source='profile.total_learning_hours', max_digits=6, decimal_places=1, read_only=True)
    rating = serializers.DecimalField(source='profile.average_rating', max_digits=3, decimal_places=2, read_only=True)
    credits_available = serializers.IntegerField(source='wallet.available_balance', read_only=True)

    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'first_name', 'last_name', 'role',
            'is_active', 'is_verified_student', 'college', 'department',
            'year', 'teaching_hours', 'learning_hours', 'rating', 'credits_available',
            'created_at'
        ]


class AdminPendingVerificationSerializer(serializers.ModelSerializer):
    student_id = serializers.CharField(source='student.id', read_only=True)
    student_name = serializers.CharField(source='student.username', read_only=True)
    student_email = serializers.CharField(source='student.email', read_only=True)
    college = serializers.CharField(source='student.profile.college_name', read_only=True)
    skill_name = serializers.CharField(source='skill.name', read_only=True)
    category_name = serializers.CharField(source='skill.category.name', read_only=True)

    class Meta:
        model = StudentTeachingSkill
        fields = [
            'id', 'student_id', 'student_name', 'student_email', 'college',
            'skill_name', 'category_name', 'experience_level', 'experience_duration',
            'description', 'topics_offered', 'certificate_file', 'portfolio_link',
            'verification_status', 'verification_score', 'verification_note',
            'is_published', 'created_at'
        ]


class AdminDisputeSerializer(serializers.ModelSerializer):
    raised_by_name = serializers.CharField(source='raised_by.username', read_only=True)
    teacher_name = serializers.CharField(source='session.teacher.username', read_only=True)
    learner_name = serializers.CharField(source='session.learner.username', read_only=True)
    skill_name = serializers.CharField(source='session.skill.name', read_only=True)
    credit_amount = serializers.IntegerField(source='session.credit_amount', read_only=True)

    class Meta:
        model = Dispute
        fields = [
            'id', 'session_id', 'raised_by_name', 'teacher_name', 'learner_name',
            'skill_name', 'credit_amount', 'reason', 'evidence_text',
            'status', 'admin_notes', 'created_at', 'resolved_at'
        ]
