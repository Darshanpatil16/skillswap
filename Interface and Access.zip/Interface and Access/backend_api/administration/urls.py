from django.urls import path
from .views import (
    AdminPlatformStatsView,
    AdminStudentListView,
    AdminToggleStudentStatusView,
    AdminVerificationsView,
    AdminDisputesView,
    AdminLedgerView
)

urlpatterns = [
    path('admin/stats/', AdminPlatformStatsView.as_view(), name='admin_stats'),
    path('admin/students/', AdminStudentListView.as_view(), name='admin_students'),
    path('admin/students/<str:pk>/status/', AdminToggleStudentStatusView.as_view(), name='admin_toggle_student'),
    path('admin/verifications/', AdminVerificationsView.as_view(), name='admin_verifications'),
    path('admin/verifications/<str:pk>/', AdminVerificationsView.as_view(), name='admin_verification_action'),
    path('admin/disputes/', AdminDisputesView.as_view(), name='admin_disputes'),
    path('admin/disputes/<str:pk>/resolve/', AdminDisputesView.as_view(), name='admin_resolve_dispute'),
    path('admin/ledger/', AdminLedgerView.as_view(), name='admin_ledger'),
]
