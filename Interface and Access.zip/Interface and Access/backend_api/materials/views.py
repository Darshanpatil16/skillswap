from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q
from .models import LearningMaterial
from .serializers import LearningMaterialSerializer
from skills.models import Skill
from learning_sessions.models import LearningSession

ALLOWED_EXTENSIONS = {'pdf', 'ppt', 'pptx', 'doc', 'docx', 'png', 'jpg', 'jpeg', 'webp', 'zip', 'py', 'txt'}
MAX_UPLOAD_SIZE = 10 * 1024 * 1024 # 10 MB

class LearningMaterialListUploadView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        skill_id = request.query_params.get('skill_id')
        session_id = request.query_params.get('session_id')

        # Accessible materials:
        # 1. Uploaded by me
        # 2. Public materials
        # 3. Associated with a session I am a participant of (as teacher or learner)
        my_session_ids = LearningSession.objects.filter(
            Q(teacher=user) | Q(learner=user)
        ).values_list('id', flat=True)

        materials = LearningMaterial.objects.filter(
            Q(uploaded_by=user) |
            Q(is_public=True) |
            Q(session_id__in=my_session_ids)
        ).select_related('skill', 'uploaded_by')

        if skill_id:
            materials = materials.filter(skill_id=skill_id)
        if session_id:
            materials = materials.filter(session_id=session_id)

        return Response(LearningMaterialSerializer(materials.distinct(), many=True).data)

    def post(self, request):
        user = request.user
        skill_id = request.data.get('skill')
        skill = Skill.objects.filter(id=skill_id).first()
        if not skill:
            return Response({'error': 'Skill not found.'}, status=status.HTTP_404_NOT_FOUND)

        uploaded_file = request.FILES.get('file')
        external_link = request.data.get('external_link', '').strip()

        if not uploaded_file and not external_link:
            return Response({'error': 'Please provide either a resource file or an external link.'}, status=status.HTTP_400_BAD_REQUEST)

        file_size = 0
        if uploaded_file:
            if uploaded_file.size > MAX_UPLOAD_SIZE:
                return Response({'error': 'File size exceeds maximum allowed limit (10 MB).'}, status=status.HTTP_400_BAD_REQUEST)
            ext = uploaded_file.name.split('.')[-1].lower()
            if ext not in ALLOWED_EXTENSIONS:
                return Response({'error': f'Unsupported file type ".{ext}". Allowed: PDF, PPTX, DOCX, images, code.'}, status=status.HTTP_400_BAD_REQUEST)
            file_size = uploaded_file.size

        session_id = request.data.get('session')
        session_obj = None
        if session_id:
            session_obj = LearningSession.objects.filter(id=session_id, teacher=user).first()

        material = LearningMaterial.objects.create(
            uploaded_by=user,
            skill=skill,
            session=session_obj,
            title=request.data.get('title', 'Learning Resource'),
            description=request.data.get('description', ''),
            material_type=request.data.get('material_type', 'pdf'),
            file=uploaded_file,
            external_link=external_link,
            file_size_bytes=file_size,
            is_public=request.data.get('is_public', False) in (True, 'true', 'True', 1)
        )

        return Response(LearningMaterialSerializer(material).data, status=status.HTTP_201_CREATED)
