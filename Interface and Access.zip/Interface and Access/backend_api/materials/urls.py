from django.urls import path
from .views import LearningMaterialListUploadView

urlpatterns = [
    path('materials/', LearningMaterialListUploadView.as_view(), name='materials_list_upload'),
]
