from rest_framework import serializers
from .models import LearningMaterial
from accounts.serializers import UserShortSerializer
from skills.serializers import SkillSerializer

class LearningMaterialSerializer(serializers.ModelSerializer):
    uploader_name = serializers.CharField(source='uploaded_by.username', read_only=True)
    skill_name = serializers.CharField(source='skill.name', read_only=True)
    file_url = serializers.SerializerMethodField()

    class Meta:
        model = LearningMaterial
        fields = [
            'id', 'title', 'description', 'material_type', 'skill', 'skill_name',
            'session', 'uploaded_by', 'uploader_name', 'file', 'file_url',
            'external_link', 'file_size_bytes', 'is_public', 'created_at'
        ]
        read_only_fields = ['uploaded_by', 'file_size_bytes', 'created_at']

    def get_file_url(self, obj):
        if obj.file:
            return obj.file.url
        return None
