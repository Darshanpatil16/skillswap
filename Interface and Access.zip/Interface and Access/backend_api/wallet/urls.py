from django.urls import path
from .views import MyWalletView, MyTransactionsView

urlpatterns = [
    path('wallet/', MyWalletView.as_view(), name='my_wallet'),
    path('wallet/transactions/', MyTransactionsView.as_view(), name='my_transactions'),
]
