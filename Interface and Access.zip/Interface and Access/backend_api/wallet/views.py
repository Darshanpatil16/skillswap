from rest_framework import permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q
from .models import CreditWallet, CreditTransaction
from .serializers import CreditWalletSerializer, CreditTransactionSerializer
from .services import WalletService

class MyWalletView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        wallet, created = CreditWallet.objects.get_or_create(
            user=request.user,
            defaults={'available_balance': 50, 'escrow_balance': 0, 'total_earned': 0, 'total_spent': 0}
        )
        if created:
            WalletService.create_initial_wallet(request.user)
            wallet.refresh_from_db()

        return Response(CreditWalletSerializer(wallet).data)


class MyTransactionsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        txs = CreditTransaction.objects.filter(
            Q(sender=user) | Q(receiver=user)
        ).select_related('sender', 'receiver')

        # Filters
        tx_type = request.query_params.get('type')
        if tx_type:
            if tx_type == 'earned':
                txs = txs.filter(receiver=user, transaction_type='session_payout')
            elif tx_type == 'spent':
                txs = txs.filter(sender=user, transaction_type='session_payout')
            elif tx_type == 'refund':
                txs = txs.filter(transaction_type='session_refund')
            elif tx_type == 'bonus':
                txs = txs.filter(transaction_type='registration_bonus')
            elif tx_type == 'escrow':
                txs = txs.filter(transaction_type='session_escrow')
            else:
                txs = txs.filter(transaction_type=tx_type)

        status_filter = request.query_params.get('status')
        if status_filter:
            txs = txs.filter(status=status_filter)

        return Response(CreditTransactionSerializer(txs[:100], many=True).data)
