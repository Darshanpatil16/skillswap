from rest_framework import serializers
from .models import CreditWallet, CreditTransaction
from accounts.serializers import UserShortSerializer

class CreditWalletSerializer(serializers.ModelSerializer):
    user = UserShortSerializer(read_only=True)
    total_balance = serializers.IntegerField(read_only=True)

    class Meta:
        model = CreditWallet
        fields = [
            'id', 'user', 'available_balance', 'escrow_balance', 
            'total_balance', 'total_earned', 'total_spent', 
            'created_at', 'updated_at'
        ]
        read_only_fields = ['available_balance', 'escrow_balance', 'total_earned', 'total_spent']


class CreditTransactionSerializer(serializers.ModelSerializer):
    sender_name = serializers.CharField(source='sender.username', read_only=True, default='SkillSwap System')
    receiver_name = serializers.CharField(source='receiver.username', read_only=True, default='SkillSwap Escrow')
    transaction_type_display = serializers.CharField(source='get_transaction_type_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = CreditTransaction
        fields = [
            'id', 'transaction_id', 'sender', 'sender_name', 
            'receiver', 'receiver_name', 'session_id', 
            'transaction_type', 'transaction_type_display', 
            'amount', 'sender_previous_balance', 'sender_updated_balance', 
            'receiver_previous_balance', 'receiver_updated_balance', 
            'status', 'status_display', 'description', 'timestamp'
        ]
