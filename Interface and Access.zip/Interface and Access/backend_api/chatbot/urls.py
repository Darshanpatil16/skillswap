from django.urls import path
from .views import (
    ChatHistoryView,
    ChatSendMessageView,
    ChatClearView
)

urlpatterns = [
    path('chatbot/history/', ChatHistoryView.as_view(), name='chatbot_history'),
    path('chatbot/message/', ChatSendMessageView.as_view(), name='chatbot_message'),
    path('chatbot/clear/', ChatClearView.as_view(), name='chatbot_clear'),
]
