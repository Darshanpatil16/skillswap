from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import ChatConversation, ChatMessage
from .serializers import ChatConversationSerializer, ChatMessageSerializer
from .services import ChatbotService

class ChatHistoryView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        conv = ChatbotService.get_or_create_conversation(request.user)
        return Response(ChatConversationSerializer(conv).data)


class ChatSendMessageView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        prompt = request.data.get('message', '').strip()
        if not prompt:
            return Response({'error': 'Message cannot be empty.'}, status=status.HTTP_400_BAD_REQUEST)

        conv = ChatbotService.get_or_create_conversation(request.user)
        reply = ChatbotService.generate_response(request.user, prompt, conv)

        latest_messages = ChatMessage.objects.filter(conversation=conv).order_by('-timestamp')[:2]
        return Response({
            'response': reply,
            'messages': ChatMessageSerializer(reversed(list(latest_messages)), many=True).data
        })


class ChatClearView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        ChatConversation.objects.filter(user=request.user).delete()
        new_conv = ChatbotService.get_or_create_conversation(request.user)
        return Response(ChatConversationSerializer(new_conv).data)
