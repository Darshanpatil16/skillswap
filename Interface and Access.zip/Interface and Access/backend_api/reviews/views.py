from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth import get_user_model
from .models import Review
from .serializers import ReviewSerializer, SubmitReviewSerializer
from learning_sessions.models import LearningSession
from notifications.models import Notification
from achievements.services import AchievementService

User = get_user_model()

class SubmitReviewView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = SubmitReviewSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        session = LearningSession.objects.filter(id=data['session_id']).select_related('teacher', 'learner', 'skill').first()

        if not session:
            return Response({'error': 'Session not found.'}, status=status.HTTP_404_NOT_FOUND)

        if session.learner != request.user:
            return Response({'error': 'Only the learner of this session can submit a tutor review.'}, status=status.HTTP_403_FORBIDDEN)

        if session.status != 'completed':
            return Response({'error': 'Reviews can only be submitted for completed sessions.'}, status=status.HTTP_400_BAD_REQUEST)

        if hasattr(session, 'review'):
            return Response({'error': 'You have already submitted a review for this session.'}, status=status.HTTP_400_BAD_REQUEST)

        review = Review.objects.create(
            session=session,
            reviewer=request.user,
            teacher=session.teacher,
            skill=session.skill,
            subject_knowledge=data['subject_knowledge'],
            teaching_clarity=data['teaching_clarity'],
            communication=data['communication'],
            time_management=data['time_management'],
            feedback_comment=data['feedback_comment']
        )

        AchievementService.evaluate_user_achievements(session.teacher)

        Notification.objects.create(
            user=session.teacher,
            title="⭐ New Student Review Received!",
            message=f"{request.user.username} rated your {session.skill.name} session {review.overall_rating}/5.0: \"{review.feedback_comment[:60]}...\"",
            notification_type='review_received',
            link_url='/profile'
        )

        return Response(ReviewSerializer(review).data, status=status.HTTP_201_CREATED)


class TutorReviewListView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request, user_id):
        tutor = User.objects.filter(id=user_id).first()
        if not tutor:
            return Response({'error': 'Tutor not found.'}, status=status.HTTP_404_NOT_FOUND)

        reviews = Review.objects.filter(teacher=tutor).select_related('reviewer', 'skill')
        return Response(ReviewSerializer(reviews, many=True).data)
