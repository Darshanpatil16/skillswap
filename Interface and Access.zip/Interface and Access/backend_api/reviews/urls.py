from django.urls import path
from .views import SubmitReviewView, TutorReviewListView

urlpatterns = [
    path('reviews/', SubmitReviewView.as_view(), name='submit_review'),
    path('reviews/tutor/<str:user_id>/', TutorReviewListView.as_view(), name='tutor_reviews'),
]
