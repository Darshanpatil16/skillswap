from rest_framework import serializers
from .models import Review
from accounts.serializers import UserShortSerializer
from skills.serializers import SkillSerializer

class ReviewSerializer(serializers.ModelSerializer):
    reviewer_name = serializers.CharField(source='reviewer.username', read_only=True)
    teacher_name = serializers.CharField(source='teacher.username', read_only=True)
    skill_name = serializers.CharField(source='skill.name', read_only=True)

    class Meta:
        model = Review
        fields = [
            'id', 'session', 'reviewer', 'reviewer_name', 'teacher', 'teacher_name',
            'skill', 'skill_name', 'subject_knowledge', 'teaching_clarity',
            'communication', 'time_management', 'overall_rating', 'feedback_comment',
            'created_at'
        ]
        read_only_fields = ['reviewer', 'teacher', 'skill', 'overall_rating', 'created_at']


class SubmitReviewSerializer(serializers.Serializer):
    session_id = serializers.CharField()
    subject_knowledge = serializers.IntegerField(min_value=1, max_value=5, default=5)
    teaching_clarity = serializers.IntegerField(min_value=1, max_value=5, default=5)
    communication = serializers.IntegerField(min_value=1, max_value=5, default=5)
    time_management = serializers.IntegerField(min_value=1, max_value=5, default=5)
    feedback_comment = serializers.CharField(min_length=5)
