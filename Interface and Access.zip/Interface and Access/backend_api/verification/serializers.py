from rest_framework import serializers
from .models import AssessmentQuestion, SkillAssessment, AssessmentAnswer, SkillVerification
from skills.serializers import SkillSerializer

class AssessmentQuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssessmentQuestion
        fields = ['id', 'skill', 'question_type', 'question_text', 'options', 'difficulty']
        # Do not expose correct_option_id or sample_answer to the student before submission


class AssessmentAnswerSubmissionSerializer(serializers.Serializer):
    question_id = serializers.CharField()
    selected_option_id = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    descriptive_response = serializers.CharField(required=False, allow_blank=True, allow_null=True)


class AssessmentSubmitSerializer(serializers.Serializer):
    answers = AssessmentAnswerSubmissionSerializer(many=True)


class SkillAssessmentSerializer(serializers.ModelSerializer):
    skill_name = serializers.CharField(source='teaching_skill.skill.name', read_only=True)

    class Meta:
        model = SkillAssessment
        fields = ['id', 'student', 'teaching_skill', 'skill_name', 'score', 'status', 'started_at', 'completed_at', 'automated_feedback']


class SkillVerificationSerializer(serializers.ModelSerializer):
    teaching_skill_id = serializers.CharField(source='teaching_skill.id', read_only=True)
    skill_name = serializers.CharField(source='teaching_skill.skill.name', read_only=True)
    student_name = serializers.CharField(source='teaching_skill.student.username', read_only=True)

    class Meta:
        model = SkillVerification
        fields = ['id', 'teaching_skill_id', 'skill_name', 'student_name', 'outcome', 'score', 'review_comments', 'verified_at', 'updated_at']
