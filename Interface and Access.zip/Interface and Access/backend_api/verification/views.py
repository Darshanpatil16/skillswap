from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.utils import timezone
from .models import AssessmentQuestion, SkillAssessment, AssessmentAnswer, SkillVerification
from .serializers import (
    AssessmentQuestionSerializer,
    AssessmentSubmitSerializer,
    SkillAssessmentSerializer,
    SkillVerificationSerializer
)
from skills.models import StudentTeachingSkill, Skill
from notifications.models import Notification
from achievements.services import AchievementService

class SkillAssessmentQuestionView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, teaching_skill_id):
        teaching_skill = StudentTeachingSkill.objects.filter(
            id=teaching_skill_id,
            student=request.user
        ).select_related('skill', 'skill__category').first()

        if not teaching_skill:
            return Response({'error': 'Teaching skill not found or does not belong to you.'}, status=status.HTTP_404_NOT_FOUND)

        skill = teaching_skill.skill
        questions = AssessmentQuestion.objects.filter(skill=skill)

        # If question bank is empty for this skill, auto-generate standard dynamic assessment questions
        if not questions.exists():
            seed_skill_questions(skill)
            questions = AssessmentQuestion.objects.filter(skill=skill)

        # Create or fetch active assessment session
        assessment, created = SkillAssessment.objects.get_or_create(
            student=request.user,
            teaching_skill=teaching_skill,
            status='in_progress',
            defaults={'started_at': timezone.now()}
        )

        return Response({
            'assessment_id': assessment.id,
            'skill_name': skill.name,
            'category_name': skill.category.name,
            'questions': AssessmentQuestionSerializer(questions, many=True).data
        })


class SkillAssessmentSubmitView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, teaching_skill_id):
        teaching_skill = StudentTeachingSkill.objects.filter(
            id=teaching_skill_id,
            student=request.user
        ).select_related('skill').first()

        if not teaching_skill:
            return Response({'error': 'Teaching skill not found.'}, status=status.HTTP_404_NOT_FOUND)

        serializer = AssessmentSubmitSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        answers_data = serializer.validated_data['answers']
        if not answers_data:
            return Response({'error': 'No answers submitted.'}, status=status.HTTP_400_BAD_REQUEST)

        assessment = SkillAssessment.objects.filter(
            student=request.user,
            teaching_skill=teaching_skill
        ).order_by('-started_at').first()

        if not assessment:
            assessment = SkillAssessment.objects.create(
                student=request.user,
                teaching_skill=teaching_skill,
                status='in_progress'
            )

        total_questions = len(answers_data)
        total_points = 0.0

        for item in answers_data:
            q_id = item['question_id']
            question = AssessmentQuestion.objects.filter(id=q_id).first()
            if not question:
                continue

            points = 0.0
            is_correct = False

            if question.question_type == 'mcq':
                user_choice = (item.get('selected_option_id') or '').strip().upper()
                if user_choice and user_choice == (question.correct_option_id or '').strip().upper():
                    is_correct = True
                    points = 1.0
            elif question.question_type in ('descriptive', 'code_task'):
                text = (item.get('descriptive_response') or '').strip()
                # Basic rubric check: length and conceptual depth
                if len(text) > 40:
                    is_correct = True
                    points = 1.0
                elif len(text) > 15:
                    is_correct = True
                    points = 0.5

            total_points += points

            AssessmentAnswer.objects.update_or_create(
                assessment=assessment,
                question=question,
                defaults={
                    'selected_option_id': item.get('selected_option_id'),
                    'descriptive_response': item.get('descriptive_response'),
                    'is_correct': is_correct,
                    'points_awarded': points
                }
            )

        percentage_score = round((total_points / max(total_questions, 1)) * 100)
        assessment.score = percentage_score
        assessment.status = 'evaluated'
        assessment.completed_at = timezone.now()

        # Determine verification tier
        if percentage_score >= 80:
            outcome = 'verified'
            feedback = f"Outstanding performance! You scored {percentage_score}%. Your teaching skill is now VERIFIED and visible in tutor searches."
            teaching_skill.verification_status = 'verified'
            teaching_skill.verification_score = percentage_score
            teaching_skill.is_published = True
            teaching_skill.save()

            # Award achievements
            AchievementService.evaluate_user_achievements(request.user)

            Notification.objects.create(
                user=request.user,
                title="🛡️ Skill Verification Passed!",
                message=f"Congratulations! You scored {percentage_score}% in {teaching_skill.skill.name} and are now a Verified Tutor.",
                notification_type='verification_result',
                link_url='/teach'
            )
        elif percentage_score >= 60:
            outcome = 'provisional'
            feedback = f"Good effort! You scored {percentage_score}%. Your submission has been flagged for Provisional Review by campus administration."
            teaching_skill.verification_status = 'provisional'
            teaching_skill.verification_score = percentage_score
            teaching_skill.is_published = False
            teaching_skill.save()

            Notification.objects.create(
                user=request.user,
                title="📋 Provisional Verification Review",
                message=f"Your {teaching_skill.skill.name} assessment scored {percentage_score}% and is awaiting administrator review.",
                notification_type='verification_result',
                link_url='/teach'
            )
        else:
            outcome = 'rejected'
            feedback = f"You scored {percentage_score}%. Minimum passing score is 80%. Please review the subject material and retake the assessment."
            teaching_skill.verification_status = 'rejected'
            teaching_skill.verification_score = percentage_score
            teaching_skill.is_published = False
            teaching_skill.save()

            Notification.objects.create(
                user=request.user,
                title="❌ Skill Assessment Not Passed",
                message=f"You scored {percentage_score}% in {teaching_skill.skill.name}. You may retake the assessment when ready.",
                notification_type='verification_result',
                link_url='/teach'
            )

        assessment.automated_feedback = feedback
        assessment.save()

        # Update or create SkillVerification record
        SkillVerification.objects.update_or_create(
            teaching_skill=teaching_skill,
            defaults={
                'assessment': assessment,
                'outcome': outcome,
                'score': percentage_score,
                'review_comments': feedback
            }
        )

        return Response({
            'score': percentage_score,
            'outcome': outcome,
            'feedback': feedback,
            'teaching_skill': {
                'id': teaching_skill.id,
                'verification_status': teaching_skill.verification_status,
                'is_published': teaching_skill.is_published,
                'hourly_rate': teaching_skill.hourly_rate
            }
        })


def seed_skill_questions(skill):
    """Generates 5 tailored assessment questions per skill covering MCQs and descriptive tasks."""
    sname = skill.name.lower()
    cname = skill.category.name.lower()

    if 'photo' in sname or 'photoshop' in sname:
        questions = [
            {
                "type": "mcq",
                "text": "What is the primary difference between raster graphics and vector graphics in Adobe Photoshop?",
                "options": [
                    {"id": "A", "text": "Raster graphics are based on pixels that lose quality when scaled, while vector graphics are mathematically defined paths."},
                    {"id": "B", "text": "Raster graphics can only be printed in black and white."},
                    {"id": "C", "text": "Vector graphics are only supported on macOS devices."},
                    {"id": "D", "text": "There is no difference; they are identical formats."}
                ],
                "correct": "A"
            },
            {
                "type": "mcq",
                "text": "What is the primary purpose of using Layer Masks rather than the Eraser Tool?",
                "options": [
                    {"id": "A", "text": "Layer masks permanently erase the pixels to reduce file size."},
                    {"id": "B", "text": "Layer masks allow non-destructive editing, enabling you to reveal or hide portions at any time."},
                    {"id": "C", "text": "Layer masks automatically vectorize bitmap images."},
                    {"id": "D", "text": "Layer masks can only be used on 3D layers."}
                ],
                "correct": "B"
            },
            {
                "type": "mcq",
                "text": "Which tool in Photoshop provides the most precise manual control for background removal around complex subject edges?",
                "options": [
                    {"id": "A", "text": "Pen Tool with Path to Selection"},
                    {"id": "B", "text": "Paint Bucket Tool"},
                    {"id": "C", "text": "Crop Tool"},
                    {"id": "D", "text": "Gradient Map"}
                ],
                "correct": "A"
            },
            {
                "type": "descriptive",
                "text": "Explain how you would adjust color balance, contrast, and levels in a portrait photograph to create a balanced, professional tone.",
                "options": [],
                "correct": ""
            },
            {
                "type": "descriptive",
                "text": "Describe your step-by-step workflow for creating a professional promotional event poster from scratch in Photoshop.",
                "options": [],
                "correct": ""
            }
        ]
    elif 'python' in sname:
        questions = [
            {
                "type": "mcq",
                "text": "What is the fundamental difference between a Python list and a tuple?",
                "options": [
                    {"id": "A", "text": "Lists are mutable and defined with square brackets [], while tuples are immutable and defined with parentheses ()."},
                    {"id": "B", "text": "Lists can only hold integers, while tuples can hold any type."},
                    {"id": "C", "text": "Tuples cannot be indexed or iterated."},
                    {"id": "D", "text": "Lists require explicit type casting for every element."}
                ],
                "correct": "A"
            },
            {
                "type": "mcq",
                "text": "In Python, which built-in function returns both the index and value during an iteration over an iterable?",
                "options": [
                    {"id": "A", "text": "enumerate()"},
                    {"id": "B", "text": "zip()"},
                    {"id": "C", "text": "range()"},
                    {"id": "D", "text": "indexof()"}
                ],
                "correct": "A"
            },
            {
                "type": "mcq",
                "text": "What does the `*args` syntax in a Python function definition accomplish?",
                "options": [
                    {"id": "A", "text": "Multiplies all arguments by a scalar value."},
                    {"id": "B", "text": "Allows a function to accept an arbitrary number of positional arguments as a tuple."},
                    {"id": "C", "text": "Forces the function to run asynchronously."},
                    {"id": "D", "text": "Restricts arguments to string types only."}
                ],
                "correct": "B"
            },
            {
                "type": "descriptive",
                "text": "Explain the four core principles of Object-Oriented Programming (OOP) in Python and provide a brief example of Encapsulation or Inheritance.",
                "options": [],
                "correct": ""
            },
            {
                "type": "code_task",
                "text": "Write a clean Python function named `count_word_frequencies(sentence)` that takes a string and returns a dictionary of words and their counts, ignoring case.",
                "options": [],
                "correct": ""
            }
        ]
    else:
        # High-quality general subject assessment
        questions = [
            {
                "type": "mcq",
                "text": f"Which foundational concept is considered essential for students mastering {skill.name}?",
                "options": [
                    {"id": "A", "text": "Core theoretical principles, standard workflows, and structured problem solving."},
                    {"id": "B", "text": "Relying strictly on automated default presets without manual inspection."},
                    {"id": "C", "text": "Skipping documentation and working without version control."},
                    {"id": "D", "text": "Memorizing superficial shortcuts without conceptual understanding."}
                ],
                "correct": "A"
            },
            {
                "type": "mcq",
                "text": f"When mentoring a beginner student in {skill.name}, what is the best teaching strategy?",
                "options": [
                    {"id": "A", "text": "Break down complex topics into bite-sized, interactive hands-on exercises with immediate feedback."},
                    {"id": "B", "text": "Lecture continuously for 3 hours without answering questions."},
                    {"id": "C", "text": "Require them to read 500 pages before attempting anything."},
                    {"id": "D", "text": "Give them advanced edge cases on day one."}
                ],
                "correct": "A"
            },
            {
                "type": "mcq",
                "text": f"How do you troubleshoot or debug an unexpected error or bottleneck in {skill.name}?",
                "options": [
                    {"id": "A", "text": "Isolate the problem systematically, reproduce the issue, inspect logs/inspectors, and verify step-by-step."},
                    {"id": "B", "text": "Delete the entire project and start over every time."},
                    {"id": "C", "text": "Ignore the error and hope it goes away."},
                    {"id": "D", "text": "Change random settings until something looks different."}
                ],
                "correct": "A"
            },
            {
                "type": "descriptive",
                "text": f"Summarize the key topics and hands-on exercises you plan to teach in your first 2 sessions of {skill.name}.",
                "options": [],
                "correct": ""
            },
            {
                "type": "descriptive",
                "text": f"Describe a real-world project or practical scenario where {skill.name} is applied to solve a concrete problem.",
                "options": [],
                "correct": ""
            }
        ]

    for q in questions:
        AssessmentQuestion.objects.create(
            skill=skill,
            question_type=q['type'],
            question_text=q['text'],
            options=q['options'],
            correct_option_id=q.get('correct', ''),
            difficulty='medium'
        )
