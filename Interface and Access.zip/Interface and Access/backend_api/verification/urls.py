from django.urls import path
from .views import (
    SkillAssessmentQuestionView,
    SkillAssessmentSubmitView
)

urlpatterns = [
    path('verification/skills/<str:teaching_skill_id>/questions/', SkillAssessmentQuestionView.as_view(), name='assessment_questions'),
    path('verification/skills/<str:teaching_skill_id>/submit/', SkillAssessmentSubmitView.as_view(), name='assessment_submit'),
]
