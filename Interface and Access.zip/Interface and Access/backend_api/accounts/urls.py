from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    RegisterView,
    LoginView,
    CurrentUserView,
    ProfileDetailView,
    AvailabilityListCreateView
)

urlpatterns = [
    path('auth/register/', RegisterView.as_view(), name='register'),
    path('auth/login/', LoginView.as_view(), name='login'),
    path('auth/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('auth/me/', CurrentUserView.as_view(), name='current_user'),
    path('profiles/me/', ProfileDetailView.as_view(), name='my_profile'),
    path('profiles/<str:pk>/', ProfileDetailView.as_view(), name='user_profile'),
    path('profiles/me/availabilities/', AvailabilityListCreateView.as_view(), name='my_availabilities'),
    path('profiles/<str:user_id>/availabilities/', AvailabilityListCreateView.as_view(), name='user_availabilities'),
]
