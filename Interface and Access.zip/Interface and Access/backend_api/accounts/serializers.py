from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import StudentProfile, Availability
from skills.models import Skill, StudentTeachingSkill, StudentLearningInterest
from wallet.services import WalletService

User = get_user_model()

class UserShortSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name', 'email', 'role']


class AvailabilitySerializer(serializers.ModelSerializer):
    day_name = serializers.CharField(source='get_day_of_week_display', read_only=True)

    class Meta:
        model = Availability
        fields = ['id', 'day_of_week', 'day_name', 'start_time', 'end_time', 'is_active']


class StudentProfileSerializer(serializers.ModelSerializer):
    user = UserShortSerializer(read_only=True)
    completion_percentage = serializers.IntegerField(read_only=True)

    class Meta:
        model = StudentProfile
        fields = [
            'id', 'user', 'college_name', 'department', 'year_of_study', 
            'bio', 'profile_picture', 'learning_goals', 'preferred_categories', 
            'teaching_mode', 'total_teaching_hours', 'total_learning_hours', 
            'average_rating', 'total_reviews', 'completed_sessions', 
            'completion_percentage', 'created_at', 'updated_at'
        ]
        read_only_fields = ['total_teaching_hours', 'total_learning_hours', 'average_rating', 'total_reviews', 'completed_sessions']


class UserDetailSerializer(serializers.ModelSerializer):
    profile = StudentProfileSerializer(read_only=True)
    wallet_balance = serializers.SerializerMethodField()
    wallet_escrow = serializers.SerializerMethodField()
    availabilities = AvailabilitySerializer(many=True, read_only=True)

    class Meta:
        model = User
        fields = [
            'id', 'username', 'email', 'first_name', 'last_name', 'role', 
            'phone_number', 'is_verified_student', 'profile', 
            'wallet_balance', 'wallet_escrow', 'availabilities'
        ]

    def get_wallet_balance(self, obj):
        return getattr(getattr(obj, 'wallet', None), 'available_balance', 0)

    def get_wallet_escrow(self, obj):
        return getattr(getattr(obj, 'wallet', None), 'escrow_balance', 0)


class MultiStepRegisterSerializer(serializers.Serializer):
    # Step 1: Personal Info
    full_name = serializers.CharField(max_length=150)
    username = serializers.CharField(max_length=150)
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, min_length=6)
    confirm_password = serializers.CharField(write_only=True, min_length=6)
    college_name = serializers.CharField(max_length=200, required=False, default='SkillSwap University')
    department = serializers.CharField(max_length=150, required=False, default='Computer Science')
    year_of_study = serializers.CharField(max_length=30, required=False, default='2nd Year')
    phone_number = serializers.CharField(max_length=20, required=False, allow_blank=True)

    # Step 2: Learning Interests
    learning_interests = serializers.ListField(child=serializers.CharField(), required=False, default=list)
    preferred_categories = serializers.ListField(child=serializers.CharField(), required=False, default=list)
    learning_goals = serializers.CharField(required=False, allow_blank=True, default='')

    # Step 3: Teaching Preferences
    wants_to_teach = serializers.BooleanField(required=False, default=False)
    teaching_skills = serializers.ListField(child=serializers.CharField(), required=False, default=list)
    teaching_experience_level = serializers.CharField(required=False, default='intermediate')
    teaching_experience_duration = serializers.CharField(required=False, default='1 year')
    teaching_mode = serializers.CharField(required=False, default='online')

    def validate_username(self, value):
        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError("This username is already taken. Please choose another.")
        return value

    def validate_email(self, value):
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError("An account with this email address already exists.")
        return value

    def validate(self, attrs):
        if attrs.get('password') != attrs.get('confirm_password'):
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})
        return attrs

    def create(self, validated_data):
        full_name = validated_data.pop('full_name', '').strip()
        names = full_name.split(' ', 1)
        first_name = names[0] if names else ''
        last_name = names[1] if len(names) > 1 else ''

        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            first_name=first_name,
            last_name=last_name,
            phone_number=validated_data.get('phone_number', ''),
            role='student'
        )

        # Create Profile
        StudentProfile.objects.create(
            user=user,
            college_name=validated_data.get('college_name', 'SkillSwap University'),
            department=validated_data.get('department', 'Computer Science'),
            year_of_study=validated_data.get('year_of_study', '2nd Year'),
            learning_goals=validated_data.get('learning_goals', ''),
            preferred_categories=validated_data.get('preferred_categories', []),
            teaching_mode=validated_data.get('teaching_mode', 'online')
        )

        # Create Wallet with 50 credits & transaction ledger entry
        WalletService.create_initial_wallet(user)

        # Save Learning Interests if skills exist
        for skill_name in validated_data.get('learning_interests', []):
            skill = Skill.objects.filter(name__iexact=skill_name.strip()).first()
            if skill:
                StudentLearningInterest.objects.get_or_create(
                    student=user,
                    skill=skill,
                    defaults={'preferred_level': 'beginner'}
                )

        # Save Teaching Skills if requested
        if validated_data.get('wants_to_teach'):
            for skill_name in validated_data.get('teaching_skills', []):
                skill = Skill.objects.filter(name__iexact=skill_name.strip()).first()
                if skill:
                    StudentTeachingSkill.objects.get_or_create(
                        student=user,
                        skill=skill,
                        defaults={
                            'experience_level': validated_data.get('teaching_experience_level', 'intermediate'),
                            'experience_duration': validated_data.get('teaching_experience_duration', '1 year'),
                            'description': f"Confident in teaching {skill.name}.",
                            'verification_status': 'pending',
                            'is_published': False
                        }
                    )

        # Add initial default availability
        for day in [0, 1, 2, 3, 4]: # Mon-Fri
            Availability.objects.create(
                user=user,
                day_of_week=day,
                start_time='16:00:00',
                end_time='18:00:00'
            )

        return user
