from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate, get_user_model
from .models import StudentProfile, Availability
from .serializers import (
    MultiStepRegisterSerializer,
    UserDetailSerializer,
    StudentProfileSerializer,
    AvailabilitySerializer
)

User = get_user_model()

class RegisterView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = MultiStepRegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            refresh = RefreshToken.for_user(user)
            return Response({
                'message': 'Registration successful! 50 SkillSwap welcome credits have been deposited in your credit wallet.',
                'tokens': {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                },
                'user': UserDetailSerializer(user).data
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        username_or_email = (request.data.get('username') or request.data.get('email') or '').strip()
        password = request.data.get('password') or ''

        if not username_or_email or not password:
            return Response({'error': 'Please provide both username/email and password.'}, status=status.HTTP_400_BAD_REQUEST)

        # Check by email or username (case-insensitive lookup)
        user = None
        if '@' in username_or_email:
            user_obj = User.objects.filter(email__iexact=username_or_email).first()
        else:
            user_obj = User.objects.filter(username__iexact=username_or_email).first()

        if user_obj:
            user = authenticate(request, username=user_obj.username, password=password)
        else:
            user = authenticate(request, username=username_or_email, password=password)

        if not user:
            return Response({'error': 'Invalid username/email or password.'}, status=status.HTTP_401_UNAUTHORIZED)

        if not user.is_active:
            return Response({'error': 'This account has been deactivated. Please contact campus administration.'}, status=status.HTTP_403_FORBIDDEN)

        refresh = RefreshToken.for_user(user)
        return Response({
            'tokens': {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            },
            'user': UserDetailSerializer(user).data
        })


class CurrentUserView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        serializer = UserDetailSerializer(request.user)
        return Response(serializer.data)


class ProfileDetailView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk=None):
        target_user = request.user if pk is None else User.objects.filter(id=pk).first()
        if not target_user:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)
        return Response(UserDetailSerializer(target_user).data)

    def patch(self, request, pk=None):
        profile = getattr(request.user, 'profile', None)
        if not profile:
            profile = StudentProfile.objects.create(user=request.user)

        serializer = StudentProfileSerializer(profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()

            # Update User fields if provided
            user_fields = {}
            if 'first_name' in request.data:
                user_fields['first_name'] = request.data['first_name']
            if 'last_name' in request.data:
                user_fields['last_name'] = request.data['last_name']
            if 'phone_number' in request.data:
                user_fields['phone_number'] = request.data['phone_number']
            if user_fields:
                User.objects.filter(id=request.user.id).update(**user_fields)

            return Response(UserDetailSerializer(request.user).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class AvailabilityListCreateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, user_id=None):
        target_user = request.user if user_id is None else User.objects.filter(id=user_id).first()
        if not target_user:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
        avails = Availability.objects.filter(user=target_user)
        return Response(AvailabilitySerializer(avails, many=True).data)

    def post(self, request):
        day_of_week = request.data.get('day_of_week')
        start_time = request.data.get('start_time')
        end_time = request.data.get('end_time')

        avail, created = Availability.objects.update_or_create(
            user=request.user,
            day_of_week=day_of_week,
            defaults={
                'start_time': start_time,
                'end_time': end_time,
                'is_active': request.data.get('is_active', True)
            }
        )
        return Response(AvailabilitySerializer(avail).data, status=status.HTTP_201_CREATED)
