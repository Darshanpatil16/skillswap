from rest_framework import permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Achievement, StudentAchievement
from .serializers import AchievementSerializer
from .services import AchievementService

class AchievementListView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        # Auto-evaluate in case new threshold was achieved
        AchievementService.evaluate_user_achievements(request.user)

        achievements = Achievement.objects.all()
        # Seed standard badges if not present
        if not achievements.exists():
            seed_achievements()
            achievements = Achievement.objects.all()

        return Response(AchievementSerializer(achievements, many=True, context={'request': request}).data)


def seed_achievements():
    items = [
        ("First Skill Shared", "first_skill", "Registered and passed verification for your first peer teaching skill.", "Award", "indigo", "first_skill", 1),
        ("First Session Completed", "first_session", "Successfully finished your first collaborative learning session on SkillSwap.", "CheckCircle2", "emerald", "first_session", 1),
        ("Knowledge Sharer", "knowledge_sharer", "Taught 5 or more peer sessions and contributed to campus learning.", "Share2", "blue", "knowledge_sharer", 5),
        ("Active Learner", "active_learner", "Completed 5 or more learning sessions as an enthusiastic student.", "BookOpen", "cyan", "active_learner", 5),
        ("10 Hours of Teaching", "ten_hours_teaching", "Dedicated over 10 hours of hands-on peer instruction.", "Clock", "purple", "ten_hours_teaching", 10),
        ("5-Star Tutor", "five_star_tutor", "Maintained an exceptional 5.0 rating across 3+ student reviews.", "Sparkles", "amber", "five_star_tutor", 3),
        ("SkillSwap Champion", "skillswap_champion", "Completed 20+ total skill exchange sessions across the platform.", "Crown", "rose", "skillswap_champion", 20),
    ]
    for name, slug, desc, icon, color, cond, thresh in items:
        Achievement.objects.get_or_create(
            slug=slug,
            defaults={
                'name': name,
                'description': desc,
                'icon': icon,
                'badge_color': color,
                'condition_type': cond,
                'threshold': thresh
            }
        )
