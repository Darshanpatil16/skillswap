from rest_framework import serializers
from .models import Achievement, StudentAchievement

class AchievementSerializer(serializers.ModelSerializer):
    is_earned = serializers.SerializerMethodField()
    earned_at = serializers.SerializerMethodField()

    class Meta:
        model = Achievement
        fields = ['id', 'name', 'slug', 'description', 'icon', 'badge_color', 'condition_type', 'threshold', 'is_earned', 'earned_at']

    def get_is_earned(self, obj):
        user = self.context.get('request').user if 'request' in self.context else None
        if user and user.is_authenticated:
            return StudentAchievement.objects.filter(student=user, achievement=obj).exists()
        return False

    def get_earned_at(self, obj):
        user = self.context.get('request').user if 'request' in self.context else None
        if user and user.is_authenticated:
            sa = StudentAchievement.objects.filter(student=user, achievement=obj).first()
            return sa.earned_at if sa else None
        return None
