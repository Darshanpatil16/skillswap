from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q
from django.utils import timezone
from django.contrib.auth import get_user_model
from .models import SkillSwapRequest
from .serializers import SkillSwapRequestSerializer, CreateSkillSwapSerializer
from skills.models import StudentTeachingSkill, StudentLearningInterest, Skill
from notifications.models import Notification
from achievements.services import AchievementService

User = get_user_model()

class MutualMatchesView(APIView):
    """
    Identifies direct mutual matches (Section 12):
    Current user teaches Skill A and wants to learn Skill B.
    Another student teaches Skill B and wants to learn Skill A.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user

        # User's teaching skills (verified preferred or published)
        my_teaching = StudentTeachingSkill.objects.filter(student=user, verification_status='verified').values_list('skill_id', flat=True)
        # User's learning interests
        my_learning = StudentLearningInterest.objects.filter(student=user).values_list('skill_id', flat=True)

        if not my_teaching or not my_learning:
            return Response([])

        # Find other students who teach one of my_learning skills AND want to learn one of my_teaching skills
        other_tutors = StudentTeachingSkill.objects.filter(
            skill_id__in=my_learning,
            verification_status='verified'
        ).exclude(student=user).select_related('student', 'skill')

        matches = []
        for tutor in other_tutors:
            peer = tutor.student
            # Check if peer wants to learn any skill I teach
            peer_wants = StudentLearningInterest.objects.filter(
                student=peer,
                skill_id__in=my_teaching
            ).select_related('skill').first()

            if peer_wants:
                matches.append({
                    'peer_id': peer.id,
                    'peer_username': peer.username,
                    'peer_full_name': peer.get_full_name() or peer.username,
                    'peer_college': getattr(getattr(peer, 'profile', None), 'college_name', ''),
                    'peer_department': getattr(getattr(peer, 'profile', None), 'department', ''),
                    'peer_rating': float(getattr(getattr(peer, 'profile', None), 'average_rating', 5.0)),
                    'skill_they_teach': {
                        'id': tutor.skill.id,
                        'name': tutor.skill.name,
                        'category': tutor.skill.category.name,
                        'experience_level': tutor.experience_level
                    },
                    'skill_you_teach_them': {
                        'id': peer_wants.skill.id,
                        'name': peer_wants.skill.name,
                        'category': peer_wants.skill.category.name
                    },
                    'match_type': 'Perfect 1:1 Mutual Skill Swap',
                    'credit_cost': 0 # 0 Credits
                })

        return Response(matches)


class SkillSwapListCreateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        swaps = SkillSwapRequest.objects.filter(
            Q(initiator=user) | Q(receiver=user)
        ).select_related('initiator', 'receiver', 'initiator_skill_offered', 'receiver_skill_requested')
        return Response(SkillSwapRequestSerializer(swaps, many=True).data)

    def post(self, request):
        serializer = CreateSkillSwapSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        receiver = User.objects.filter(id=data['receiver_id']).first()
        if not receiver:
            return Response({'error': 'Recipient student not found.'}, status=status.HTTP_404_NOT_FOUND)

        if receiver == request.user:
            return Response({'error': 'You cannot initiate a skill swap with yourself.'}, status=status.HTTP_400_BAD_REQUEST)

        offered_skill = Skill.objects.filter(id=data['initiator_skill_offered_id']).first()
        requested_skill = Skill.objects.filter(id=data['receiver_skill_requested_id']).first()

        if not offered_skill or not requested_skill:
            return Response({'error': 'Invalid skill selected for swap.'}, status=status.HTTP_400_BAD_REQUEST)

        swap = SkillSwapRequest.objects.create(
            initiator=request.user,
            receiver=receiver,
            initiator_skill_offered=offered_skill,
            receiver_skill_requested=requested_skill,
            message=data.get('message', ''),
            scheduled_date=data.get('scheduled_date'),
            start_time=data.get('start_time'),
            session_duration_minutes=data.get('session_duration_minutes', 60),
            meeting_link=data.get('meeting_link', 'Campus Library / Google Meet'),
            status='pending'
        )

        Notification.objects.create(
            user=receiver,
            title="🔄 Skill Swap Invitation!",
            message=f"{request.user.username} invited you to a Skill Swap: teach {requested_skill.name} in exchange for learning {offered_skill.name} (0 credits!).",
            notification_type='swap_invitation',
            link_url='/swaps'
        )

        return Response(SkillSwapRequestSerializer(swap).data, status=status.HTTP_201_CREATED)


class SkillSwapActionView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk, action):
        user = request.user
        swap = SkillSwapRequest.objects.filter(
            id=pk
        ).filter(Q(initiator=user) | Q(receiver=user)).first()

        if not swap:
            return Response({'error': 'Skill swap request not found.'}, status=status.HTTP_404_NOT_FOUND)

        if action == 'accept':
            if swap.receiver != user:
                return Response({'error': 'Only the recipient can accept this swap invitation.'}, status=status.HTTP_403_FORBIDDEN)
            swap.status = 'accepted'
            swap.save()

            Notification.objects.create(
                user=swap.initiator,
                title="✅ Skill Swap Accepted!",
                message=f"{user.username} accepted your Skill Swap invitation ({swap.initiator_skill_offered.name} <-> {swap.receiver_skill_requested.name})!",
                notification_type='swap_invitation',
                link_url='/swaps'
            )

        elif action == 'reject':
            swap.status = 'rejected'
            swap.save()

        elif action == 'complete':
            if user == swap.initiator:
                swap.initiator_confirmed_completed = True
            elif user == swap.receiver:
                swap.receiver_confirmed_completed = True

            swap.save()

            if swap.initiator_confirmed_completed and swap.receiver_confirmed_completed:
                swap.status = 'completed'
                swap.completed_at = timezone.now()
                swap.save()

                AchievementService.evaluate_user_achievements(swap.initiator)
                AchievementService.evaluate_user_achievements(swap.receiver)

                Notification.objects.create(
                    user=swap.initiator,
                    title="🎉 Skill Swap Completed!",
                    message=f"Mutual skill swap with {swap.receiver.username} successfully completed (Zero Credits Charged)!",
                    notification_type='system',
                    link_url='/swaps'
                )
                Notification.objects.create(
                    user=swap.receiver,
                    title="🎉 Skill Swap Completed!",
                    message=f"Mutual skill swap with {swap.initiator.username} successfully completed (Zero Credits Charged)!",
                    notification_type='system',
                    link_url='/swaps'
                )

        return Response(SkillSwapRequestSerializer(swap).data)
