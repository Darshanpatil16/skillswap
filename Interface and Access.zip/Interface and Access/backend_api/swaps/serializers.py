from rest_framework import serializers
from .models import SkillSwapRequest
from accounts.serializers import UserShortSerializer
from skills.serializers import SkillSerializer

class SkillSwapRequestSerializer(serializers.ModelSerializer):
    initiator_details = UserShortSerializer(source='initiator', read_only=True)
    receiver_details = UserShortSerializer(source='receiver', read_only=True)
    offered_skill_details = SkillSerializer(source='initiator_skill_offered', read_only=True)
    requested_skill_details = SkillSerializer(source='receiver_skill_requested', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = SkillSwapRequest
        fields = [
            'id', 'initiator', 'initiator_details', 'receiver', 'receiver_details',
            'initiator_skill_offered', 'offered_skill_details',
            'receiver_skill_requested', 'requested_skill_details',
            'initiator_topics', 'receiver_topics',
            'scheduled_date', 'start_time', 'session_duration_minutes', 'meeting_link',
            'status', 'status_display', 'message',
            'initiator_confirmed_completed', 'receiver_confirmed_completed',
            'completed_at', 'created_at', 'updated_at'
        ]
        read_only_fields = [
            'initiator', 'initiator_confirmed_completed', 'receiver_confirmed_completed', 
            'completed_at', 'created_at', 'updated_at'
        ]


class CreateSkillSwapSerializer(serializers.Serializer):
    receiver_id = serializers.CharField()
    initiator_skill_offered_id = serializers.CharField()
    receiver_skill_requested_id = serializers.CharField()
    message = serializers.CharField(required=False, allow_blank=True, default='')
    scheduled_date = serializers.DateField(required=False, allow_null=True)
    start_time = serializers.TimeField(required=False, allow_null=True)
    session_duration_minutes = serializers.IntegerField(default=60)
    meeting_link = serializers.CharField(required=False, default='Campus Library / Google Meet')
