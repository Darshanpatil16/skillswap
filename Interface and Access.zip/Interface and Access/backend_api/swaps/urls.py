from django.urls import path
from .views import (
    MutualMatchesView,
    SkillSwapListCreateView,
    SkillSwapActionView
)

urlpatterns = [
    path('swaps/mutual-matches/', MutualMatchesView.as_view(), name='mutual_matches'),
    path('swaps/', SkillSwapListCreateView.as_view(), name='swap_list_create'),
    path('swaps/<str:pk>/<str:action>/', SkillSwapActionView.as_view(), name='swap_action'),
]
