from rest_framework import serializers
from .models import SkillCategory, Skill, StudentTeachingSkill, StudentLearningInterest
from accounts.serializers import UserShortSerializer

class SkillCategorySerializer(serializers.ModelSerializer):
    skills_count = serializers.SerializerMethodField()

    class Meta:
        model = SkillCategory
        fields = ['id', 'name', 'slug', 'description', 'icon', 'display_order', 'skills_count']

    def get_skills_count(self, obj):
        return obj.skills.filter(is_active=True).count()


class SkillSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    category_slug = serializers.CharField(source='category.slug', read_only=True)

    class Meta:
        model = Skill
        fields = ['id', 'name', 'category', 'category_name', 'category_slug', 'description', 'default_topics', 'is_active']


class StudentTeachingSkillSerializer(serializers.ModelSerializer):
    skill_details = SkillSerializer(source='skill', read_only=True)
    student_details = UserShortSerializer(source='student', read_only=True)
    hourly_rate = serializers.IntegerField(read_only=True)
    verification_status = serializers.CharField(read_only=True)
    verification_score = serializers.IntegerField(read_only=True)

    class Meta:
        model = StudentTeachingSkill
        fields = [
            'id', 'student', 'student_details', 'skill', 'skill_details', 
            'experience_level', 'experience_duration', 'description', 
            'topics_offered', 'teaching_language', 'preferred_duration_minutes', 
            'certificate_file', 'portfolio_link', 'hourly_rate', 
            'verification_status', 'verification_score', 'verification_note',
            'is_published', 'total_sessions_taught', 'average_rating', 
            'created_at', 'updated_at'
        ]
        read_only_fields = ['student', 'hourly_rate', 'verification_status', 'verification_score', 'is_published', 'total_sessions_taught', 'average_rating']

    def create(self, validated_data):
        user = self.context['request'].user
        skill = validated_data['skill']

        # Determine hourly credit rate from level
        rates = {'beginner': 10, 'intermediate': 15, 'advanced': 20}
        level = validated_data.get('experience_level', 'intermediate')
        rate = rates.get(level, 15)

        teaching_skill, created = StudentTeachingSkill.objects.update_or_create(
            student=user,
            skill=skill,
            defaults={
                'experience_level': level,
                'experience_duration': validated_data.get('experience_duration', '1 year'),
                'description': validated_data.get('description', ''),
                'topics_offered': validated_data.get('topics_offered', []),
                'teaching_language': validated_data.get('teaching_language', 'English'),
                'preferred_duration_minutes': validated_data.get('preferred_duration_minutes', 60),
                'certificate_file': validated_data.get('certificate_file', None),
                'portfolio_link': validated_data.get('portfolio_link', ''),
                'hourly_rate': rate,
                'verification_status': 'pending',
                'is_published': False
            }
        )
        return teaching_skill


class TutorCardSerializer(serializers.ModelSerializer):
    tutor_id = serializers.CharField(source='student.id', read_only=True)
    tutor_name = serializers.SerializerMethodField()
    profile_picture = serializers.SerializerMethodField()
    college = serializers.CharField(source='student.profile.college_name', read_only=True)
    department = serializers.CharField(source='student.profile.department', read_only=True)
    skill_name = serializers.CharField(source='skill.name', read_only=True)
    category_name = serializers.CharField(source='skill.category.name', read_only=True)
    teaching_mode = serializers.CharField(source='student.profile.teaching_mode', read_only=True)

    class Meta:
        model = StudentTeachingSkill
        fields = [
            'id', 'tutor_id', 'tutor_name', 'profile_picture', 'college', 'department',
            'skill', 'skill_name', 'category_name', 'experience_level', 'experience_duration',
            'hourly_rate', 'verification_status', 'verification_score', 'average_rating',
            'total_sessions_taught', 'topics_offered', 'teaching_language', 'teaching_mode',
            'description', 'portfolio_link'
        ]

    def get_tutor_name(self, obj):
        full = obj.student.get_full_name()
        return full if full else obj.student.username

    def get_profile_picture(self, obj):
        profile = getattr(obj.student, 'profile', None)
        if profile and profile.profile_picture:
            return profile.profile_picture.url
        return None


class StudentLearningInterestSerializer(serializers.ModelSerializer):
    skill_details = SkillSerializer(source='skill', read_only=True)

    class Meta:
        model = StudentLearningInterest
        fields = ['id', 'student', 'skill', 'skill_details', 'preferred_level', 'preferred_duration_minutes', 'learning_goals', 'created_at']
        read_only_fields = ['student']
