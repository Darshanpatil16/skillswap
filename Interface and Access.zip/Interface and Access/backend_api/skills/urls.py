from django.urls import path
from .views import (
    CategoryListView,
    SkillListView,
    MyTeachingSkillsView,
    MyTeachingSkillDetailView,
    MyLearningInterestsView,
    TutorSearchView,
    IntelligentMatchingView
)

urlpatterns = [
    path('skills/categories/', CategoryListView.as_view(), name='category_list'),
    path('skills/', SkillListView.as_view(), name='skill_list'),
    path('teaching/my-skills/', MyTeachingSkillsView.as_view(), name='my_teaching_skills'),
    path('teaching/my-skills/<str:pk>/', MyTeachingSkillDetailView.as_view(), name='my_teaching_skill_detail'),
    path('learning/interests/', MyLearningInterestsView.as_view(), name='my_learning_interests'),
    path('learning/interests/<str:pk>/', MyLearningInterestsView.as_view(), name='delete_learning_interest'),
    path('learning/tutors/', TutorSearchView.as_view(), name='tutor_search'),
    path('learning/recommendations/', IntelligentMatchingView.as_view(), name='intelligent_matching'),
]
