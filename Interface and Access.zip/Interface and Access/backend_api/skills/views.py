from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q
from .models import SkillCategory, Skill, StudentTeachingSkill, StudentLearningInterest
from .serializers import (
    SkillCategorySerializer,
    SkillSerializer,
    StudentTeachingSkillSerializer,
    TutorCardSerializer,
    StudentLearningInterestSerializer
)
from accounts.models import Availability

class CategoryListView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        categories = SkillCategory.objects.all().order_by('display_order', 'name')
        return Response(SkillCategorySerializer(categories, many=True).data)


class SkillListView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        category_slug = request.query_params.get('category')
        skills = Skill.objects.filter(is_active=True)
        if category_slug:
            skills = skills.filter(category__slug=category_slug)
        return Response(SkillSerializer(skills, many=True).data)


class MyTeachingSkillsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        skills = StudentTeachingSkill.objects.filter(student=request.user)
        return Response(StudentTeachingSkillSerializer(skills, many=True).data)

    def post(self, request):
        serializer = StudentTeachingSkillSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            teaching_skill = serializer.save()
            return Response(StudentTeachingSkillSerializer(teaching_skill).data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class MyTeachingSkillDetailView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, pk):
        ts = StudentTeachingSkill.objects.filter(student=request.user, pk=pk).first()
        if not ts:
            return Response({'error': 'Teaching skill not found'}, status=status.HTTP_404_NOT_FOUND)
        return Response(StudentTeachingSkillSerializer(ts).data)

    def patch(self, request, pk):
        ts = StudentTeachingSkill.objects.filter(student=request.user, pk=pk).first()
        if not ts:
            return Response({'error': 'Teaching skill not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = StudentTeachingSkillSerializer(ts, data=request.data, partial=True, context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response(StudentTeachingSkillSerializer(ts).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        ts = StudentTeachingSkill.objects.filter(student=request.user, pk=pk).first()
        if not ts:
            return Response({'error': 'Teaching skill not found'}, status=status.HTTP_404_NOT_FOUND)
        ts.delete()
        return Response({'message': 'Teaching skill removed'}, status=status.HTTP_204_NO_CONTENT)


class MyLearningInterestsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        interests = StudentLearningInterest.objects.filter(student=request.user)
        return Response(StudentLearningInterestSerializer(interests, many=True).data)

    def post(self, request):
        skill_id = request.data.get('skill')
        skill = Skill.objects.filter(id=skill_id).first()
        if not skill:
            return Response({'error': 'Skill not found'}, status=status.HTTP_404_NOT_FOUND)

        interest, created = StudentLearningInterest.objects.get_or_create(
            student=request.user,
            skill=skill,
            defaults={
                'preferred_level': request.data.get('preferred_level', 'beginner'),
                'preferred_duration_minutes': request.data.get('preferred_duration_minutes', 60),
                'learning_goals': request.data.get('learning_goals', '')
            }
        )
        return Response(StudentLearningInterestSerializer(interest).data, status=status.HTTP_201_CREATED)

    def delete(self, request, pk):
        interest = StudentLearningInterest.objects.filter(student=request.user, pk=pk).first()
        if not interest:
            return Response({'error': 'Interest not found'}, status=status.HTTP_404_NOT_FOUND)
        interest.delete()
        return Response({'message': 'Interest removed'}, status=status.HTTP_204_NO_CONTENT)


class TutorSearchView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        # Only verified or published tutors
        tutors = StudentTeachingSkill.objects.filter(is_published=True, verification_status='verified')

        # Exclude self if authenticated
        if request.user.is_authenticated:
            tutors = tutors.exclude(student=request.user)

        # Filters
        query = request.query_params.get('q', '').strip()
        if query:
            tutors = tutors.filter(
                Q(skill__name__icontains=query) |
                Q(student__username__icontains=query) |
                Q(student__first_name__icontains=query) |
                Q(student__last_name__icontains=query) |
                Q(topics_offered__icontains=query)
            )

        category = request.query_params.get('category')
        if category:
            tutors = tutors.filter(skill__category__slug=category)

        level = request.query_params.get('level')
        if level:
            tutors = tutors.filter(experience_level=level)

        min_rating = request.query_params.get('min_rating')
        if min_rating:
            try:
                tutors = tutors.filter(average_rating__gte=float(min_rating))
            except ValueError:
                pass

        max_credits = request.query_params.get('max_credits')
        if max_credits:
            try:
                tutors = tutors.filter(hourly_rate__lte=int(max_credits))
            except ValueError:
                pass

        mode = request.query_params.get('mode')
        if mode:
            tutors = tutors.filter(student__profile__teaching_mode=mode)

        # Sorting
        sort_by = request.query_params.get('sort_by', 'rating')
        if sort_by == 'rating':
            tutors = tutors.order_by('-average_rating', '-total_sessions_taught')
        elif sort_by == 'sessions':
            tutors = tutors.order_by('-total_sessions_taught', '-average_rating')
        elif sort_by == 'cost_asc':
            tutors = tutors.order_by('hourly_rate', '-average_rating')
        elif sort_by == 'cost_desc':
            tutors = tutors.order_by('-hourly_rate', '-average_rating')
        elif sort_by == 'experience':
            tutors = tutors.order_by('-verification_score', '-average_rating')

        return Response(TutorCardSerializer(tutors, many=True).data)


class IntelligentMatchingView(APIView):
    """
    Intelligent Skill Matching engine (Prompt Section 11):
    Considers requested skill, tutor skill level, assessment verification score,
    ratings, completed sessions, and matching availability.
    Calculates a relevance score (0-100) and provides a clear human-readable explanation.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        user_interests = StudentLearningInterest.objects.filter(student=user).select_related('skill')
        target_skills = [interest.skill for interest in user_interests]

        # If user has no specific interests, suggest top verified tutors
        if not target_skills:
            available_skills = Skill.objects.filter(tutors__is_published=True, tutors__verification_status='verified').distinct()[:5]
            target_skills = list(available_skills)

        # Find verified tutors for these skills excluding self
        tutors = StudentTeachingSkill.objects.filter(
            skill__in=target_skills,
            is_published=True,
            verification_status='verified'
        ).exclude(student=user).select_related('student', 'student__profile', 'skill')

        # Check learner's availability days
        learner_days = set(Availability.objects.filter(user=user, is_active=True).values_list('day_of_week', flat=True))

        matched_results = []
        for tutor in tutors:
            # 1. Base Score from Verification Score (up to 40 pts)
            v_score = tutor.verification_score or 85
            score_verification = (v_score / 100.0) * 40.0

            # 2. Rating Score (up to 30 pts)
            rating = float(tutor.average_rating or 5.0)
            score_rating = (rating / 5.0) * 30.0

            # 3. Completed Sessions Experience (up to 15 pts)
            sessions = min(tutor.total_sessions_taught, 15)
            score_sessions = (sessions / 15.0) * 15.0

            # 4. Availability Match (up to 15 pts)
            tutor_days = set(Availability.objects.filter(user=tutor.student, is_active=True).values_list('day_of_week', flat=True))
            common_days = learner_days.intersection(tutor_days)
            score_availability = 15.0 if common_days else 8.0

            total_relevance = round(score_verification + score_rating + score_sessions + score_availability)

            # Generate dynamic explanation
            reasons = []
            if tutor.verification_status == 'verified':
                reasons.append(f"verified {tutor.skill.name} assessment ({v_score}%)")
            if rating >= 4.8:
                reasons.append(f"top tutor rating ({rating}★)")
            if common_days:
                reasons.append("matching weekly availability")
            if tutor.total_sessions_taught > 0:
                reasons.append(f"{tutor.total_sessions_taught} completed sessions")

            explanation = f"Recommended because this tutor has " + ", ".join(reasons) + "."

            card_data = TutorCardSerializer(tutor).data
            card_data['relevance_score'] = total_relevance
            card_data['match_explanation'] = explanation
            matched_results.append(card_data)

        # Sort by relevance score descending
        matched_results.sort(key=lambda x: x['relevance_score'], reverse=True)
        return Response(matched_results)
