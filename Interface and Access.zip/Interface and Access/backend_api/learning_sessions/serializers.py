from rest_framework import serializers
from .models import LearningSession, Dispute
from accounts.serializers import UserShortSerializer
from skills.serializers import SkillSerializer

class DisputeSerializer(serializers.ModelSerializer):
    raised_by_name = serializers.CharField(source='raised_by.username', read_only=True)
    session_details = serializers.SerializerMethodField()

    class Meta:
        model = Dispute
        fields = ['id', 'session', 'session_details', 'raised_by', 'raised_by_name', 'reason', 'evidence_text', 'status', 'admin_notes', 'created_at', 'resolved_at']
        read_only_fields = ['raised_by', 'status', 'admin_notes', 'resolved_at']

    def get_session_details(self, obj):
        return {
            'id': obj.session.id,
            'skill_name': obj.session.skill.name,
            'teacher_name': obj.session.teacher.username,
            'learner_name': obj.session.learner.username,
            'credit_amount': obj.session.credit_amount,
            'scheduled_date': str(obj.session.scheduled_date)
        }


class LearningSessionSerializer(serializers.ModelSerializer):
    teacher_details = UserShortSerializer(source='teacher', read_only=True)
    learner_details = UserShortSerializer(source='learner', read_only=True)
    skill_details = SkillSerializer(source='skill', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    dispute = DisputeSerializer(read_only=True)

    class Meta:
        model = LearningSession
        fields = [
            'id', 'teacher', 'teacher_details', 'learner', 'learner_details', 
            'skill', 'skill_details', 'teaching_skill', 'topics', 
            'scheduled_date', 'start_time', 'duration_minutes', 'credit_amount', 
            'session_mode', 'meeting_link_or_location', 'notes', 'status', 
            'status_display', 'teacher_completed_confirmed', 'learner_completed_confirmed', 
            'completion_timestamp', 'cancellation_reason', 'dispute', 'created_at', 'updated_at'
        ]
        read_only_fields = [
            'learner', 'teacher_completed_confirmed', 'learner_completed_confirmed', 
            'completion_timestamp', 'created_at', 'updated_at'
        ]


class SessionRequestCreateSerializer(serializers.Serializer):
    tutor_id = serializers.CharField()
    skill_id = serializers.CharField()
    topics = serializers.ListField(child=serializers.CharField(), required=False, default=list)
    scheduled_date = serializers.DateField()
    start_time = serializers.TimeField()
    duration_minutes = serializers.IntegerField(default=60)
    session_mode = serializers.ChoiceField(choices=['online', 'offline'], default='online')
    meeting_link_or_location = serializers.CharField(required=False, default='Google Meet / Campus Library')
    notes = serializers.CharField(required=False, allow_blank=True, default='')
