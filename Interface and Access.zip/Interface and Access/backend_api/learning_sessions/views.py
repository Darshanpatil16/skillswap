from rest_framework import status, permissions
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Q, F
from django.utils import timezone
from django.contrib.auth import get_user_model
from decimal import Decimal
from .models import LearningSession, Dispute
from .serializers import LearningSessionSerializer, SessionRequestCreateSerializer, DisputeSerializer
from skills.models import Skill, StudentTeachingSkill
from wallet.models import CreditWallet
from wallet.services import WalletService
from notifications.models import Notification
from achievements.services import AchievementService
from accounts.models import StudentProfile

User = get_user_model()

class SessionListView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        role_filter = request.query_params.get('role') # 'teaching' or 'learning'
        status_filter = request.query_params.get('status')

        qs = LearningSession.objects.filter(
            Q(teacher=user) | Q(learner=user)
        ).select_related('teacher', 'learner', 'skill', 'teaching_skill')

        if role_filter == 'teaching':
            qs = qs.filter(teacher=user)
        elif role_filter == 'learning':
            qs = qs.filter(learner=user)

        if status_filter:
            qs = qs.filter(status=status_filter)

        return Response(LearningSessionSerializer(qs, many=True).data)


class SessionRequestCreateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = SessionRequestCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        learner = request.user
        tutor = User.objects.filter(id=data['tutor_id']).first()

        if not tutor:
            return Response({'error': 'Tutor not found.'}, status=status.HTTP_404_NOT_FOUND)

        if tutor == learner:
            return Response({'error': 'You cannot request a learning session with yourself.'}, status=status.HTTP_400_BAD_REQUEST)

        skill = Skill.objects.filter(id=data['skill_id']).first()
        if not skill:
            return Response({'error': 'Skill not found.'}, status=status.HTTP_404_NOT_FOUND)

        teaching_skill = StudentTeachingSkill.objects.filter(
            student=tutor,
            skill=skill,
            is_published=True,
            verification_status='verified'
        ).first()

        if not teaching_skill:
            return Response({'error': 'This tutor does not currently have a verified listing for this skill.'}, status=status.HTTP_400_BAD_REQUEST)

        # Check conflicting tutor schedule
        has_conflict = LearningSession.objects.filter(
            teacher=tutor,
            scheduled_date=data['scheduled_date'],
            start_time=data['start_time'],
            status__in=['accepted', 'in_progress']
        ).exists()

        if has_conflict:
            return Response(
                {'error': 'Tutor already has an accepted session scheduled at this date and time. Please select another slot.'},
                status=status.HTTP_409_CONFLICT
            )

        # Calculate credit cost
        duration_hours = max(data['duration_minutes'] / 60.0, 0.5)
        credit_cost = round(teaching_skill.hourly_rate * duration_hours)

        # Validate learner credit balance
        wallet, _ = CreditWallet.objects.get_or_create(user=learner)
        if wallet.available_balance < credit_cost:
            return Response({
                'error': f'Insufficient credits. Required: {credit_cost} credits, Available: {wallet.available_balance} credits.'
            }, status=status.HTTP_400_BAD_REQUEST)

        # Create session record
        session = LearningSession.objects.create(
            teacher=tutor,
            learner=learner,
            skill=skill,
            teaching_skill=teaching_skill,
            topics=data.get('topics', []),
            scheduled_date=data['scheduled_date'],
            start_time=data['start_time'],
            duration_minutes=data['duration_minutes'],
            credit_amount=credit_cost,
            session_mode=data['session_mode'],
            meeting_link_or_location=data.get('meeting_link_or_location', 'Google Meet'),
            notes=data.get('notes', ''),
            status='requested'
        )

        # Place credits in escrow atomically
        try:
            WalletService.hold_session_escrow(learner, session.id, credit_cost)
        except Exception as e:
            session.delete()
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

        # Send notification to tutor
        Notification.objects.create(
            user=tutor,
            title="📬 New Session Request",
            message=f"{learner.username} requested a {session.duration_minutes}-min session on {skill.name} for {credit_cost} credits.",
            notification_type='session_request',
            link_url='/sessions'
        )

        return Response(LearningSessionSerializer(session).data, status=status.HTTP_201_CREATED)


class SessionAcceptRejectView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk, action):
        session = LearningSession.objects.filter(id=pk, teacher=request.user).first()
        if not session:
            return Response({'error': 'Session not found or not your teaching request.'}, status=status.HTTP_404_NOT_FOUND)

        if session.status != 'requested':
            return Response({'error': f'Cannot {action} a session with status "{session.status}".'}, status=status.HTTP_400_BAD_REQUEST)

        if action == 'accept':
            # Check for conflict
            conflict = LearningSession.objects.filter(
                teacher=request.user,
                scheduled_date=session.scheduled_date,
                start_time=session.start_time,
                status='accepted'
            ).exclude(id=session.id).exists()

            if conflict:
                return Response({'error': 'You already have another accepted session at this exact date and time.'}, status=status.HTTP_409_CONFLICT)

            session.status = 'accepted'
            session.save()

            Notification.objects.create(
                user=session.learner,
                title="✅ Session Request Accepted!",
                message=f"{request.user.username} accepted your {session.skill.name} session on {session.scheduled_date}.",
                notification_type='session_accepted',
                link_url='/sessions'
            )

        elif action == 'reject':
            session.status = 'rejected'
            session.cancellation_reason = request.data.get('reason', 'Declined by tutor')
            session.save()

            # Refund escrowed credits back to learner
            WalletService.refund_session_escrow(
                session.learner, 
                session.id, 
                session.credit_amount, 
                reason=f"Tutor declined request: {session.cancellation_reason}"
            )

            Notification.objects.create(
                user=session.learner,
                title="⚠️ Session Request Declined",
                message=f"{request.user.username} declined your session request. {session.credit_amount} credits have been refunded to your wallet.",
                notification_type='session_rejected',
                link_url='/sessions'
            )

        return Response(LearningSessionSerializer(session).data)


class SessionMutualCompletionView(APIView):
    """
    Mutually confirmed completion workflow (Prompt Section 14).
    Both learner and teacher must confirm completion before credits are paid out.
    """
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, pk):
        user = request.user
        session = LearningSession.objects.filter(
            id=pk,
            status__in=['accepted', 'in_progress']
        ).filter(Q(teacher=user) | Q(learner=user)).first()

        if not session:
            return Response({'error': 'Session not found or cannot be marked complete.'}, status=status.HTTP_404_NOT_FOUND)

        if user == session.teacher:
            session.teacher_completed_confirmed = True
        elif user == session.learner:
            session.learner_completed_confirmed = True

        session.save()

        # Check if both have confirmed
        if session.teacher_completed_confirmed and session.learner_completed_confirmed:
            session.status = 'completed'
            session.completion_timestamp = timezone.now()
            session.save()

            # Release Escrow Payout to Teacher atomically
            WalletService.release_session_payout(
                learner=session.learner,
                teacher=session.teacher,
                session_id=session.id,
                amount=session.credit_amount
            )

            # Update teaching & learning metrics
            hours = Decimal(str(round(session.duration_minutes / 60.0, 1)))

            # Teacher profile
            t_profile = getattr(session.teacher, 'profile', None)
            if t_profile:
                t_profile.total_teaching_hours += hours
                t_profile.completed_sessions += 1
                t_profile.save()

            # Learner profile
            l_profile = getattr(session.learner, 'profile', None)
            if l_profile:
                l_profile.total_learning_hours += hours
                l_profile.completed_sessions += 1
                l_profile.save()

            # Teaching skill counter
            if session.teaching_skill:
                StudentTeachingSkill.objects.filter(id=session.teaching_skill.id).update(
                    total_sessions_taught=F('total_sessions_taught') + 1
                )

            # Evaluate gamification achievements for both
            AchievementService.evaluate_user_achievements(session.teacher)
            AchievementService.evaluate_user_achievements(session.learner)

            # Notifications
            Notification.objects.create(
                user=session.teacher,
                title="🎉 Session Completed & Paid!",
                message=f"Session #{session.id} ({session.skill.name}) marked complete. {session.credit_amount} credits transferred to your wallet!",
                notification_type='credit_received',
                link_url='/wallet'
            )
            Notification.objects.create(
                user=session.learner,
                title="🎓 Learning Session Completed",
                message=f"Session #{session.id} completed. Please leave a rating and review for {session.teacher.username}!",
                notification_type='session_completed',
                link_url='/sessions'
            )

        return Response(LearningSessionSerializer(session).data)


class SessionCancellationView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        user = request.user
        session = LearningSession.objects.filter(
            id=pk,
            status__in=['requested', 'accepted']
        ).filter(Q(teacher=user) | Q(learner=user)).first()

        if not session:
            return Response({'error': 'Session not found or cannot be cancelled.'}, status=status.HTTP_404_NOT_FOUND)

        reason = request.data.get('reason', 'Cancelled by participant')
        session.status = 'cancelled'
        session.cancelled_by = user
        session.cancellation_reason = reason
        session.save()

        # Refund escrowed credits back to learner
        WalletService.refund_session_escrow(
            session.learner,
            session.id,
            session.credit_amount,
            reason=f"Session cancelled by {user.username}: {reason}"
        )

        other_user = session.teacher if user == session.learner else session.learner
        Notification.objects.create(
            user=other_user,
            title="🚫 Session Cancelled",
            message=f"{user.username} cancelled Session #{session.id} ({session.skill.name}). Escrow credits have been refunded.",
            notification_type='session_rejected',
            link_url='/sessions'
        )

        return Response(LearningSessionSerializer(session).data)


class SessionDisputeView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        user = request.user
        session = LearningSession.objects.filter(
            id=pk
        ).filter(Q(teacher=user) | Q(learner=user)).first()

        if not session:
            return Response({'error': 'Session not found.'}, status=status.HTTP_404_NOT_FOUND)

        if session.status == 'completed':
            return Response({'error': 'Completed sessions with released payout cannot be disputed automatically. Contact admin.'}, status=status.HTTP_400_BAD_REQUEST)

        reason = request.data.get('reason', '').strip()
        evidence = request.data.get('evidence_text', '').strip()

        if not reason:
            return Response({'error': 'Please provide a clear dispute reason.'}, status=status.HTTP_400_BAD_REQUEST)

        session.status = 'disputed'
        session.save()

        dispute, created = Dispute.objects.update_or_create(
            session=session,
            defaults={
                'raised_by': user,
                'reason': reason,
                'evidence_text': evidence,
                'status': 'open'
            }
        )

        return Response(DisputeSerializer(dispute).data, status=status.HTTP_201_CREATED)
