from django.urls import path
from .views import (
    SessionListView,
    SessionRequestCreateView,
    SessionAcceptRejectView,
    SessionMutualCompletionView,
    SessionCancellationView,
    SessionDisputeView
)

urlpatterns = [
    path('sessions/', SessionListView.as_view(), name='session_list'),
    path('learning/sessions/request/', SessionRequestCreateView.as_view(), name='session_request'),
    path('teaching/requests/<str:pk>/<str:action>/', SessionAcceptRejectView.as_view(), name='session_accept_reject'),
    path('sessions/<str:pk>/complete/', SessionMutualCompletionView.as_view(), name='session_complete'),
    path('sessions/<str:pk>/cancel/', SessionCancellationView.as_view(), name='session_cancel'),
    path('sessions/<str:pk>/dispute/', SessionDisputeView.as_view(), name='session_dispute'),
]
