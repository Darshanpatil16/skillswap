# Web Technology – SkillSwap Engine

## Purpose
This folder contains the SkillSwap mini-project files relevant to **Web Technology**.

## Team member scope
React frontend, component architecture, routing, state/context, API communication, Django REST endpoints, serializers, authentication, styling and build configuration.

## Instructions
- Treat the included source files as the primary evidence. Do not invent features or claim code exists if it is not present.
- Preserve original file paths inside the reference subfolders.
- If a concept is inferred from code, label it as an interpretation and cite the exact file path.
- Keep changes inside this engine folder unless the team explicitly agrees otherwise.
- Do not add `.env`, credentials, virtual environments, `node_modules`, database dumps or generated build files.
